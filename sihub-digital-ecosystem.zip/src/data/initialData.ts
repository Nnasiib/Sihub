/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Authentic Demonstration Data
 * Represents Somali Innovation Hub's comprehensive multi-sector ecosystem.
 */

import type {
  User,
  Course,
  Enrollment,
  Startup,
  InnovationProject,
  Program,
  SiHubEvent as Event,
  Mentor,
  Opportunity,
  Partner,
  CommunityMember,
  ForumTopic,
  NewsArticle,
  ImpactMetrics,
  AuditLog
} from '../types';

export const SIHUB_LOGO_URL = '/assets/aistudio/FB_IMG_1793630993622_edit_183670017242279_811cbd58.jpg';

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-admin-1',
    fullName: 'Eng. Abdullahi Warsame',
    email: 'admin@sihub.so',
    phone: '+252 61 555 1200',
    role: 'admin',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    bio: 'Executive Director & Systems Strategist at SiHub. 12+ years supporting East African innovation ecosystems.',
    location: 'Mogadishu, Somalia',
    organization: 'Somali Innovation Hub',
    isActive: true,
    registeredAt: '2024-01-15T08:00:00Z',
    lastLoginAt: '2026-11-02T06:30:00Z'
  },
  {
    id: 'usr-superadmin-1',
    fullName: 'Fadumo Ahmed Noor',
    email: 'superadmin@sihub.so',
    phone: '+252 61 888 9012',
    role: 'super_admin',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    bio: 'Lead Architect & Institutional Governance Specialist overseeing all digital infrastructure.',
    location: 'Mogadishu, Somalia',
    organization: 'SiHub Advisory Council',
    isActive: true,
    registeredAt: '2023-11-01T08:00:00Z',
    lastLoginAt: '2026-11-02T06:45:00Z'
  },
  {
    id: 'usr-learner-1',
    fullName: 'Hodan Mohamed Barre',
    email: 'hodan.barre@student.so',
    phone: '+252 61 432 7891',
    role: 'learner',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    bio: 'Final year computer science student and aspiring cloud & web developer.',
    location: 'Hargeisa, Somalia',
    organization: 'SiHub Academy',
    isActive: true,
    registeredAt: '2026-09-10T11:20:00Z',
    lastLoginAt: '2026-11-01T14:15:00Z'
  },
  {
    id: 'usr-instructor-1',
    fullName: 'Dr. Hassan Ali Geedi',
    email: 'hassan.geedi@sihub.so',
    phone: '+252 61 223 9901',
    role: 'instructor',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    bio: 'Senior Lecturer in Renewable Energy and Applied IoT, researcher on drought resilient systems.',
    location: 'Mogadishu, Somalia',
    organization: 'SiHub Learning Lab',
    isActive: true,
    registeredAt: '2024-03-01T09:00:00Z',
    lastLoginAt: '2026-11-02T05:00:00Z'
  },
  {
    id: 'usr-founder-1',
    fullName: 'Abdirahman Farah',
    email: 'abdirahman@geeltech.so',
    phone: '+252 61 777 4433',
    role: 'startup_founder',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    bio: 'Founder of GeelTech Solutions, pioneering camel milk cold-chain logistics in rural Somalia.',
    location: 'Garowe, Somalia',
    organization: 'GeelTech Solutions',
    isActive: true,
    registeredAt: '2025-05-12T10:00:00Z',
    lastLoginAt: '2026-10-31T16:20:00Z'
  },
  {
    id: 'usr-mentor-1',
    fullName: 'Zahra Osman Guled',
    email: 'zahra.guled@globalventure.org',
    phone: '+254 71 123 4567',
    role: 'mentor',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    bio: 'Diaspora Tech Angel Investor & Product Strategy Lead based between Nairobi & London.',
    location: 'Diaspora / Regional',
    organization: 'Somali Diaspora Angels',
    isActive: true,
    registeredAt: '2024-06-20T12:00:00Z',
    lastLoginAt: '2026-10-29T18:00:00Z'
  },
  {
    id: 'usr-community-1',
    fullName: 'Jama Duale Samatar',
    email: 'jama.samatar@community.so',
    phone: '+252 61 999 1122',
    role: 'community_member',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    bio: 'Youth community organizer in Baidoa championing digital literacy and regenerative agriculture.',
    location: 'Baidoa, Somalia',
    organization: 'South West Youth Innovators',
    isActive: true,
    registeredAt: '2025-08-14T14:30:00Z',
    lastLoginAt: '2026-11-01T09:10:00Z'
  },
  {
    id: 'usr-staff-1',
    fullName: 'Khadija Yusuf Noor',
    email: 'khadija.noor@sihub.so',
    phone: '+252 61 666 3322',
    role: 'staff',
    avatarUrl: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=150&auto=format&fit=crop&q=80',
    bio: 'Operations Coordinator managing daily hub facilities, community events, and visitor registration.',
    location: 'Mogadishu, Somalia',
    organization: 'SiHub Operations Team',
    isActive: true,
    registeredAt: '2024-02-10T08:30:00Z',
    lastLoginAt: '2026-11-02T06:15:00Z'
  },
  {
    id: 'usr-partner-1',
    fullName: 'Marcus Lindqvist',
    email: 'm.lindqvist@undp-innovation.org',
    phone: '+254 20 762 1234',
    role: 'partner',
    avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    bio: 'Senior Program Portfolio Manager, UN Development Programme Somalia Accelerator Labs.',
    location: 'Nairobi / Mogadishu',
    organization: 'UNDP Somalia',
    isActive: true,
    registeredAt: '2024-04-05T09:40:00Z',
    lastLoginAt: '2026-10-30T11:00:00Z'
  },
  {
    id: 'usr-progmanager-1',
    fullName: 'Sharmarke Abdi Liban',
    email: 'sharmarke.liban@sihub.so',
    phone: '+252 61 333 8899',
    role: 'program_manager',
    avatarUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    bio: 'Incubation & Acceleration Director tracking 45+ startup cohorts across the country.',
    location: 'Mogadishu, Somalia',
    organization: 'SiHub Venture Studio',
    isActive: true,
    registeredAt: '2024-01-20T08:00:00Z',
    lastLoginAt: '2026-11-02T06:00:00Z'
  },
  {
    id: 'usr-visitor-1',
    fullName: 'Guest Visitor',
    email: 'visitor@example.com',
    role: 'visitor',
    bio: 'Exploring SiHub programs, educational offerings, and upcoming community events.',
    isActive: true,
    registeredAt: '2026-11-02T00:00:00Z'
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'crs-fullstack-01',
    title: 'Full-Stack Web & Mobile Software Engineering',
    titleSo: 'Injineernimada Barnaamijyada Webka & Mobile-ka',
    code: 'SIHUB-TECH-101',
    category: 'Technology & Software',
    description: 'Master modern frontend and backend development with TypeScript, React, Node.js, and REST/GraphQL APIs tailored for building high-scale African digital applications.',
    descriptionSo: 'Baro horumarinta barnaamijyada casriga ah adoo adeegsanaya TypeScript, React, iyo server-side APIs oo loogu talagalay suuqa Soomaaliya.',
    instructorId: 'usr-admin-1',
    instructorName: 'Eng. Abdullahi Warsame',
    instructorTitle: 'Senior Software Architect',
    durationWeeks: 12,
    hoursPerWeek: 8,
    level: 'Intermediate',
    deliveryMode: 'Online',
    capacity: 60,
    enrolledCount: 42,
    thumbnailUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&auto=format&fit=crop&q=80',
    prerequisites: ['Basic HTML/CSS understanding', 'Fundamental programming logic'],
    learningOutcomes: [
      'Design and deploy production-grade responsive web apps',
      'Architect relational database schemas with PostgreSQL',
      'Build secure REST APIs with token-based authentication',
      'Deploy applications to cloud container environments'
    ],
    isPublished: true,
    createdAt: '2026-01-10T00:00:00Z',
    modules: [
      {
        id: 'mod-tech-1',
        courseId: 'crs-fullstack-01',
        title: 'Module 1: Modern Web Foundations & React Ecosystem',
        order: 1,
        lessons: [
          {
            id: 'les-tech-1-1',
            moduleId: 'mod-tech-1',
            title: '1.1 Introduction to Modern Web Architecture & TypeScript',
            type: 'video',
            durationMinutes: 45,
            contentUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            textContent: 'Welcome to SiHub Software Engineering track! In this lesson, we explore single-page applications, typed systems, and frontend state design.'
          },
          {
            id: 'les-tech-1-2',
            moduleId: 'mod-tech-1',
            title: '1.2 Architecture Guide: Components & State Patterns',
            type: 'pdf',
            durationMinutes: 30,
            contentUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
            textContent: 'Download the comprehensive SiHub Frontend Design and State Management Architecture Handbook (PDF).'
          },
          {
            id: 'les-tech-1-3',
            moduleId: 'mod-tech-1',
            title: '1.3 Practical Assignment: Building a Responsive Portal',
            type: 'assignment',
            durationMinutes: 90,
            assignmentPrompt: 'Build a multi-card responsive dashboard that loads JSON data and demonstrates filter/search functionality. Submit your GitHub link and short description.'
          },
          {
            id: 'les-tech-1-4',
            moduleId: 'mod-tech-1',
            title: '1.4 Knowledge Check: Web Architecture Quiz',
            type: 'quiz',
            durationMinutes: 15,
            quizQuestions: [
              {
                id: 'q-tech-1',
                question: 'Which of the following is the primary advantage of static typing in TypeScript?',
                options: [
                  'It compiles directly to native binary code',
                  'It catches type errors at compile-time before code runs',
                  'It makes all API calls execute twice as fast',
                  'It eliminates the need for styling'
                ],
                correctAnswerIndex: 1,
                explanation: 'TypeScript adds compile-time type verification, reducing runtime exceptions and boosting refactoring confidence.'
              },
              {
                id: 'q-tech-2',
                question: 'What is the role of an ORM like PostgreSQL/Prisma in enterprise apps?',
                options: [
                  'To manage styling animations',
                  'To map database tables to type-safe code objects',
                  'To compress images for mobile clients',
                  'To host email accounts'
                ],
                correctAnswerIndex: 1,
                explanation: 'ORMs provide a programmatic abstraction layer between application code and relational databases.'
              }
            ]
          }
        ]
      },
      {
        id: 'mod-tech-2',
        courseId: 'crs-fullstack-01',
        title: 'Module 2: Server-Side APIs & Database Modeling',
        order: 2,
        lessons: [
          {
            id: 'les-tech-2-1',
            moduleId: 'mod-tech-2',
            title: '2.1 Relational Schema Design & Indexing',
            type: 'reading',
            durationMinutes: 40,
            textContent: 'Designing normalized schemas (3NF) versus denormalized caching views for high-concurrency payment and registration services.'
          }
        ]
      }
    ]
  },
  {
    id: 'crs-solar-02',
    title: 'Renewable Energy Systems & Solar Mini-Grids',
    titleSo: 'Nidaamyada Tamarta Qorraxda & Shabakadaha Yar-yar',
    code: 'SIHUB-ENERGY-201',
    category: 'Renewable Energy & Climate',
    description: 'Learn solar photovoltaic system design, inverter sizing, lithium battery energy storage (BESS), and smart remote metering for rural and peri-urban Somali settlements.',
    descriptionSo: 'Baro qaabeynta nidaamyada tamarta qorraxda, xisaabinta baytariyada iyo hababka casriga ah ee korontada loogu geeyo deegaanada.',
    instructorId: 'usr-instructor-1',
    instructorName: 'Dr. Hassan Ali Geedi',
    instructorTitle: 'Energy Systems Director',
    durationWeeks: 8,
    hoursPerWeek: 6,
    level: 'Beginner',
    deliveryMode: 'Online',
    capacity: 50,
    enrolledCount: 38,
    thumbnailUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=600&auto=format&fit=crop&q=80',
    prerequisites: ['Basic physics or technical aptitude', 'High school mathematics'],
    learningOutcomes: [
      'Calculate solar load requirements for commercial and residential applications',
      'Size PV arrays, charge controllers, and hybrid off-grid inverters',
      'Integrate IoT telemetry for battery health and remote power monitoring'
    ],
    isPublished: true,
    createdAt: '2026-01-20T00:00:00Z',
    modules: [
      {
        id: 'mod-sol-1',
        courseId: 'crs-solar-02',
        title: 'Module 1: Photovoltaic Fundamentals in High Irradiance Climates',
        order: 1,
        lessons: [
          {
            id: 'les-sol-1-1',
            moduleId: 'mod-sol-1',
            title: '1.1 Solar Irradiance Profiles Across Somalia and Horn of Africa',
            type: 'video',
            durationMinutes: 35,
            contentUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            textContent: 'Somalia averages over 3,000 hours of sunshine annually with peak solar irradiance of 5.5 - 6.5 kWh/m²/day.'
          },
          {
            id: 'les-sol-1-2',
            moduleId: 'mod-sol-1',
            title: '1.2 Battery Chemistry: Lead-Carbon vs LiFePO4 for High Temp Resilience',
            type: 'pdf',
            durationMinutes: 30,
            contentUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
          },
          {
            id: 'les-sol-1-3',
            moduleId: 'mod-sol-1',
            title: '1.3 Assessment: Load Estimation Quiz',
            type: 'quiz',
            durationMinutes: 15,
            quizQuestions: [
              {
                id: 'q-sol-1',
                question: 'What is the primary factor causing temperature derating in photovoltaic solar modules?',
                options: [
                  'High ambient temperature reducing cell voltage output',
                  'Dust particles reflecting sunlight entirely',
                  'Low atmospheric humidity',
                  'Inverter cable colors'
                ],
                correctAnswerIndex: 0,
                explanation: 'Silicon PV cells have a negative temperature coefficient, meaning output voltage drops as cell temperature rises above 25°C.'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'crs-agri-03',
    title: 'AgriTech & Climate-Smart Farming in Arid Zones',
    titleSo: 'Farsamada Beeraha Casriga ah & Isbedelka Cimilada',
    code: 'SIHUB-AGRI-103',
    category: 'AgriTech & Food Security',
    description: 'Precision drip irrigation, hydroponics, soil moisture sensors, drought-tolerant crop cultivars, and mobile livestock healthcare logistics.',
    descriptionSo: 'Baro waraabka casriga ah, beeraha biyaha (hydroponics), iyo adeegsiga teknoolojiyadda si looga gaashaanto abaarta.',
    instructorId: 'usr-instructor-1',
    instructorName: 'Dr. Hassan Ali Geedi',
    instructorTitle: 'AgriTech Lead',
    durationWeeks: 10,
    hoursPerWeek: 6,
    level: 'Beginner',
    deliveryMode: 'Online',
    capacity: 45,
    enrolledCount: 31,
    thumbnailUrl: 'https://images.unsplash.com/photo-1586771107445-d3ca888129ff?w=600&auto=format&fit=crop&q=80',
    prerequisites: ['Interest in agriculture, water engineering, or food systems'],
    learningOutcomes: [
      'Design solar-powered automated drip irrigation networks',
      'Read and interpret soil salinity and moisture sensors',
      'Formulate drought mitigation models for smallholder farmers'
    ],
    isPublished: true,
    createdAt: '2026-02-01T00:00:00Z',
    modules: [
      {
        id: 'mod-agri-1',
        courseId: 'crs-agri-03',
        title: 'Module 1: Water Conservation & Smart Micro-Irrigation',
        order: 1,
        lessons: [
          {
            id: 'les-ag-1-1',
            moduleId: 'mod-agri-1',
            title: '1.1 Drip Irrigation Sizing for Shabelle & Jubba River Basins',
            type: 'video',
            durationMinutes: 40,
            contentUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
          }
        ]
      }
    ]
  },
  {
    id: 'crs-startup-04',
    title: 'Digital Entrepreneurship & Venture Building in Emerging Markets',
    titleSo: 'Ganacsiga Dijitaalka ah & Kobcinta Shirkadaha Bilowga ah',
    code: 'SIHUB-VENTURE-301',
    category: 'Digital Entrepreneurship',
    description: 'From problem validation and prototype to product-market fit, unit economics, Somali commercial law, angel investment pitching, and diaspora syndicates.',
    descriptionSo: 'Sida fikrad ganacsi loogu beddelo shirkad guulaysata, loona helo maalgashi caalami ah iyo suuq ballaaran.',
    instructorId: 'usr-mentor-1',
    instructorName: 'Zahra Osman Guled',
    instructorTitle: 'Venture Partner & Investor',
    durationWeeks: 6,
    hoursPerWeek: 5,
    level: 'Intermediate',
    deliveryMode: 'Online',
    capacity: 75,
    enrolledCount: 64,
    thumbnailUrl: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&auto=format&fit=crop&q=80',
    prerequisites: ['Entrepreneurial idea or existing early prototype'],
    learningOutcomes: [
      'Construct a validated 10-slide venture investor pitch deck',
      'Calculate Customer Acquisition Cost (CAC) and Lifetime Value (LTV)',
      'Navigate mobile money integrations (EVC Plus, Zaad, Sahal)'
    ],
    isPublished: true,
    createdAt: '2026-02-15T00:00:00Z',
    modules: [
      {
        id: 'mod-ven-1',
        courseId: 'crs-startup-04',
        title: 'Module 1: Lean Startup Methodology & Market Sizing',
        order: 1,
        lessons: [
          {
            id: 'les-ven-1-1',
            moduleId: 'mod-ven-1',
            title: '1.1 Defining the Problem and Total Addressable Market (TAM)',
            type: 'video',
            durationMinutes: 30,
            contentUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
          }
        ]
      }
    ]
  },
  {
    id: 'crs-data-05',
    title: 'Applied Data Science & Machine Learning for Social Impact',
    titleSo: 'Sayniska Xogta & Caqliga Macmalka ah (AI)',
    code: 'SIHUB-DATA-401',
    category: 'Data & AI',
    description: 'Analyze demographic surveys, satellite drought telemetry, and economic indicators using Python, Pandas, and machine learning models for humanitarian and developmental decision-making.',
    descriptionSo: 'Baro falanqaynta xogta baaxadda leh iyo caqliga macmalka ah ee loo isticmaalo go’aan qaadashada horumarka.',
    instructorId: 'usr-admin-1',
    instructorName: 'Eng. Abdullahi Warsame',
    instructorTitle: 'Data Systems Lead',
    durationWeeks: 10,
    hoursPerWeek: 7,
    level: 'Advanced',
    deliveryMode: 'Online',
    capacity: 40,
    enrolledCount: 29,
    thumbnailUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&auto=format&fit=crop&q=80',
    prerequisites: ['Python basics', 'Fundamental statistics'],
    learningOutcomes: [
      'Clean and visualize multi-dimensional geospatial data',
      'Train predictive models for climate and agricultural yields',
      'Build dashboards with interactive analytics'
    ],
    isPublished: true,
    createdAt: '2026-03-01T00:00:00Z',
    modules: []
  },
  {
    id: 'crs-health-06',
    title: 'Community Healthcare Tech & Telemedicine Systems',
    titleSo: 'Tiknolojiyadda Caafimaadka & Daaweynta Meel-fog (Telemedicine)',
    code: 'SIHUB-HEALTH-105',
    category: 'Health & MedTech',
    description: 'Design mobile healthcare record systems, SMS alert frameworks for maternal health, and low-bandwidth video consultations for remote rural clinics.',
    descriptionSo: 'Barnaamijyada dijitaalka ah ee caafimaadka hooyada iyo dhallaanka iyo la xiriiridda dhakhaatiirta meel fog.',
    instructorId: 'usr-instructor-1',
    instructorName: 'Dr. Hassan Ali Geedi',
    instructorTitle: 'Health Systems Fellow',
    durationWeeks: 8,
    hoursPerWeek: 5,
    level: 'Beginner',
    deliveryMode: 'Online',
    capacity: 35,
    enrolledCount: 22,
    thumbnailUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=600&auto=format&fit=crop&q=80',
    prerequisites: ['General interest in public health, nursing, or tech'],
    learningOutcomes: [
      'Understand digital patient health confidentiality standards',
      'Deploy offline-first mobile forms for remote health workers',
      'Implement maternal immunization reminder pipelines'
    ],
    isPublished: true,
    createdAt: '2026-03-10T00:00:00Z',
    modules: []
  }
];

export const INITIAL_ENROLLMENTS: Enrollment[] = [
  {
    id: 'enr-demo-1',
    courseId: 'crs-fullstack-01',
    courseTitle: 'Full-Stack Web & Mobile Software Engineering',
    userId: 'usr-learner-1',
    userName: 'Hodan Mohamed Barre',
    userEmail: 'hodan.barre@student.so',
    userPhone: '+252 61 432 7891',
    motivation: 'I am completing my final year in computer science and want to build modern tech platforms for Somali youth and schools.',
    status: 'approved',
    progressPercent: 45,
    appliedAt: '2026-09-12T10:00:00Z',
    reviewedAt: '2026-09-14T09:30:00Z',
    reviewerId: 'usr-admin-1',
    completedLessonIds: ['les-tech-1-1', 'les-tech-1-2'],
    quizScores: { 'les-tech-1-4': 100 },
    certificateIssued: false
  },
  {
    id: 'enr-demo-2',
    courseId: 'crs-solar-02',
    courseTitle: 'Renewable Energy Systems & Solar Mini-Grids',
    userId: 'usr-learner-1',
    userName: 'Hodan Mohamed Barre',
    userEmail: 'hodan.barre@student.so',
    userPhone: '+252 61 432 7891',
    motivation: 'I want to integrate IoT sensors into clean solar mini-grids in rural regions.',
    status: 'pending',
    progressPercent: 0,
    appliedAt: '2026-11-01T08:15:00Z',
    completedLessonIds: []
  },
  {
    id: 'enr-demo-3',
    courseId: 'crs-agri-03',
    courseTitle: 'AgriTech & Climate-Smart Farming in Arid Zones',
    userId: 'usr-community-1',
    userName: 'Jama Duale Samatar',
    userEmail: 'jama.samatar@community.so',
    userPhone: '+252 61 999 1122',
    motivation: 'I work with young farmers in Baidoa who face recurring drought. Need modern drip irrigation methods.',
    status: 'pending',
    progressPercent: 0,
    appliedAt: '2026-11-01T15:20:00Z',
    completedLessonIds: []
  },
  {
    id: 'enr-demo-4',
    courseId: 'crs-startup-04',
    courseTitle: 'Digital Entrepreneurship & Venture Building in Emerging Markets',
    userId: 'usr-founder-1',
    userName: 'Abdirahman Farah',
    userEmail: 'abdirahman@geeltech.so',
    userPhone: '+252 61 777 4433',
    motivation: 'Scaling my camel milk cold-chain startup to international trade and need better financial models.',
    status: 'approved',
    progressPercent: 80,
    appliedAt: '2026-08-01T10:00:00Z',
    reviewedAt: '2026-08-03T11:00:00Z',
    reviewerId: 'usr-admin-1',
    completedLessonIds: ['les-ven-1-1'],
    certificateIssued: true,
    certificateDate: '2026-10-15',
    certificateNumber: 'SIHUB-CERT-2026-8891'
  }
];

export const INITIAL_STARTUPS: Startup[] = [
  {
    id: 'stp-geeltech',
    name: 'GeelTech Solutions',
    tagline: 'Solar-powered cold chain and IoT milk quality tracking for pastoralists.',
    sector: 'AgriTech',
    founderName: 'Abdirahman Farah',
    founderEmail: 'abdirahman@geeltech.so',
    founderPhone: '+252 61 777 4433',
    teamSize: 7,
    stage: 'Incubation',
    description: 'GeelTech builds decentralized solar milk chillers placed at pastoral gathering hubs, equipped with mobile money payouts and rapid bacterial testing kits to reduce spoilage from 40% to under 4%.',
    problemStatement: 'Over 40% of fresh camel and cow milk in Somalia spoils during transport before reaching urban centers due to lack of electricity and refrigeration.',
    solution: 'Modular, pay-as-you-chill solar stations that instantly test, chill, and bulk-store milk with automated EVC Plus SMS payments to nomadic herders.',
    fundingRaised: '$45,000 (SiHub Seed + Angel)',
    location: 'Garowe & Mudug Region',
    logoUrl: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?w=150&auto=format&fit=crop&q=80',
    incubationCohort: 'Cohort 4 - 2025',
    mentorAssigned: 'Zahra Osman Guled',
    status: 'active',
    appliedDate: '2025-04-10'
  },
  {
    id: 'stp-banaadirsolar',
    name: 'Banaadir Smart Solar',
    tagline: 'Pay-as-you-go clean electricity for peri-urban micro-enterprises.',
    sector: 'CleanTech / Energy',
    founderName: 'Ilhan Yusuf Kahiye',
    founderEmail: 'ilhan@banaadirsolar.so',
    founderPhone: '+252 61 555 8821',
    teamSize: 5,
    stage: 'Acceleration',
    description: 'Deploying smart prepaid solar rooftop systems for neighborhood tailors, bakeries, and mobile charging kiosks with zero upfront installation costs.',
    problemStatement: 'Grid diesel electricity in Mogadishu is among the most expensive in the world ($0.45 - $0.65/kWh), crippling small shops.',
    solution: 'Lease-to-own solar inverters with automated GSM daily token activation via mobile wallets.',
    fundingRaised: '$75,000',
    location: 'Mogadishu (Wadajir & Hodan)',
    logoUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=150&auto=format&fit=crop&q=80',
    incubationCohort: 'Cohort 3 - 2024',
    mentorAssigned: 'Dr. Hassan Ali Geedi',
    status: 'active',
    appliedDate: '2024-08-15'
  },
  {
    id: 'stp-hilaachealth',
    name: 'Hilaac Health Telemedicine',
    tagline: 'Connecting remote maternal health clinics with specialist doctors.',
    sector: 'HealthTech',
    founderName: 'Dr. Amina Guled',
    founderEmail: 'amina@hilaachealth.so',
    founderPhone: '+252 61 334 9911',
    teamSize: 8,
    stage: 'Growth / Scale',
    description: 'Low-bandwidth video & digital ultrasound transmission linking rural mid-wives to Mogadishu and Hargeisa referral hospitals.',
    problemStatement: 'Severe maternal mortality rates exacerbated by 300+ km distances to obstetric specialists.',
    solution: 'Solar-powered backpack telemetry kits and offline-first mobile app for prenatal triage.',
    fundingRaised: '$120,000 (Grants + Series Seed)',
    location: 'Hargeisa & Burao',
    logoUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=150&auto=format&fit=crop&q=80',
    incubationCohort: 'Cohort 2 - 2024',
    mentorAssigned: 'Zahra Osman Guled',
    status: 'graduated',
    appliedDate: '2024-02-18'
  },
  {
    id: 'stp-kalkaal-edtech',
    name: 'Kalkaal STEM & Robotics',
    tagline: 'Somali-language interactive kits and coding platforms for high schools.',
    sector: 'EdTech',
    founderName: 'Mukhtar Dahir',
    founderEmail: 'mukhtar@kalkaal.so',
    founderPhone: '+252 61 661 7733',
    teamSize: 4,
    stage: 'Incubation',
    description: 'Affordable hardware breadboard kits and gamified coding software translated into Somali language to ignite young engineers.',
    problemStatement: 'Schools lack physical computer labs and accessible vernacular engineering curriculum.',
    solution: 'Plug-and-play microcomputer modules that run off 12V solar batteries without internet.',
    fundingRaised: '$25,000',
    location: 'Mogadishu & Kismayo',
    logoUrl: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=150&auto=format&fit=crop&q=80',
    incubationCohort: 'Cohort 5 - 2026',
    mentorAssigned: 'Eng. Abdullahi Warsame',
    status: 'active',
    appliedDate: '2026-01-05'
  },
  {
    id: 'stp-daryeelwaste',
    name: 'Daryeel Circular Plastics',
    tagline: 'Upcycling municipal plastic waste into eco-friendly interlocking paving bricks.',
    sector: 'CleanTech / Energy',
    founderName: 'Nasra Jama Egal',
    founderEmail: 'nasra@daryeelplastic.so',
    founderPhone: '+252 61 884 1120',
    teamSize: 12,
    stage: 'Ideation',
    description: 'Transforming discarded HDPE plastic containers and bags mixed with sand into zero-cement construction paving tiles.',
    problemStatement: 'Severe plastic pollution in coastal towns and high costs of imported concrete paving materials.',
    solution: 'Community plastic collection points combined with mechanical thermal extruders producing heavy-duty pavers.',
    fundingRaised: '$15,000',
    location: 'Kismayo',
    logoUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=150&auto=format&fit=crop&q=80',
    incubationCohort: 'Under Review',
    status: 'under_review',
    appliedDate: '2026-10-25'
  }
];

export const INITIAL_INNOVATION_PROJECTS: InnovationProject[] = [
  {
    id: 'prj-water-iot',
    title: 'Smart Deep-Well IoT Telemetry Network',
    sector: 'Agriculture',
    leadResearcher: 'Eng. Osman Shire',
    organizationOrTeam: 'SiHub AgriTech & Water Consortium',
    description: 'Autonomous solar-powered ultrasound sensors installed inside deep boreholes across Galmudug and Hirshabelle to forecast aquifer depletion and water salinity in real time.',
    objectives: [
      'Equip 50 boreholes with low-power satellite/GSM telemetry',
      'Provide open dashboard to Ministry of Water & humanitarian actors',
      'Prevent catastrophic pump burnouts through early dry-run cutoffs'
    ],
    status: 'Pilot Tested',
    location: 'Beledweyne & Dusamareb',
    beneficiariesCount: 45000,
    budgetEstimated: '$65,000',
    startDate: '2025-03-01',
    milestones: [
      { title: 'Sensor prototype benchmarked in lab', completed: true, dueDate: '2025-06-01' },
      { title: 'Deployment across first 20 pilot boreholes', completed: true, dueDate: '2025-11-15' },
      { title: 'Full multi-regional telemetry dashboard public release', completed: false, dueDate: '2026-12-30' }
    ]
  },
  {
    id: 'prj-somali-llm',
    title: 'Open Somali Language Natural Language & Speech Corpus',
    sector: 'Technology',
    leadResearcher: 'Dr. Fatima Mohamed',
    organizationOrTeam: 'SiHub AI & Linguistics Lab',
    description: 'Building high-fidelity open Somali audio-to-text datasets and tokenized language corpora representing northern, central, and Maay dialects for inclusive public AI services.',
    objectives: [
      'Transcribe and align 2,500 hours of verified native Somali speech',
      'Build open-source speech recognition models for illiterate citizens to access health info',
      'Partner with academic institutions for linguistic governance'
    ],
    status: 'In Progress',
    location: 'National / Open Science',
    beneficiariesCount: 120000,
    budgetEstimated: '$80,000',
    startDate: '2025-09-01',
    milestones: [
      { title: 'Ethics & dialect mapping framework approved', completed: true, dueDate: '2025-11-01' },
      { title: 'Collection of 1,000 voice hours completed', completed: true, dueDate: '2026-04-01' },
      { title: 'Public HuggingFace model weights release', completed: false, dueDate: '2026-12-15' }
    ]
  },
  {
    id: 'prj-fish-coldchain',
    title: 'Zero-Emission Coastal Cold Storage for Artisanal Fisherfolk',
    sector: 'Environment',
    leadResearcher: 'Capt. Dahir Rageh',
    organizationOrTeam: 'Maritime Green Energy Lab',
    description: 'Off-grid seawater ice slurry generators powered by hybrid wind-solar systems allowing coastal fishermen to chill catches immediately at sea.',
    objectives: [
      'Eliminate diesel generator dependence on coastal fish docks',
      'Boost artisanal fishermen export value by 60%',
      'Reduce post-harvest fish spoilage to near zero'
    ],
    status: 'Concept',
    location: 'Hobyo & Bosaso',
    beneficiariesCount: 18000,
    budgetEstimated: '$95,000',
    startDate: '2026-02-01',
    milestones: [
      { title: 'Thermal calculation & wind resource assessment', completed: true, dueDate: '2026-05-01' },
      { title: 'Fabrication of prototype ice-slurry unit', completed: false, dueDate: '2026-11-01' }
    ]
  },
  {
    id: 'prj-nomad-health',
    title: 'Mobile Solar Vaccination Carriers with Cold-Chain GPS',
    sector: 'Health',
    leadResearcher: 'Dr. Marian Hussein',
    organizationOrTeam: 'Kalkaal Health & SiHub Labs',
    description: 'Lightweight portable thermoelectric cooling boxes mounted on motorcycles and camels maintaining 2°C - 8°C for measles, polio, and maternal tetanus vaccines.',
    objectives: [
      'Reach pastoralist migration corridors with viable vaccines',
      'Live GPS and temperature telemetry via satellite micro-bursts',
      'Train 150 community health outreach workers'
    ],
    status: 'Pilot Tested',
    location: 'Sool, Sanaag & Mudug',
    beneficiariesCount: 32000,
    budgetEstimated: '$50,000',
    startDate: '2025-07-01',
    milestones: [
      { title: 'Lab testing under 45°C ambient heat', completed: true, dueDate: '2025-09-01' },
      { title: 'Field trial with 50 nomadic camps', completed: true, dueDate: '2026-03-01' }
    ]
  }
];

export const INITIAL_PROGRAMS: Program[] = [
  {
    id: 'prg-flagship-2026',
    title: 'SiHub Flagship Incubation Program 2026',
    titleSo: 'Barnaamijka Kobcinta Ganacsiyada Cusub 2026',
    category: 'Incubation',
    summary: 'A rigorous 6-month hands-on venture acceleration cohort for high-potential technology, agriculture, and clean energy startups across Somalia.',
    summarySo: 'Barnaamij 6 bilood ah oo lagu taageerayo shirkadaha cusub ee dhanka tignoolojiyada, beeraha iyo tamarta nadiifka ah.',
    objectives: [
      'Provide $10,000 equity-free pilot grant per accepted startup',
      'Dedicated international and diaspora mentor matchmaking',
      'Free office workspace, high-speed fiber, and lab facilities at SiHub'
    ],
    targetAudience: 'Early-stage founders with an MVP or functional prototype',
    duration: '6 Months (Intensive)',
    eligibility: [
      'Registered or registerable startup in Somalia',
      'At least two full-time co-founders',
      'Demonstrated prototype or paying pilot customers'
    ],
    cohortSize: 15,
    status: 'Open',
    deadline: '2026-12-15',
    coordinator: 'Sharmarke Abdi Liban',
    thumbnailUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'prg-switi-women',
    title: 'SWITI: Somali Women in Tech & Innovation',
    titleSo: 'SWITI: Haweenka Soomaaliyeed ee Tignoolajiyada & Hal-abuurka',
    category: 'Women in Innovation',
    summary: 'Empowering female software developers, researchers, and digital entrepreneurs through certified skill tracks, executive leadership coaching, and seed grants.',
    summarySo: 'Barnaamij gaar ah oo lagu kobcinayo gabdhaha baranaya cilmiga kumbuyuutarka iyo hal-abuurka ganacsi.',
    objectives: [
      'Train 250 female engineers in modern web & cloud architectures',
      'Incubate 20 women-led social enterprises',
      'Create peer circles and international leadership fellowships'
    ],
    targetAudience: 'Female tech graduates, digital creators, and entrepreneurs',
    duration: '4 Months',
    eligibility: [
      'Female candidates residing in any Somali federal state',
      'Commitment to attend weekly sessions and complete capstone'
    ],
    cohortSize: 30,
    status: 'Open',
    deadline: '2026-11-30',
    coordinator: 'Khadija Yusuf Noor',
    thumbnailUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'prg-agri-seed',
    title: 'Agrinnovation Seed Fund & Mentorship Challenge',
    titleSo: 'Tartan Maalgashi Hal-abuurka Beeraha & Xoolaha',
    category: 'Seed Grant',
    summary: 'A catalytic innovation challenge matching rural agricultural pioneers with technical mentors, satellite analytics, and micro-grants.',
    summarySo: 'Maalgashi iyo taageero farsamo oo loogu talagalay dhalinyarada horumarinaysa beeraha iyo xoolaha.',
    objectives: [
      'Fund scalable water efficiency and crop value chain innovations',
      'Connect smallholders with national supermarket supply chains'
    ],
    targetAudience: 'Farmers, agronomists, university student teams',
    duration: '3 Months',
    eligibility: ['Focus on food security, drought resilience, or livestock cold-chain'],
    cohortSize: 20,
    status: 'In Progress',
    deadline: '2026-10-01',
    coordinator: 'Dr. Hassan Ali Geedi',
    thumbnailUrl: 'https://images.unsplash.com/photo-1586771107445-d3ca888129ff?w=600&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_EVENTS: Event[] = [
  {
    id: 'evt-summit-2026',
    title: 'Somalia Annual Innovation Summit 2026',
    category: 'Conference',
    date: '2026-11-25',
    time: '08:30 AM - 05:30 PM (EAT)',
    locationType: 'Hybrid',
    venue: 'SiHub Grand Auditorium, KM4 Airport Road, Mogadishu & Live Virtual Stream',
    description: 'The premier national gathering of innovators, diaspora angel investors, ministers, university chancellors, and startup founders exploring sovereign digital transformation.',
    capacity: 400,
    registeredCount: 312,
    speaker: 'HE Minister of Communications, Diaspora Leaders & Global Tech Executives',
    isUpcoming: true,
    qrCodeSample: 'SIHUB-CONF-2026-MOG'
  },
  {
    id: 'evt-hack-climate',
    title: 'Horn of Africa Climate Resilience Hackathon',
    category: 'Hackathon',
    date: '2026-12-05',
    time: '48 Hours (Continuous)',
    locationType: 'In-Person',
    venue: 'SiHub MakerSpace & Innovation Lab, Mogadishu',
    description: '48-hour sprint to build low-power IoT water level monitors, weather SMS bots, and emergency animal feed logistics applications.',
    capacity: 100,
    registeredCount: 84,
    speaker: 'Eng. Abdullahi Warsame & UNDP Climate Lab Specialists',
    isUpcoming: true,
    qrCodeSample: 'SIHUB-HACK-2026-CLIM'
  },
  {
    id: 'evt-pitch-day',
    title: 'SiHub Venture Pitch & Angel Demo Day',
    category: 'Demo Day',
    date: '2026-12-18',
    time: '02:00 PM - 06:00 PM (EAT)',
    locationType: 'Hybrid',
    venue: 'Jazeera Palace Hotel & Zoom Global Webinar',
    description: 'Ten graduated SiHub startups pitch to an accredited syndicate of Somali diaspora business owners, venture capitalists, and impact donors.',
    capacity: 150,
    registeredCount: 110,
    speaker: 'Sharmarke Abdi Liban & Zahra Osman Guled',
    isUpcoming: true,
    qrCodeSample: 'SIHUB-PITCH-2026-INV'
  }
];

export const INITIAL_MENTORS: Mentor[] = [
  {
    id: 'mnt-zahra',
    name: 'Zahra Osman Guled',
    title: 'General Partner & Strategy Lead',
    organization: 'Somali Diaspora Angels',
    expertise: ['Venture Capital Pitching', 'Cross-border Payments', 'Scale-up Strategy', 'Product Management'],
    sectors: ['Fintech', 'AgriTech', 'E-commerce'],
    bio: 'Former senior product manager in European fintech, now investing and mentoring early-stage ventures across the Horn of Africa.',
    availableHoursPerMonth: 8,
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
    rating: 4.9,
    totalMenteesHelped: 38
  },
  {
    id: 'mnt-abdullahi',
    name: 'Eng. Abdullahi Warsame',
    title: 'Chief Technology Architect',
    organization: 'Somali Innovation Hub',
    expertise: ['Cloud Architecture', 'Distributed Systems', 'PostgreSQL & ORM', 'Cybersecurity Foundations'],
    sectors: ['Software', 'GovTech', 'EdTech'],
    bio: 'Enterprise systems specialist who has architected national registries and high-volume merchant platforms.',
    availableHoursPerMonth: 12,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    rating: 5.0,
    totalMenteesHelped: 64
  },
  {
    id: 'mnt-hassan',
    name: 'Dr. Hassan Ali Geedi',
    title: 'Director of Renewable Technology',
    organization: 'East Africa Clean Energy Institute',
    expertise: ['Solar Microgrids', 'Hardware Prototyping', 'Grant Proposals', 'Thermal Engineering'],
    sectors: ['CleanTech / Energy', 'AgriTech', 'Hardware / IoT'],
    bio: 'PhD in Mechanical Engineering, specialist in extreme climate electronics and off-grid irrigation.',
    availableHoursPerMonth: 6,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    rating: 4.8,
    totalMenteesHelped: 29
  }
];

export const INITIAL_OPPORTUNITIES: Opportunity[] = [
  {
    id: 'opp-grant-01',
    title: 'SiHub Climate & Food Security Catalytic Grant ($15,000)',
    type: 'Grant',
    provider: 'Somali Innovation Hub & International Development Fund',
    location: 'All Federal Member States',
    deadline: '2026-12-10',
    amountOrStipend: '$15,000 Equity-Free',
    description: 'Direct capital grants for registered youth and female innovators deploying hardware or digital solutions that mitigate food insecurity and drought vulnerability.',
    eligibility: ['Operational in Somalia for > 6 months', 'Clear community beneficiary impact metrics'],
    status: 'Open',
    applicantsCount: 68
  },
  {
    id: 'opp-scholar-02',
    title: 'SiHub Future Software Engineers Fellowship 2026',
    type: 'Scholarship',
    provider: 'SiHub Academy & Diaspora Tech Coalition',
    location: 'Online / Hybrid',
    deadline: '2026-11-20',
    amountOrStipend: '100% Tuition + Laptop & Internet Subsidy',
    description: 'Fully funded 6-month software engineering scholarship program including dedicated industry mentor and job placement support upon completion.',
    eligibility: ['Young adults aged 18-30', 'Pass technical logic and aptitude assessment'],
    status: 'Open',
    applicantsCount: 142
  },
  {
    id: 'opp-intern-03',
    title: 'Full-Stack Developer Internship (SiHub Innovation Lab)',
    type: 'Internship',
    provider: 'Somali Innovation Hub',
    location: 'Mogadishu Headquarters',
    deadline: '2026-11-15',
    amountOrStipend: '$400 / Month Stipend',
    description: '6-month paid residency working on core SiHub digital public goods, community portals, and IoT telemetry dashboards.',
    eligibility: ['Experience with React, TypeScript, and modern Git workflows'],
    status: 'Open',
    applicantsCount: 53
  }
];

export const INITIAL_PARTNERS: Partner[] = [
  {
    id: 'ptn-undp',
    name: 'UNDP Somalia Accelerator Labs',
    type: 'Development Agency',
    country: 'International / Somalia',
    collaborativePrograms: ['Youth Agrinnovation Lab', 'Horn Climate Hackathon', 'SWITI Cohort 2'],
    mouStatus: 'Active',
    contactPerson: 'Marcus Lindqvist, Head of Exploration',
    joinedYear: 2022
  },
  {
    id: 'ptn-ministry',
    name: 'Ministry of Communications & Technology (Somalia)',
    type: 'Institutional',
    country: 'Somalia',
    collaborativePrograms: ['National Digital Skills Initiative', 'GovTech Sandbox'],
    mouStatus: 'Active',
    contactPerson: 'Director General Office',
    joinedYear: 2021
  },
  {
    id: 'ptn-hormuud',
    name: 'Hormuud Telecom Foundation',
    type: 'Corporate Sponsor',
    country: 'Somalia',
    collaborativePrograms: ['SiHub Connectivity Sponsorship', 'Mobile Money API Sandbox'],
    mouStatus: 'Active',
    contactPerson: 'Corporate CSR & Tech Partnerships',
    joinedYear: 2023
  },
  {
    id: 'ptn-simad',
    name: 'SIMAD University Innovation & Incubation Center',
    type: 'Academic',
    country: 'Somalia',
    collaborativePrograms: ['Joint Student Capstone Residency', 'Academic Research Exchange'],
    mouStatus: 'Active',
    contactPerson: 'Dean of Computing & Information Tech',
    joinedYear: 2022
  }
];

export const INITIAL_COMMUNITY_MEMBERS: CommunityMember[] = [
  { id: 'cm-1', name: 'Asha Nur Shire', sectorInterest: 'AgriTech & Climate', city: 'Mogadishu', contributionsCount: 24, joinedDate: '2025-02-10', isAmbassador: true },
  { id: 'cm-2', name: 'Khalid Bashir', sectorInterest: 'Software & Open Source', city: 'Hargeisa', contributionsCount: 18, joinedDate: '2025-05-18', isAmbassador: false },
  { id: 'cm-3', name: 'Safia Abdikadir', sectorInterest: 'Women in Tech', city: 'Garowe', contributionsCount: 31, joinedDate: '2024-11-04', isAmbassador: true },
  { id: 'cm-4', name: 'Guled Abshir', sectorInterest: 'Renewable Solar', city: 'Baidoa', contributionsCount: 9, joinedDate: '2026-01-14', isAmbassador: false },
  { id: 'cm-5', name: 'Muna Dahir', sectorInterest: 'Healthcare Tech', city: 'Kismayo', contributionsCount: 15, joinedDate: '2025-09-02', isAmbassador: false }
];

export const INITIAL_FORUM_TOPICS: ForumTopic[] = [
  {
    id: 'top-1',
    title: 'How are you handling high-temperature battery life in Somali solar installations?',
    author: 'Eng. Osman Shire',
    category: 'Renewable Energy',
    repliesCount: 14,
    likesCount: 29,
    createdAt: '2026-10-28T14:00:00Z',
    content: 'We noticed lead-acid cycles degrade rapidly when ambient shed temperatures exceed 38°C in Beledweyne. Has anyone transitioned to LiFePO4 with active airflow shade structures?'
  },
  {
    id: 'top-2',
    title: 'Best open-source tools for building offline-first PWA forms for remote field workers?',
    author: 'Hodan Mohamed Barre',
    category: 'Software Engineering',
    repliesCount: 21,
    likesCount: 43,
    createdAt: '2026-10-30T09:30:00Z',
    content: 'Working on a maternal survey tool for areas where 4G drops frequently. We are experimenting with IndexedDB and Background Sync.'
  },
  {
    id: 'top-3',
    title: 'Diaspora angel investors: What metrics do you prioritize for early Somali startups?',
    author: 'Abdirahman Farah',
    category: 'Entrepreneurship',
    repliesCount: 18,
    likesCount: 37,
    createdAt: '2026-11-01T11:20:00Z',
    content: 'Is unit economics and cash flow break-even favored over rapid user acquisition in low-margin logistics?'
  }
];

export const INITIAL_NEWS: NewsArticle[] = [
  {
    id: 'news-1',
    title: 'SiHub Launches Cohort 5 with 15 Groundbreaking Startups Across Agriculture and Energy',
    titleSo: 'SiHub oo Daahfurtay Dufcadda 5-aad ee Shirkadaha Cusub',
    category: 'Announcement',
    author: 'SiHub Communications Bureau',
    publishedAt: '2026-10-20',
    readTime: '4 min read',
    summary: 'Selected from over 180 applicants across all federal member states, the new cohort represents pioneering solutions in camel milk cold chains, decentralized solar grids, and Somali language STEM kits.',
    content: 'Somali Innovation Hub (SiHub) is proud to announce the commencement of its 2026 Flagship Incubation Cohort. Over the next six months, each venture will receive equity-free seed grants, intensive mentoring, workspace, and access to the regional investor syndicate.',
    coverImage: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=80'
  },
  {
    id: 'news-2',
    title: 'Case Study: How GeelTech Saved Over 120,000 Liters of Fresh Milk in Central Regions',
    titleSo: 'Daraasad: Sida GeelTech u Badbaadisay Caano Badan',
    category: 'Success Story',
    author: 'Innovation Research Desk',
    publishedAt: '2026-10-05',
    readTime: '6 min read',
    summary: 'By deploying solar-powered bulk chilling stations with instant mobile money disbursements, GeelTech has dramatically boosted pastoralist incomes.',
    content: 'Pastoral communities in Mudug region historically lost nearly half their evening milk yield to overnight spoilage. GeelTech installed solar-powered micro-chillers at watering hubs, creating steady income for 450+ families.',
    coverImage: 'https://images.unsplash.com/photo-1527153857715-3908f2ae5e81?w=800&auto=format&fit=crop&q=80'
  },
  {
    id: 'news-3',
    title: 'Whitepaper: Digital Infrastructure & Clean Energy Pathways for Somalia 2026-2035',
    titleSo: 'Warbixin Cilmiyeed: Kaabayaasha Dijitaalka & Tamarta Nadiifka ah',
    category: 'Impact Report',
    author: 'SiHub Policy & Research Lab',
    publishedAt: '2026-09-18',
    readTime: '12 min read',
    summary: 'A joint policy publication detailing regulatory recommendations, telecom spectrum sandboxes, and green mini-grid tariff frameworks.',
    content: 'SiHub, in collaboration with national research fellows and development partners, has published an in-depth 48-page strategy document outlining the economic multiplier effect of community digital centers.',
    coverImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_IMPACT_METRICS: ImpactMetrics = {
  totalBeneficiaries: 184500,
  learnersTrained: 3420,
  coursesDelivered: 48,
  startupsSupported: 86,
  jobsCreatedDirectly: 720,
  grantsDisbursedUSD: 460000,
  womenParticipationRate: 44, // 44%
  innovationProjectsCompleted: 24,
  partnerOrganizations: 32
};

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    timestamp: '2026-11-02T06:15:00Z',
    userId: 'usr-admin-1',
    userName: 'Eng. Abdullahi Warsame',
    action: 'REVIEW_ENROLLMENT',
    module: 'LMS / Education',
    details: 'Approved enrollment application for Hodan Mohamed Barre in SIHUB-TECH-101'
  },
  {
    id: 'log-2',
    timestamp: '2026-11-01T16:00:00Z',
    userId: 'usr-progmanager-1',
    userName: 'Sharmarke Abdi Liban',
    action: 'COHORT_UPDATE',
    module: 'Startup Hub',
    details: 'Advanced GeelTech Solutions to Incubation Milestone 3 (Financial Audit)'
  },
  {
    id: 'log-3',
    timestamp: '2026-11-01T10:30:00Z',
    userId: 'usr-admin-1',
    userName: 'Eng. Abdullahi Warsame',
    action: 'COURSE_PUBLISH',
    module: 'LMS / Education',
    details: 'Published new course: Renewable Energy Systems & Solar Mini-Grids'
  }
];
