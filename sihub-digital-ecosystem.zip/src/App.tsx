/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Master Application Entry Point
 * Comprehensive interactive website, administration console & role demonstration system.
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';

// Common Components
import { RoleSwitcherBar } from './components/common/RoleSwitcherBar';
import { ToastContainer } from './components/common/ToastContainer';

// Public Pages & Navigation
import { Header } from './components/public/Header';
import { Footer } from './components/public/Footer';
import { Home } from './components/public/Home';
import { About } from './components/public/About';
import { ProgramsPage } from './components/public/ProgramsPage';
import { CoursesPage } from './components/public/CoursesPage';
import { StartupHubPage } from './components/public/StartupHubPage';
import { InnovationLabPage } from './components/public/InnovationLabPage';
import { CommunityPage } from './components/public/CommunityPage';
import { EventsPage } from './components/public/EventsPage';
import { OpportunitiesPage } from './components/public/OpportunitiesPage';
import { MentorshipPage } from './components/public/MentorshipPage';
import { PartnershipsPage } from './components/public/PartnershipsPage';
import { NewsPage } from './components/public/NewsPage';
import { ContactPage } from './components/public/ContactPage';

// Admin Modules
import { AdminLayout } from './components/admin/AdminLayout';
import { AdminOverview } from './components/admin/AdminOverview';
import { AdminUsers } from './components/admin/AdminUsers';
import { AdminLMS } from './components/admin/AdminLMS';
import { AdminStartups } from './components/admin/AdminStartups';
import { AdminInnovation } from './components/admin/AdminInnovation';
import { AdminPrograms } from './components/admin/AdminPrograms';
import { AdminCommunity } from './components/admin/AdminCommunity';
import { AdminEvents } from './components/admin/AdminEvents';
import { AdminMentorship } from './components/admin/AdminMentorship';
import { AdminOpportunities } from './components/admin/AdminOpportunities';
import { AdminPartnerships } from './components/admin/AdminPartnerships';
import { AdminContent } from './components/admin/AdminContent';
import { AdminImpact } from './components/admin/AdminImpact';
import { AdminAI } from './components/admin/AdminAI';
import { AdminSettings } from './components/admin/AdminSettings';

// Dedicated Role Dashboards
import { LearnerDashboard } from './components/portals/LearnerDashboard';
import { InstructorDashboard } from './components/portals/InstructorDashboard';
import { StartupDashboard } from './components/portals/StartupDashboard';
import { MentorDashboard } from './components/portals/MentorDashboard';
import { PartnerDashboard } from './components/portals/PartnerDashboard';

// Interactive Modals & Assistant
import { ApplyCourseModal } from './components/modals/ApplyCourseModal';
import { CoursePlayerModal } from './components/modals/CoursePlayerModal';
import { PitchStartupModal } from './components/modals/PitchStartupModal';
import { EventRegisterModal } from './components/modals/EventRegisterModal';
import { SiHubAIAssistant } from './components/ai/SiHubAIAssistant';

const AppContent: React.FC = () => {
  const { currentView, adminTab } = useApp();

  const renderAdminModule = () => {
    switch (adminTab) {
      case 'overview': return <AdminOverview />;
      case 'users': return <AdminUsers />;
      case 'lms': return <AdminLMS />;
      case 'startups': return <AdminStartups />;
      case 'innovation': return <AdminInnovation />;
      case 'programs': return <AdminPrograms />;
      case 'community': return <AdminCommunity />;
      case 'events': return <AdminEvents />;
      case 'mentorship': return <AdminMentorship />;
      case 'opportunities': return <AdminOpportunities />;
      case 'partnerships': return <AdminPartnerships />;
      case 'content': return <AdminContent />;
      case 'impact': return <AdminImpact />;
      case 'ai': return <AdminAI />;
      case 'settings': return <AdminSettings />;
      default: return <AdminOverview />;
    }
  };

  const renderPublicView = () => {
    switch (currentView) {
      case 'home': return <Home />;
      case 'about': return <About />;
      case 'programs': return <ProgramsPage />;
      case 'courses': return <CoursesPage />;
      case 'startups': return <StartupHubPage />;
      case 'innovation': return <InnovationLabPage />;
      case 'community': return <CommunityPage />;
      case 'events': return <EventsPage />;
      case 'opportunities': return <OpportunitiesPage />;
      case 'mentorship': return <MentorshipPage />;
      case 'partnerships': return <PartnershipsPage />;
      case 'news': return <NewsPage />;
      case 'contact': return <ContactPage />;
      case 'learner_portal': return <LearnerDashboard />;
      case 'instructor_portal': return <InstructorDashboard />;
      case 'startup_portal': return <StartupDashboard />;
      case 'mentor_portal': return <MentorDashboard />;
      case 'partner_portal': return <PartnerDashboard />;
      default: return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-cyan-500 selection:text-white">
      {/* Top Demo Banner: Persona Switcher, Language & Reset */}
      <RoleSwitcherBar />

      {/* Main View: Admin Console OR Public Institutional Website */}
      {currentView === 'admin' ? (
        <AdminLayout>
          {renderAdminModule()}
        </AdminLayout>
      ) : (
        <div className="flex-1 flex flex-col">
          <Header />
          <main className="flex-1">
            {renderPublicView()}
          </main>
          <Footer />
        </div>
      )}

      {/* Modals & AI Assistant Overlays */}
      <ApplyCourseModal />
      <CoursePlayerModal />
      <PitchStartupModal />
      <EventRegisterModal />
      <SiHubAIAssistant />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
