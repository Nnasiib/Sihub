/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Data Storage & Mock Repository Service
 * Persists demo records in localStorage with reactive update dispatches.
 */

import type {
  User,
  Course,
  Enrollment,
  Startup,
  InnovationProject,
  Program,
  SiHubEvent as Event,
  EventRegistration,
  Mentor,
  MentorshipRequest,
  Opportunity,
  Partner,
  CommunityMember,
  ForumTopic,
  NewsArticle,
  ImpactMetrics,
  AuditLog
} from '../types';

import {
  INITIAL_USERS,
  INITIAL_COURSES,
  INITIAL_ENROLLMENTS,
  INITIAL_STARTUPS,
  INITIAL_INNOVATION_PROJECTS,
  INITIAL_PROGRAMS,
  INITIAL_EVENTS,
  INITIAL_MENTORS,
  INITIAL_OPPORTUNITIES,
  INITIAL_PARTNERS,
  INITIAL_COMMUNITY_MEMBERS,
  INITIAL_FORUM_TOPICS,
  INITIAL_NEWS,
  INITIAL_IMPACT_METRICS,
  INITIAL_AUDIT_LOGS
} from '../data/initialData';

const KEYS = {
  USERS: 'sihub_demo_users_v1',
  COURSES: 'sihub_demo_courses_v1',
  ENROLLMENTS: 'sihub_demo_enrollments_v1',
  STARTUPS: 'sihub_demo_startups_v1',
  INNOVATION: 'sihub_demo_innovation_v1',
  PROGRAMS: 'sihub_demo_programs_v1',
  EVENTS: 'sihub_demo_events_v1',
  EVENT_REGISTRATIONS: 'sihub_demo_event_regs_v1',
  MENTORS: 'sihub_demo_mentors_v1',
  MENTORSHIP_REQUESTS: 'sihub_demo_mentorship_reqs_v1',
  OPPORTUNITIES: 'sihub_demo_opportunities_v1',
  PARTNERS: 'sihub_demo_partners_v1',
  COMMUNITY_MEMBERS: 'sihub_demo_community_members_v1',
  FORUM_TOPICS: 'sihub_demo_forum_topics_v1',
  NEWS: 'sihub_demo_news_v1',
  IMPACT: 'sihub_demo_impact_v1',
  AUDIT_LOGS: 'sihub_demo_audit_v1'
};

function getStored<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) {
      localStorage.setItem(key, JSON.stringify(defaultValue));
      return defaultValue;
    }
    return JSON.parse(item) as T;
  } catch {
    return defaultValue;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event('sihub-storage-update'));
  } catch (err) {
    console.error('Failed to persist to localStorage', err);
  }
}

export const StorageService = {
  // Reset all data to factory demo initial state
  resetAllData: () => {
    localStorage.removeItem(KEYS.USERS);
    localStorage.removeItem(KEYS.COURSES);
    localStorage.removeItem(KEYS.ENROLLMENTS);
    localStorage.removeItem(KEYS.STARTUPS);
    localStorage.removeItem(KEYS.INNOVATION);
    localStorage.removeItem(KEYS.PROGRAMS);
    localStorage.removeItem(KEYS.EVENTS);
    localStorage.removeItem(KEYS.EVENT_REGISTRATIONS);
    localStorage.removeItem(KEYS.MENTORS);
    localStorage.removeItem(KEYS.MENTORSHIP_REQUESTS);
    localStorage.removeItem(KEYS.OPPORTUNITIES);
    localStorage.removeItem(KEYS.PARTNERS);
    localStorage.removeItem(KEYS.COMMUNITY_MEMBERS);
    localStorage.removeItem(KEYS.FORUM_TOPICS);
    localStorage.removeItem(KEYS.NEWS);
    localStorage.removeItem(KEYS.IMPACT);
    localStorage.removeItem(KEYS.AUDIT_LOGS);
    window.dispatchEvent(new Event('sihub-storage-update'));
  },

  // USERS
  getUsers: (): User[] => getStored<User[]>(KEYS.USERS, INITIAL_USERS),
  saveUser: (user: User) => {
    const users = StorageService.getUsers();
    const index = users.findIndex(u => u.id === user.id);
    if (index >= 0) {
      users[index] = user;
    } else {
      users.unshift(user);
    }
    setStored(KEYS.USERS, users);
    StorageService.addAuditLog('USER_UPDATE', 'User Management', `Updated user details for ${user.fullName}`);
  },
  toggleUserStatus: (userId: string) => {
    const users = StorageService.getUsers();
    const user = users.find(u => u.id === userId);
    if (user) {
      user.isActive = !user.isActive;
      setStored(KEYS.USERS, users);
      StorageService.addAuditLog('USER_STATUS_CHANGE', 'User Management', `${user.isActive ? 'Reactivated' : 'Suspended'} user ${user.fullName}`);
    }
  },

  // COURSES (LMS)
  getCourses: (): Course[] => getStored<Course[]>(KEYS.COURSES, INITIAL_COURSES),
  getCourseById: (courseId: string): Course | undefined => {
    return StorageService.getCourses().find(c => c.id === courseId);
  },
  saveCourse: (course: Course) => {
    const courses = StorageService.getCourses();
    const index = courses.findIndex(c => c.id === course.id);
    if (index >= 0) {
      courses[index] = course;
    } else {
      courses.unshift(course);
    }
    setStored(KEYS.COURSES, courses);
    StorageService.addAuditLog('SAVE_COURSE', 'LMS', `Saved course: ${course.title}`);
  },
  deleteCourse: (courseId: string) => {
    const courses = StorageService.getCourses().filter(c => c.id !== courseId);
    setStored(KEYS.COURSES, courses);
    StorageService.addAuditLog('DELETE_COURSE', 'LMS', `Deleted course ID: ${courseId}`);
  },
  togglePublishCourse: (courseId: string) => {
    const courses = StorageService.getCourses();
    const course = courses.find(c => c.id === courseId);
    if (course) {
      course.isPublished = !course.isPublished;
      setStored(KEYS.COURSES, courses);
      StorageService.addAuditLog('COURSE_VISIBILITY', 'LMS', `${course.isPublished ? 'Published' : 'Unpublished'} course ${course.title}`);
    }
  },

  // ENROLLMENTS (CRITICAL LMS BUSINESS RULE: ADMIN APPROVAL REQUIRED)
  getEnrollments: (): Enrollment[] => getStored<Enrollment[]>(KEYS.ENROLLMENTS, INITIAL_ENROLLMENTS),
  
  applyCourseEnrollment: (
    course: Course,
    user: User,
    motivation: string,
    phone?: string
  ): Enrollment => {
    const enrollments = StorageService.getEnrollments();
    
    // Check if already applied
    const existing = enrollments.find(e => e.courseId === course.id && e.userId === user.id);
    if (existing) {
      return existing;
    }

    const newEnrollment: Enrollment = {
      id: `enr-${Date.now()}`,
      courseId: course.id,
      courseTitle: course.title,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.email,
      userPhone: phone || user.phone || '+252 61 000 0000',
      motivation: motivation || 'Enthusiastic to master these skills to contribute to Somali innovation.',
      status: 'pending', // IMPORTANT: Pending admin review!
      progressPercent: 0,
      appliedAt: new Date().toISOString(),
      completedLessonIds: []
    };

    enrollments.unshift(newEnrollment);
    setStored(KEYS.ENROLLMENTS, enrollments);

    StorageService.addAuditLog('ENROLLMENT_APPLICATION', 'LMS', `New enrollment submitted by ${user.fullName} for ${course.title}`);
    return newEnrollment;
  },

  approveEnrollment: (enrollmentId: string, reviewerId: string = 'usr-admin-1') => {
    const enrollments = StorageService.getEnrollments();
    const item = enrollments.find(e => e.id === enrollmentId);
    if (item) {
      item.status = 'approved';
      item.reviewedAt = new Date().toISOString();
      item.reviewerId = reviewerId;
      setStored(KEYS.ENROLLMENTS, enrollments);

      // Increment course enrolledCount
      const courses = StorageService.getCourses();
      const course = courses.find(c => c.id === item.courseId);
      if (course) {
        course.enrolledCount += 1;
        setStored(KEYS.COURSES, courses);
      }

      StorageService.addAuditLog('ENROLLMENT_APPROVED', 'LMS', `Approved course enrollment for ${item.userName} in ${item.courseTitle}`);
    }
  },

  rejectEnrollment: (enrollmentId: string, reason: string, reviewerId: string = 'usr-admin-1') => {
    const enrollments = StorageService.getEnrollments();
    const item = enrollments.find(e => e.id === enrollmentId);
    if (item) {
      item.status = 'rejected';
      item.rejectionReason = reason || 'Does not meet cohort prerequisites at this time.';
      item.reviewedAt = new Date().toISOString();
      item.reviewerId = reviewerId;
      setStored(KEYS.ENROLLMENTS, enrollments);

      StorageService.addAuditLog('ENROLLMENT_REJECTED', 'LMS', `Rejected enrollment for ${item.userName}: ${reason}`);
    }
  },

  updateLessonProgress: (enrollmentId: string, lessonId: string, totalLessons: number) => {
    const enrollments = StorageService.getEnrollments();
    const item = enrollments.find(e => e.id === enrollmentId);
    if (item) {
      if (!item.completedLessonIds.includes(lessonId)) {
        item.completedLessonIds.push(lessonId);
      }
      const newPercent = Math.min(100, Math.round((item.completedLessonIds.length / Math.max(1, totalLessons)) * 100));
      item.progressPercent = newPercent;
      
      // Check certificate issuance
      if (newPercent >= 100 && !item.certificateIssued) {
        item.certificateIssued = true;
        item.certificateDate = new Date().toISOString().split('T')[0];
        item.certificateNumber = `SIHUB-CERT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      }

      setStored(KEYS.ENROLLMENTS, enrollments);
    }
  },

  // STARTUPS
  getStartups: (): Startup[] => getStored<Startup[]>(KEYS.STARTUPS, INITIAL_STARTUPS),
  saveStartup: (startup: Startup) => {
    const startups = StorageService.getStartups();
    const index = startups.findIndex(s => s.id === startup.id);
    if (index >= 0) {
      startups[index] = startup;
    } else {
      startups.unshift(startup);
    }
    setStored(KEYS.STARTUPS, startups);
    StorageService.addAuditLog('STARTUP_SAVE', 'Startup Hub', `Saved startup profile: ${startup.name}`);
  },
  updateStartupStatus: (startupId: string, status: Startup['status'], stage?: Startup['stage']) => {
    const startups = StorageService.getStartups();
    const s = startups.find(item => item.id === startupId);
    if (s) {
      s.status = status;
      if (stage) s.stage = stage;
      setStored(KEYS.STARTUPS, startups);
      StorageService.addAuditLog('STARTUP_STATUS_UPDATE', 'Startup Hub', `Updated ${s.name} to ${status} (${stage || s.stage})`);
    }
  },

  // INNOVATION PROJECTS
  getInnovationProjects: (): InnovationProject[] => getStored<InnovationProject[]>(KEYS.INNOVATION, INITIAL_INNOVATION_PROJECTS),
  saveInnovationProject: (proj: InnovationProject) => {
    const list = StorageService.getInnovationProjects();
    const idx = list.findIndex(p => p.id === proj.id);
    if (idx >= 0) {
      list[idx] = proj;
    } else {
      list.unshift(proj);
    }
    setStored(KEYS.INNOVATION, list);
    StorageService.addAuditLog('INNOVATION_SAVE', 'Innovation Lab', `Saved innovation project: ${proj.title}`);
  },

  // PROGRAMS
  getPrograms: (): Program[] => getStored<Program[]>(KEYS.PROGRAMS, INITIAL_PROGRAMS),
  saveProgram: (prog: Program) => {
    const list = StorageService.getPrograms();
    const idx = list.findIndex(p => p.id === prog.id);
    if (idx >= 0) {
      list[idx] = prog;
    } else {
      list.unshift(prog);
    }
    setStored(KEYS.PROGRAMS, list);
    StorageService.addAuditLog('PROGRAM_SAVE', 'Programs', `Saved program: ${prog.title}`);
  },

  // EVENTS & REGISTRATION
  getEvents: (): Event[] => getStored<Event[]>(KEYS.EVENTS, INITIAL_EVENTS),
  saveEvent: (event: Event) => {
    const list = StorageService.getEvents();
    const idx = list.findIndex(e => e.id === event.id);
    if (idx >= 0) {
      list[idx] = event;
    } else {
      list.unshift(event);
    }
    setStored(KEYS.EVENTS, list);
  },
  getEventRegistrations: (): EventRegistration[] => getStored<EventRegistration[]>(KEYS.EVENT_REGISTRATIONS, [
    {
      id: 'reg-demo-1',
      eventId: 'evt-summit-2026',
      eventTitle: 'Somalia Annual Innovation Summit 2026',
      eventDate: '2026-11-25',
      userId: 'usr-learner-1',
      userName: 'Hodan Mohamed Barre',
      userEmail: 'hodan.barre@student.so',
      ticketCode: 'SIHUB-TKT-99120',
      registeredAt: '2026-10-25T10:00:00Z',
      attended: false
    }
  ]),
  registerForEvent: (event: Event, user: User): EventRegistration => {
    const regs = StorageService.getEventRegistrations();
    const existing = regs.find(r => r.eventId === event.id && r.userId === user.id);
    if (existing) return existing;

    const newReg: EventRegistration = {
      id: `reg-${Date.now()}`,
      eventId: event.id,
      eventTitle: event.title,
      eventDate: event.date,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.email,
      ticketCode: `SIHUB-TKT-${Math.floor(10000 + Math.random() * 90000)}`,
      registeredAt: new Date().toISOString(),
      attended: false
    };

    regs.unshift(newReg);
    setStored(KEYS.EVENT_REGISTRATIONS, regs);

    // Increment event registered count
    const events = StorageService.getEvents();
    const e = events.find(item => item.id === event.id);
    if (e) {
      e.registeredCount += 1;
      setStored(KEYS.EVENTS, events);
    }

    StorageService.addAuditLog('EVENT_REGISTRATION', 'Events', `Registered ${user.fullName} for ${event.title}`);
    return newReg;
  },

  // MENTORS & REQUESTS
  getMentors: (): Mentor[] => getStored<Mentor[]>(KEYS.MENTORS, INITIAL_MENTORS),
  getMentorshipRequests: (): MentorshipRequest[] => getStored<MentorshipRequest[]>(KEYS.MENTORSHIP_REQUESTS, [
    {
      id: 'mreq-1',
      mentorId: 'mnt-zahra',
      mentorName: 'Zahra Osman Guled',
      menteeId: 'usr-founder-1',
      menteeName: 'Abdirahman Farah (GeelTech)',
      menteeEmail: 'abdirahman@geeltech.so',
      topic: 'Venture capital valuation models and term sheet review',
      preferredSlot: 'Tuesdays 3:00 PM EAT',
      status: 'accepted',
      scheduledDate: '2026-11-10T12:00:00Z',
      meetingLink: 'https://meet.google.com/sihub-demo-call',
      createdAt: '2026-10-28T09:00:00Z'
    }
  ]),
  requestMentorship: (mentor: Mentor, mentee: User, topic: string, preferredSlot: string) => {
    const reqs = StorageService.getMentorshipRequests();
    const newReq: MentorshipRequest = {
      id: `mreq-${Date.now()}`,
      mentorId: mentor.id,
      mentorName: mentor.name,
      menteeId: mentee.id,
      menteeName: mentee.fullName,
      menteeEmail: mentee.email,
      topic,
      preferredSlot,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    reqs.unshift(newReq);
    setStored(KEYS.MENTORSHIP_REQUESTS, reqs);
    StorageService.addAuditLog('MENTORSHIP_REQUEST', 'Mentorship', `New request for ${mentor.name} from ${mentee.fullName}`);
    return newReq;
  },
  updateMentorshipStatus: (requestId: string, status: MentorshipRequest['status'], meetingLink?: string) => {
    const reqs = StorageService.getMentorshipRequests();
    const r = reqs.find(item => item.id === requestId);
    if (r) {
      r.status = status;
      if (meetingLink) r.meetingLink = meetingLink;
      setStored(KEYS.MENTORSHIP_REQUESTS, reqs);
    }
  },

  // OPPORTUNITIES
  getOpportunities: (): Opportunity[] => getStored<Opportunity[]>(KEYS.OPPORTUNITIES, INITIAL_OPPORTUNITIES),
  saveOpportunity: (opp: Opportunity) => {
    const list = StorageService.getOpportunities();
    const idx = list.findIndex(o => o.id === opp.id);
    if (idx >= 0) list[idx] = opp;
    else list.unshift(opp);
    setStored(KEYS.OPPORTUNITIES, list);
  },

  // PARTNERS
  getPartners: (): Partner[] => getStored<Partner[]>(KEYS.PARTNERS, INITIAL_PARTNERS),

  // COMMUNITY & FORUM
  getCommunityMembers: (): CommunityMember[] => getStored<CommunityMember[]>(KEYS.COMMUNITY_MEMBERS, INITIAL_COMMUNITY_MEMBERS),
  addCommunityMember: (member: CommunityMember) => {
    const list = StorageService.getCommunityMembers();
    list.unshift(member);
    setStored(KEYS.COMMUNITY_MEMBERS, list);
  },
  getForumTopics: (): ForumTopic[] => getStored<ForumTopic[]>(KEYS.FORUM_TOPICS, INITIAL_FORUM_TOPICS),
  addForumTopic: (topic: ForumTopic) => {
    const list = StorageService.getForumTopics();
    list.unshift(topic);
    setStored(KEYS.FORUM_TOPICS, list);
  },
  likeForumTopic: (topicId: string) => {
    const list = StorageService.getForumTopics();
    const t = list.find(item => item.id === topicId);
    if (t) {
      t.likesCount += 1;
      setStored(KEYS.FORUM_TOPICS, list);
    }
  },

  // NEWS
  getNews: (): NewsArticle[] => getStored<NewsArticle[]>(KEYS.NEWS, INITIAL_NEWS),
  saveNewsArticle: (art: NewsArticle) => {
    const list = StorageService.getNews();
    const idx = list.findIndex(n => n.id === art.id);
    if (idx >= 0) list[idx] = art;
    else list.unshift(art);
    setStored(KEYS.NEWS, list);
  },

  // IMPACT METRICS
  getImpactMetrics: (): ImpactMetrics => getStored<ImpactMetrics>(KEYS.IMPACT, INITIAL_IMPACT_METRICS),

  // AUDIT LOGS
  getAuditLogs: (): AuditLog[] => getStored<AuditLog[]>(KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS),
  addAuditLog: (action: string, module: string, details: string, user?: User) => {
    const logs = StorageService.getAuditLogs();
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user ? user.id : 'usr-admin-1',
      userName: user ? user.fullName : 'Admin System',
      action,
      module,
      details
    };
    logs.unshift(newLog);
    // Keep last 100 entries
    if (logs.length > 100) logs.pop();
    setStored(KEYS.AUDIT_LOGS, logs);
  }
};
