/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.12 News & Content Management (CMS)
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { NewsArticle } from '../../types';
import { FileText, Plus, Calendar, Clock, Edit, Trash2, X } from 'lucide-react';

export const AdminContent: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const news = StorageService.getNews();

  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<NewsArticle['category']>('Announcement');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const newArt: NewsArticle = {
      id: `news-${Date.now()}`,
      title,
      category,
      author: 'SiHub Communications Bureau',
      publishedAt: new Date().toISOString().split('T')[0],
      readTime: '4 min read',
      summary,
      content,
      coverImage: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=80'
    };

    StorageService.saveNewsArticle(newArt);
    setShowModal(false);
    triggerRefresh();
    addToast('success', 'Article Published', `"${newArt.title}" is now live on the website.`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.12 • Content Management System (CMS)
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Articles, Research Papers & Success Stories
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Publish official announcements, startup case studies, and policy whitepapers.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-4 h-4" /> Publish New Article
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {news.map(art => (
          <div key={art.id} className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex flex-col justify-between">
            <div className="relative h-40">
              <img src={art.coverImage} alt={art.title} className="w-full h-full object-cover" />
              <div className="absolute top-3 left-3 bg-slate-900/90 text-cyan-300 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                {art.category}
              </div>
            </div>

            <div className="p-5 space-y-2">
              <div className="text-[10px] text-slate-500 font-mono">{art.publishedAt} • {art.readTime}</div>
              <h3 className="text-sm font-bold text-white leading-snug">{art.title}</h3>
              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{art.summary}</p>
            </div>

            <div className="p-5 pt-0 border-t border-slate-800/80 text-[11px] text-slate-500 flex justify-between">
              <span>Author: {art.author}</span>
              <span className="text-emerald-400">Published</span>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" /> Publish CMS Article
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Article Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Breakthrough in Off-Grid Coastal Fish Cold Storage..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Category</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as NewsArticle['category'])}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                >
                  <option value="Announcement">Announcement</option>
                  <option value="Success Story">Success Story</option>
                  <option value="Impact Report">Impact Report</option>
                  <option value="Press Release">Press Release</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Summary Abstract</label>
                <textarea
                  rows={2}
                  required
                  value={summary}
                  onChange={e => setSummary(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white resize-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Full Content</label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                >
                  Publish Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
