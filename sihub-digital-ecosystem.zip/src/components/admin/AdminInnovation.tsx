/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.5 Innovation Projects Administration
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { InnovationProject } from '../../types';
import {
  Lightbulb,
  CheckCircle2,
  Clock,
  Plus,
  Layers,
  MapPin,
  TrendingUp,
  X
} from 'lucide-react';

export const AdminInnovation: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const projects = StorageService.getInnovationProjects();

  const [showNewModal, setShowNewModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSector, setNewSector] = useState<InnovationProject['sector']>('Agriculture');
  const [newLead, setNewLead] = useState('Eng. Osman Shire');
  const [newDesc, setNewDesc] = useState('');

  const handleToggleMilestone = (project: InnovationProject, milestoneIdx: number) => {
    project.milestones[milestoneIdx].completed = !project.milestones[milestoneIdx].completed;
    StorageService.saveInnovationProject(project);
    triggerRefresh();
    addToast('info', 'Milestone Updated', `Toggled milestone for ${project.title}`);
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    const newPrj: InnovationProject = {
      id: `prj-${Date.now()}`,
      title: newTitle,
      sector: newSector,
      leadResearcher: newLead,
      organizationOrTeam: 'SiHub Applied Research Fellows',
      description: newDesc,
      objectives: ['Deploy proof of concept in regional hub', 'Measure community resilience'],
      status: 'In Progress',
      location: 'Mogadishu & Regional Hubs',
      beneficiariesCount: 15000,
      budgetEstimated: '$45,000',
      startDate: new Date().toISOString().split('T')[0],
      milestones: [
        { title: 'Baseline assessment & hardware sourcing', completed: true, dueDate: '2026-12-01' },
        { title: 'Field trial deployment', completed: false, dueDate: '2027-02-15' }
      ]
    };

    StorageService.saveInnovationProject(newPrj);
    setShowNewModal(false);
    setNewTitle('');
    setNewDesc('');
    triggerRefresh();
    addToast('success', 'Project Registered', `"${newPrj.title}" is now tracked in the Innovation Lab.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.5 • Innovation Project Portfolio
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Grassroots R&D & Applied Prototyping
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Monitor multi-sector engineering projects spanning water telemetry, Somali NLP, solar fishing storage, and health carriers.
          </p>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-4 h-4" /> Add Innovation Project
        </button>
      </div>

      {/* Projects List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map(proj => (
          <div
            key={proj.id}
            className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                  {proj.sector}
                </span>
                <span className="text-[11px] font-bold text-emerald-400 font-mono">
                  ● {proj.status}
                </span>
              </div>

              <h3 className="text-base font-bold text-white leading-snug">{proj.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">{proj.description}</p>

              <div className="text-xs text-slate-400 flex items-center justify-between pt-2 border-t border-slate-800">
                <span>Lead: <strong className="text-slate-200">{proj.leadResearcher}</strong></span>
                <span>Budget: <strong className="text-emerald-400 font-mono">{proj.budgetEstimated}</strong></span>
              </div>

              {/* Milestones Checklist */}
              <div className="space-y-1.5 pt-2">
                <span className="text-[10px] font-bold uppercase text-slate-500 block">Milestones (Click to toggle):</span>
                {proj.milestones.map((m, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleToggleMilestone(proj, idx)}
                    className="w-full text-left p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs flex items-center justify-between hover:bg-slate-850 transition-colors"
                  >
                    <span className={`flex items-center gap-2 ${m.completed ? 'text-emerald-300 font-semibold line-through' : 'text-slate-300'}`}>
                      <CheckCircle2 className={`w-3.5 h-3.5 ${m.completed ? 'text-emerald-400' : 'text-slate-600'}`} />
                      {m.title}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{m.dueDate}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-800">
              Impact Scope: <strong className="text-white">{proj.beneficiariesCount.toLocaleString()} Citizens</strong>
            </div>
          </div>
        ))}
      </div>

      {/* New Project Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" /> Register Applied R&D Project
              </h3>
              <button onClick={() => setShowNewModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProject} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Project Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Solar Borehole Desalination Unit..."
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Sector</label>
                  <select
                    value={newSector}
                    onChange={e => setNewSector(e.target.value as InnovationProject['sector'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Agriculture">Agriculture & Water</option>
                    <option value="Environment">Clean Energy / Environment</option>
                    <option value="Technology">Technology & AI</option>
                    <option value="Health">Health & Telemedicine</option>
                    <option value="Education">Education & STEM</option>
                    <option value="Social">Social Innovation</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Lead Researcher</label>
                  <input
                    type="text"
                    required
                    value={newLead}
                    onChange={e => setNewLead(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Project Summary</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Problem, technical methodology, and deployment locations..."
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                >
                  Save Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
