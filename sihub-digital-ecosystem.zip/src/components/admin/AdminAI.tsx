/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.14 AI Management & Knowledge Base Console
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bot,
  Sparkles,
  BookOpen,
  MessageSquare,
  Settings,
  Database,
  BarChart2,
  CheckCircle2,
  Save,
  Plus
} from 'lucide-react';

export const AdminAI: React.FC = () => {
  const { addToast } = useApp();

  const [modelSelected, setModelSelected] = useState('gemini-2.5-flash');
  const [temperature, setTemperature] = useState(0.4);
  const [systemPrompt, setSystemPrompt] = useState(
    'You are SiHub AI, the official digital guide for the Somali Innovation Hub. Help students discover courses, guide entrepreneurs to pitch their startups, and provide accurate details on scholarships and regional offices in Mogadishu, Hargeisa, Garowe, Baidoa, and Kismayo.'
  );

  const [knowledgeBase, setKnowledgeBase] = useState([
    { q: 'How to apply for incubation?', a: 'Founders must submit a 2-founder team and prototype at /startups.' },
    { q: 'Are academy courses accredited and free?', a: 'Yes, 100% grant-subsidized with mandatory admin approval before lesson unlocking.' },
    { q: 'Where are maker spaces located?', a: 'KM4 Airport Road, Mogadishu (HQ) and 4 regional field hubs.' }
  ]);

  const [newQ, setNewQ] = useState('');
  const [newA, setNewA] = useState('');

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('success', 'AI Configuration Saved', 'Updated system prompt and vector retrieval weights.');
  };

  const handleAddFaq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQ || !newA) return;
    setKnowledgeBase([...knowledgeBase, { q: newQ, a: newA }]);
    setNewQ('');
    setNewA('');
    addToast('success', 'Knowledge Updated', 'New item indexed into AI retrieval store.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.14 • AI Management Console
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            SiHub AI Assistant Architecture & Knowledge Base
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure prompt behavioral policies, curate institutional knowledge retrieval documents, and inspect usage analytics.
          </p>
        </div>

        <span className="text-[11px] px-3 py-1.5 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
          Model: {modelSelected}
        </span>
      </div>

      {/* AI Telemetry & Usage KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400">Total Queries Handled</span>
          <div className="text-2xl font-bold text-white font-mono">4,120</div>
          <span className="text-[10px] text-cyan-400">Somali: 58% • English: 42%</span>
        </div>
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400">Avg Response Time</span>
          <div className="text-2xl font-bold text-emerald-400 font-mono">340ms</div>
          <span className="text-[10px] text-slate-500">Gemini 2.5 Flash Proxy</span>
        </div>
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400">User Satisfaction</span>
          <div className="text-2xl font-bold text-amber-400 font-mono">96.4%</div>
          <span className="text-[10px] text-emerald-400">Helpful rating</span>
        </div>
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400">Knowledge Indexed</span>
          <div className="text-2xl font-bold text-purple-400 font-mono">148 Docs</div>
          <span className="text-[10px] text-slate-500">Vector Embeddings</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: System Instructions Configuration */}
        <div className="lg:col-span-7 bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Settings className="w-4 h-4 text-cyan-400" /> System Instructions & Governance Policy
          </h3>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Target Engine Model</label>
              <select
                value={modelSelected}
                onChange={e => setModelSelected(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
              >
                <option value="gemini-2.5-flash">Gemini 2.5 Flash (Recommended - Ultra Low Latency)</option>
                <option value="gemini-2.5-pro">Gemini 2.5 Pro (Deep Reasoning & Policy Analysis)</option>
              </select>
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span className="font-semibold">Temperature (Precision vs Creativity)</span>
                <span className="font-mono text-cyan-400">{temperature}</span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.1}
                value={temperature}
                onChange={e => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-cyan-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">System Directive Prompt</label>
              <textarea
                rows={5}
                value={systemPrompt}
                onChange={e => setSystemPrompt(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white resize-none font-mono text-[11px] leading-relaxed"
              />
            </div>

            <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-800 text-[11px] text-cyan-300">
              💡 <strong>Integration Note:</strong> In Phase 2, this console writes to the `/api/ai/config` server endpoint, which configures the `@google/genai` client dynamically.
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <Save className="w-4 h-4" /> Save AI Configuration
            </button>
          </form>
        </div>

        {/* Right: Knowledge Base Curation */}
        <div className="lg:col-span-5 bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" /> Knowledge Base & Verified FAQs
          </h3>

          <div className="space-y-2.5 max-h-64 overflow-y-auto">
            {knowledgeBase.map((item, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1">
                <strong className="text-white block font-medium">Q: {item.q}</strong>
                <p className="text-slate-400 text-[11px]">{item.a}</p>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddFaq} className="space-y-2 pt-3 border-t border-slate-800 text-xs">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Add Verified FAQ:</span>
            <input
              type="text"
              required
              placeholder="Question..."
              value={newQ}
              onChange={e => setNewQ(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white"
            />
            <textarea
              rows={2}
              required
              placeholder="Official organizational answer..."
              value={newA}
              onChange={e => setNewA(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white resize-none"
            />
            <button
              type="submit"
              className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" /> Index into Knowledge Base
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
