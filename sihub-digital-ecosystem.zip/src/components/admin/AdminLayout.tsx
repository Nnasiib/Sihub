/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Administration Dashboard Layout & Shell
 */

import React, { useState } from 'react';
import { useApp, AdminTab } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  Rocket,
  Lightbulb,
  Layers,
  Users2,
  Calendar,
  Compass,
  Award,
  Handshake,
  FileText,
  BarChart3,
  Bot,
  Settings,
  Bell,
  Search,
  Menu,
  X,
  ExternalLink,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const {
    adminTab,
    setAdminTab,
    currentUser,
    navigateTo,
    resetDemoData,
    setIsAiAssistantOpen
  } = useApp();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const navItems: { tab: AdminTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { tab: 'overview', label: '6.1 Executive Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
    { tab: 'users', label: '6.2 User Management', icon: <Users className="w-4 h-4" /> },
    { tab: 'lms', label: '6.3 Education & LMS', icon: <GraduationCap className="w-4 h-4" />, badge: 'Approvals' },
    { tab: 'startups', label: '6.4 Startup Hub', icon: <Rocket className="w-4 h-4" /> },
    { tab: 'innovation', label: '6.5 Innovation Projects', icon: <Lightbulb className="w-4 h-4" /> },
    { tab: 'programs', label: '6.6 Programs & Cohorts', icon: <Layers className="w-4 h-4" /> },
    { tab: 'community', label: '6.7 Community Groups', icon: <Users2 className="w-4 h-4" /> },
    { tab: 'events', label: '6.8 Events & Attendance', icon: <Calendar className="w-4 h-4" /> },
    { tab: 'mentorship', label: '6.9 Mentorship Desk', icon: <Compass className="w-4 h-4" /> },
    { tab: 'opportunities', label: '6.10 Grants & Jobs', icon: <Award className="w-4 h-4" /> },
    { tab: 'partnerships', label: '6.11 Partnerships & MOUs', icon: <Handshake className="w-4 h-4" /> },
    { tab: 'content', label: '6.12 News & CMS', icon: <FileText className="w-4 h-4" /> },
    { tab: 'impact', label: '6.13 Impact & Analytics', icon: <BarChart3 className="w-4 h-4" /> },
    { tab: 'ai', label: '6.14 AI Assistant Settings', icon: <Bot className="w-4 h-4" />, badge: 'Config' },
    { tab: 'settings', label: '6.15 Settings & Security', icon: <Settings className="w-4 h-4" /> }
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased">
      {/* Top Admin Header */}
      <header className="h-16 bg-slate-950 border-b border-slate-800 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <Menu className="w-5 h-5" />
          </button>
          <BrandLogo size="sm" showSubtitle={false} lightText={true} onClick={() => navigateTo('home')} />
          <div className="hidden sm:block pl-2 border-l border-slate-800">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              SiHub Admin Console
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">
              Enterprise Ecosystem Back-Office Demo
            </span>
          </div>
        </div>

        {/* Global Search and Actions */}
        <div className="flex items-center gap-3">
          <div className="relative hidden md:block w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search users, courses, startups..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
            />
          </div>

          <button
            onClick={() => setIsAiAssistantOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-600/50 text-xs font-semibold transition-colors"
          >
            <Bot className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">AI Config</span>
          </button>

          <button
            onClick={() => navigateTo('home')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
          >
            <span>Public Site</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </button>

          {/* User Badge */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="w-8 h-8 rounded-full bg-cyan-700 text-white font-bold flex items-center justify-center text-xs">
              {currentUser.fullName.charAt(0)}
            </div>
            <div className="hidden xl:block text-left">
              <span className="text-xs font-bold text-white block leading-tight">{currentUser.fullName}</span>
              <span className="text-[10px] text-emerald-400 font-mono uppercase">{currentUser.role}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <aside
          className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between transition-transform duration-200 ease-in-out ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="p-4 space-y-1 overflow-y-auto max-h-[calc(100vh-8rem)]">
            <div className="flex items-center justify-between pb-3 px-2 lg:hidden">
              <span className="text-xs font-bold uppercase text-slate-400">Navigation</span>
              <button onClick={() => setSidebarOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2 py-1">
              Modules
            </div>

            {navItems.map(item => {
              const isActive = adminTab === item.tab;
              return (
                <button
                  key={item.tab}
                  onClick={() => {
                    setAdminTab(item.tab);
                    setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive
                          ? 'bg-slate-950 text-cyan-300'
                          : 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Bottom Sidebar Info */}
          <div className="p-4 border-t border-slate-800/80 bg-slate-950/80 space-y-2">
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Phase 1 Demonstration Engine</span>
            </div>
            <div className="text-[9px] text-slate-500 leading-tight">
              PostgreSQL schema & server-side auth mapped in 6.15 Settings.
            </div>
          </div>
        </aside>

        {/* Backdrop for mobile */}
        {sidebarOpen && (
          <div
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          />
        )}

        {/* Content Area */}
        <main className="flex-1 bg-slate-900 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto space-y-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
