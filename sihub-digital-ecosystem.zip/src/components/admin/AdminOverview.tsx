/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.1 Executive Overview Dashboard
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import {
  Users,
  GraduationCap,
  Rocket,
  Calendar,
  Layers,
  Award,
  Clock,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';

export const AdminOverview: React.FC = () => {
  const { setAdminTab, triggerRefresh, addToast } = useApp();

  const users = StorageService.getUsers();
  const courses = StorageService.getCourses();
  const enrollments = StorageService.getEnrollments();
  const startups = StorageService.getStartups();
  const programs = StorageService.getPrograms();
  const events = StorageService.getEvents();
  const logs = StorageService.getAuditLogs();
  const impact = StorageService.getImpactMetrics();

  const pendingEnrollments = enrollments.filter(e => e.status === 'pending');
  const pendingStartups = startups.filter(s => s.status === 'under_review');

  const handleQuickApproveEnrollment = (id: string, name: string, course: string) => {
    StorageService.approveEnrollment(id);
    triggerRefresh();
    addToast('success', 'Enrollment Approved', `Granted ${name} access to ${course}.`);
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.1 • Executive Dashboard
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading mt-1">
            Institutional Operations Overview
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time status across education, incubation pipelines, programs, and regional hubs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] px-3 py-1.5 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-800 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> All Systems Nominal
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Registered Users</span>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-white font-heading">{users.length}</div>
          <div className="text-[11px] text-cyan-400 flex items-center gap-1 font-medium">
            <TrendingUp className="w-3 h-3" /> 11 Verified Role Personas
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Active LMS Courses</span>
            <GraduationCap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-white font-heading">{courses.length}</div>
          <div className="text-[11px] text-emerald-400 flex items-center gap-1 font-medium">
            <span>{enrollments.length} Total Enrolled Learners</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Startups in Pipeline</span>
            <Rocket className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-white font-heading">{startups.length}</div>
          <div className="text-[11px] text-amber-400 flex items-center gap-1 font-medium">
            <span>{pendingStartups.length} Under Committee Review</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Grant Capital Disbursed</span>
            <Award className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-extrabold text-white font-heading">
            ${(impact.grantsDisbursedUSD / 1000).toFixed(0)}k
          </div>
          <div className="text-[11px] text-purple-400 font-medium">
            {impact.startupsSupported} Catalyzed Ventures
          </div>
        </div>
      </div>

      {/* Critical Approval Queues: LMS & Startups */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LMS Course Enrollment Approvals Queue (Crucial Business Rule) */}
        <div className="lg:col-span-7 bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-sm text-white">Pending Course Enrollment Approvals</h3>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
              {pendingEnrollments.length} PENDING
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Review applicant motivations and approve access to online modules, video lessons, and quizzes:
          </p>

          {pendingEnrollments.length === 0 ? (
            <div className="p-6 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-500">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              All course applications have been processed.
            </div>
          ) : (
            <div className="space-y-3">
              {pendingEnrollments.map(enr => (
                <div
                  key={enr.id}
                  className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1 max-w-md">
                    <div className="flex items-center gap-2">
                      <strong className="text-white">{enr.userName}</strong>
                      <span className="text-[10px] text-slate-400 font-mono">{enr.userEmail}</span>
                    </div>
                    <div className="text-cyan-400 font-medium">{enr.courseTitle}</div>
                    <p className="text-slate-400 text-[11px] line-clamp-1 italic">
                      "{enr.motivation}"
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleQuickApproveEnrollment(enr.id, enr.userName, enr.courseTitle)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors shadow-xs"
                    >
                      Approve Access
                    </button>
                    <button
                      onClick={() => setAdminTab('lms')}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
                    >
                      Review
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="pt-2">
            <button
              onClick={() => setAdminTab('lms')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              Open Full LMS Management &rarr;
            </button>
          </div>
        </div>

        {/* Live System Activity Log */}
        <div className="lg:col-span-5 bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-sm text-white">Live Activity & Audit Stream</h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">AUDIT TRAIL</span>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto">
            {logs.slice(0, 5).map(log => (
              <div key={log.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800/80 text-xs space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="font-bold text-cyan-400">{log.module}</span>
                  <span className="text-slate-500 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="text-slate-200 font-medium leading-snug">{log.details}</div>
                <div className="text-[10px] text-slate-500">Initiator: {log.userName}</div>
              </div>
            ))}
          </div>

          <div className="pt-2">
            <button
              onClick={() => setAdminTab('settings')}
              className="text-xs font-bold text-slate-400 hover:text-white flex items-center gap-1"
            >
              View System Architecture & Security Logs &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
