/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.10 Opportunities (Grants & Jobs) Administration
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Opportunity } from '../../types';
import { Award, DollarSign, Calendar, Plus, X } from 'lucide-react';

export const AdminOpportunities: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const opportunities = StorageService.getOpportunities();

  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<Opportunity['type']>('Grant');
  const [amount, setAmount] = useState('$10,000 Equity-Free');
  const [deadline, setDeadline] = useState('2026-12-31');
  const [desc, setDesc] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const newOpp: Opportunity = {
      id: `opp-${Date.now()}`,
      title,
      type,
      provider: 'Somali Innovation Hub Catalytic Fund',
      location: 'National / All Regions',
      deadline,
      amountOrStipend: amount,
      description: desc,
      eligibility: ['Operational in Somalia', 'Clear community beneficiaries'],
      status: 'Open',
      applicantsCount: 0
    };

    StorageService.saveOpportunity(newOpp);
    setShowModal(false);
    triggerRefresh();
    addToast('success', 'Opportunity Published', `"${newOpp.title}" is now open for applications.`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono">
            Module 6.10 • Grants & Opportunities Management
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Catalytic Capital & Career Callouts
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Administer grants, track applicant numbers, and review fellowship disbursements.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-4 h-4" /> Post New Grant or Job
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {opportunities.map(opp => (
          <div key={opp.id} className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {opp.type}
                </span>
                <span className="text-xs text-slate-400 font-mono">{opp.applicantsCount} Applicants</span>
              </div>
              <h3 className="text-base font-bold text-white leading-snug">{opp.title}</h3>
              {opp.amountOrStipend && (
                <div className="text-emerald-400 font-bold text-xs font-mono">{opp.amountOrStipend}</div>
              )}
              <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">{opp.description}</p>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-between text-xs text-slate-400">
              <span>Deadline: <strong className="text-rose-400">{opp.deadline}</strong></span>
              <span className="text-emerald-400 font-bold">Status: {opp.status}</span>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" /> Post New Opportunity
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Women in CleanTech Grant..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Type</label>
                  <select
                    value={type}
                    onChange={e => setType(e.target.value as Opportunity['type'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                  >
                    <option value="Grant">Grant</option>
                    <option value="Scholarship">Scholarship</option>
                    <option value="Job">Job</option>
                    <option value="Internship">Internship</option>
                    <option value="Fellowship">Fellowship</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Stipend / Value</label>
                  <input
                    type="text"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Description</label>
                <textarea
                  rows={3}
                  required
                  value={desc}
                  onChange={e => setDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Publish Opportunity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
