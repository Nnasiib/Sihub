/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.15 System Settings & Phase 2 Architecture Blueprint
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import {
  Settings,
  Database,
  ShieldCheck,
  Lock,
  Server,
  FileCode,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Globe,
  Sliders
} from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const { resetDemoData, addToast, language, setLanguage } = useApp();
  const [activeTab, setActiveTab] = useState<'general' | 'roles' | 'architecture'>('architecture');

  const [orgName, setOrgName] = useState('Somali Innovation Hub (SiHub)');
  const [hqAddress, setHqAddress] = useState('KM4 Airport Road, Wadajir District, Mogadishu, Somalia');
  const [contactEmail, setContactEmail] = useState('info@sihub.so');
  const [supportPhone, setSupportPhone] = useState('+252 61 555 1200');

  const handleSaveGeneral = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('success', 'Settings Saved', 'Organization profile configurations updated.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.15 • System Settings & Architecture
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            System Configuration & Phase 2 Blueprint
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure institutional profile details, inspect RBAC role permissions, and review the production database & security roadmap.
          </p>
        </div>

        <button
          onClick={() => {
            if (confirm('Reset all demo data across courses, enrollments, startups, and events?')) {
              resetDemoData();
            }
          }}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-amber-950 text-slate-300 hover:text-amber-300 border border-slate-700 text-xs font-bold flex items-center gap-2 transition-colors"
        >
          <RotateCcw className="w-4 h-4 text-amber-400" /> Reset Demo Records
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 space-x-2">
        <button
          onClick={() => setActiveTab('architecture')}
          className={`pb-3 px-3 text-xs font-bold transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'architecture'
              ? 'border-cyan-500 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Database className="w-4 h-4" /> Phase 2 Database & Security Blueprint
        </button>

        <button
          onClick={() => setActiveTab('general')}
          className={`pb-3 px-3 text-xs font-bold transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'general'
              ? 'border-cyan-500 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Sliders className="w-4 h-4" /> Organization Profile & Branding
        </button>

        <button
          onClick={() => setActiveTab('roles')}
          className={`pb-3 px-3 text-xs font-bold transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'roles'
              ? 'border-cyan-500 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <ShieldCheck className="w-4 h-4" /> Role-Based Access Control (RBAC) Matrix
        </button>
      </div>

      {/* Tab: Phase 2 Database & Security Blueprint (Required by prompt 12 & 13) */}
      {activeTab === 'architecture' && (
        <div className="space-y-6 text-xs text-slate-300">
          <div className="p-5 rounded-2xl bg-cyan-950/40 border border-cyan-800 text-cyan-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-sm text-white">
              <ShieldCheck className="w-5 h-5 text-cyan-400" /> Production Migration Architecture Guide
            </div>
            <p className="leading-relaxed">
              This interactive demonstration is deliberately developed with isolated services (see <code className="text-cyan-300 font-mono">StorageService</code>) to allow straightforward drop-in replacement with real PostgreSQL, Drizzle ORM, and JWT authentication in Phase 2 without rewriting user interface views.
            </p>
          </div>

          {/* Database Schema Map */}
          <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-400" /> Proposed PostgreSQL Relational Schema Architecture
            </h3>
            <p className="text-slate-400">
              Normalized tables prepared for production DDL deployment:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-[11px]">
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-cyan-400 block">Table: users</strong>
                <div>id UUID PRIMARY KEY DEFAULT gen_random_uuid()</div>
                <div>full_name VARCHAR(255) NOT NULL</div>
                <div>email VARCHAR(255) UNIQUE NOT NULL</div>
                <div>phone VARCHAR(50)</div>
                <div>role user_role_enum NOT NULL DEFAULT 'visitor'</div>
                <div>is_active BOOLEAN DEFAULT TRUE</div>
                <div>created_at TIMESTAMPTZ DEFAULT NOW()</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-emerald-400 block">Table: courses</strong>
                <div>id UUID PRIMARY KEY DEFAULT gen_random_uuid()</div>
                <div>code VARCHAR(50) UNIQUE NOT NULL</div>
                <div>title VARCHAR(255) NOT NULL</div>
                <div>category VARCHAR(100) NOT NULL</div>
                <div>instructor_id UUID REFERENCES users(id)</div>
                <div>capacity INTEGER NOT NULL DEFAULT 50</div>
                <div>is_published BOOLEAN DEFAULT FALSE</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-amber-400 block">Table: course_enrollments</strong>
                <div>id UUID PRIMARY KEY DEFAULT gen_random_uuid()</div>
                <div>course_id UUID REFERENCES courses(id)</div>
                <div>user_id UUID REFERENCES users(id)</div>
                <div>status enrollment_status_enum NOT NULL DEFAULT 'pending'</div>
                <div>reviewed_by UUID REFERENCES users(id)</div>
                <div>progress_percent INTEGER DEFAULT 0</div>
                <div>applied_at TIMESTAMPTZ DEFAULT NOW()</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-purple-400 block">Table: startups</strong>
                <div>id UUID PRIMARY KEY DEFAULT gen_random_uuid()</div>
                <div>name VARCHAR(255) NOT NULL</div>
                <div>sector VARCHAR(100) NOT NULL</div>
                <div>stage startup_stage_enum NOT NULL</div>
                <div>founder_id UUID REFERENCES users(id)</div>
                <div>status startup_status_enum DEFAULT 'under_review'</div>
                <div>funding_raised_usd NUMERIC(12,2) DEFAULT 0</div>
              </div>
            </div>
          </div>

          {/* Security Specifications */}
          <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-rose-400" /> Mandatory Production Security Specifications (Phase 2)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-white block font-semibold">1. Authentication & RBAC</strong>
                <p className="text-slate-400">
                  Password hashing via Argon2id. Dual-token JWT architecture with rotating Refresh Tokens stored in HttpOnly, SameSite=Strict cookies.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-white block font-semibold">2. Defense-in-Depth</strong>
                <p className="text-slate-400">
                  Parameterised SQL queries to eliminate injection. Helmet headers (CSP, HSTS). Global Redis rate limiting against brute force.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <strong className="text-white block font-semibold">3. Audit & Compliance</strong>
                <p className="text-slate-400">
                  Append-only immutable audit logging for all administrative decisions (enrollment approvals, user role changes, and grant approvals).
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: General Settings & Branding */}
      {activeTab === 'general' && (
        <form onSubmit={handleSaveGeneral} className="bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-6 text-xs">
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white">Institutional Identity</h3>

            <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
              <BrandLogo size="md" showSubtitle={true} lightText={true} />
              <div className="text-[11px] text-slate-400">
                Official logo asset locked to: <code className="text-cyan-300 font-mono">/assets/aistudio/..._811cbd58.jpg</code>. Preserved across all views.
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Organization Name</label>
                <input
                  type="text"
                  value={orgName}
                  onChange={e => setOrgName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Official Contact Email</label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={e => setContactEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Headquarters Campus Address</label>
                <input
                  type="text"
                  value={hqAddress}
                  onChange={e => setHqAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Direct Telephone Hotline</label>
                <input
                  type="text"
                  value={supportPhone}
                  onChange={e => setSupportPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
            >
              Save Organization Settings
            </button>
          </div>
        </form>
      )}

      {/* Tab: Role Matrix */}
      {activeTab === 'roles' && (
        <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4 text-xs">
          <h3 className="text-sm font-bold text-white">Ecosystem Role Matrix & Permissions</h3>
          <p className="text-slate-400">Overview of access privileges across all 11 user personas:</p>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-900/80 text-slate-400 uppercase text-[10px] font-mono border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Role</th>
                  <th className="py-2.5 px-3">Public Site</th>
                  <th className="py-2.5 px-3">Learner LMS</th>
                  <th className="py-2.5 px-3">Founder Hub</th>
                  <th className="py-2.5 px-3">Admin Console</th>
                  <th className="py-2.5 px-3">Approve Enrollments</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-2.5 px-3 font-bold text-white">Visitor</td>
                  <td className="py-2.5 px-3 text-emerald-400">Yes</td>
                  <td className="py-2.5 px-3 text-slate-500">Apply Only</td>
                  <td className="py-2.5 px-3 text-slate-500">Apply Only</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-white">Student / Learner</td>
                  <td className="py-2.5 px-3 text-emerald-400">Yes</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full (Approved)</td>
                  <td className="py-2.5 px-3 text-slate-500">View Only</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-white">Instructor</td>
                  <td className="py-2.5 px-3 text-emerald-400">Yes</td>
                  <td className="py-2.5 px-3 text-emerald-400">Manage Course</td>
                  <td className="py-2.5 px-3 text-slate-500">View Only</td>
                  <td className="py-2.5 px-3 text-slate-500">LMS Sub-desk</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-white">Startup Founder</td>
                  <td className="py-2.5 px-3 text-emerald-400">Yes</td>
                  <td className="py-2.5 px-3 text-slate-300">Enrolled</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full Venture Desk</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                  <td className="py-2.5 px-3 text-rose-500">No</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-cyan-400">Administrator</td>
                  <td className="py-2.5 px-3 text-emerald-400">Yes</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full Console</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">YES (Auth)</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3 font-bold text-purple-400">Super Administrator</td>
                  <td className="py-2.5 px-3 text-emerald-400">Yes</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full</td>
                  <td className="py-2.5 px-3 text-emerald-400">Full Governance</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">YES (Auth)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
