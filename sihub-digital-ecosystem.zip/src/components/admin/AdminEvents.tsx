/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.8 Events & Attendance Management (with QR Ticket Scanner Demo)
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import type { SiHubEvent as Event, EventRegistration } from '../../types';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  QrCode,
  Plus,
  CheckCircle2,
  ScanLine,
  Download,
  X
} from 'lucide-react';

export const AdminEvents: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const events = StorageService.getEvents();
  const registrations = StorageService.getEventRegistrations();

  const [scannerInput, setScannerInput] = useState('');
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Event Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Event['category']>('Workshop');
  const [date, setDate] = useState('2026-12-10');
  const [time, setTime] = useState('09:00 AM - 01:00 PM (EAT)');
  const [venue, setVenue] = useState('SiHub MakerSpace Auditorium, Mogadishu');
  const [speaker, setSpeaker] = useState('Dr. Hassan Ali Geedi');
  const [capacity, setCapacity] = useState(100);
  const [description, setDescription] = useState('');

  const handleSimulateScan = (e: React.FormEvent) => {
    e.preventDefault();
    const code = scannerInput.trim().toUpperCase();
    const reg = registrations.find(r => r.ticketCode.toUpperCase() === code);

    if (reg) {
      reg.attended = true;
      setScanResult(`VERIFIED: ${reg.userName} (${reg.eventTitle}) marked as ATTENDED.`);
      addToast('success', 'QR Ticket Verified', `${reg.userName} checked in successfully!`);
      triggerRefresh();
    } else {
      setScanResult(`INVALID: Ticket code "${code}" not found in current registrations.`);
      addToast('error', 'Check-in Error', 'Ticket code not found.');
    }
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    const newEvt: Event = {
      id: `evt-${Date.now()}`,
      title,
      category,
      date,
      time,
      locationType: 'In-Person',
      venue,
      description,
      capacity,
      registeredCount: 0,
      speaker,
      isUpcoming: true,
      qrCodeSample: `SIHUB-EVT-${Math.floor(1000 + Math.random() * 9000)}`
    };

    StorageService.saveEvent(newEvt);
    setShowCreateModal(false);
    triggerRefresh();
    addToast('success', 'Event Created', `"${newEvt.title}" is now open for registrations.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.8 • Events & QR Attendance Management
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Events Coordination & Digital Check-In Desk
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Coordinate national summits, track attendee capacity, and scan digital entry QR passes in real time.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-4 h-4" /> Create New Event
        </button>
      </div>

      {/* QR Code Scanner Demonstration Box */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950 border border-cyan-800/60 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs uppercase tracking-wider">
            <ScanLine className="w-4 h-4 text-cyan-400 animate-pulse" />
            Live Reception QR Check-In Scanner (Simulated)
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Camera / USB Barcode Ready</span>
        </div>

        <form onSubmit={handleSimulateScan} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            required
            value={scannerInput}
            onChange={e => setScannerInput(e.target.value)}
            placeholder="Scan or type ticket code (e.g. SIHUB-TKT-99120)..."
            className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-hidden focus:border-cyan-400 font-mono"
          />
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shrink-0 transition-colors"
          >
            <QrCode className="w-4 h-4" /> Verify & Check-In
          </button>
        </form>

        {scanResult && (
          <div className={`p-3 rounded-xl text-xs font-mono font-medium ${
            scanResult.startsWith('VERIFIED')
              ? 'bg-emerald-950/80 border border-emerald-700 text-emerald-200'
              : 'bg-rose-950/80 border border-rose-700 text-rose-200'
          }`}>
            {scanResult}
          </div>
        )}
      </div>

      {/* Events Table */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-sm text-white">Scheduled Summits & Workshops</h3>
          <span className="text-xs text-slate-400 font-mono">{events.length} Events Listed</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-3 px-4">Event Title</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Venue</th>
                <th className="py-3 px-4">Capacity</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {events.map(evt => (
                <tr key={evt.id} className="hover:bg-slate-900/50">
                  <td className="py-3.5 px-4">
                    <strong className="text-white block font-medium">{evt.title}</strong>
                    <span className="text-[11px] text-slate-500">{evt.speaker}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                      {evt.category}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-[11px] text-slate-300">
                    {evt.date} • {evt.time}
                  </td>
                  <td className="py-3.5 px-4 text-slate-400 truncate max-w-xs">
                    {evt.venue}
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <span className="text-cyan-400 font-bold">{evt.registeredCount}</span> / {evt.capacity}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      Upcoming
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" /> Create Official SiHub Event
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Event Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AgriTech Demo Day 2026..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as Event['category'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Workshop">Workshop</option>
                    <option value="Conference">Conference</option>
                    <option value="Hackathon">Hackathon</option>
                    <option value="Demo Day">Demo Day</option>
                    <option value="Networking">Networking</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Capacity</label>
                  <input
                    type="number"
                    min={10}
                    max={1000}
                    value={capacity}
                    onChange={e => setCapacity(parseInt(e.target.value) || 50)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Time</label>
                  <input
                    type="text"
                    required
                    value={time}
                    onChange={e => setTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Venue / Hub</label>
                <input
                  type="text"
                  required
                  value={venue}
                  onChange={e => setVenue(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                >
                  Publish Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
