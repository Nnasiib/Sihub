/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.4 Startup Hub Administration & Pipeline Management
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Startup, StartupStage } from '../../types';
import {
  Rocket,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Award,
  Users,
  Compass,
  ArrowRight,
  TrendingUp,
  X
} from 'lucide-react';

export const AdminStartups: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const startups = StorageService.getStartups();
  const mentors = StorageService.getMentors();

  const [search, setSearch] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [activeStartupDetail, setActiveStartupDetail] = useState<Startup | null>(null);

  const statuses = ['All', 'active', 'under_review', 'graduated'];

  const filtered = startups.filter(s => {
    const matchesSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.founderName.toLowerCase().includes(search.toLowerCase()) ||
      s.sector.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = selectedStatus === 'All' || s.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const handleUpdateStatus = (startupId: string, status: Startup['status'], stage?: StartupStage) => {
    StorageService.updateStartupStatus(startupId, status, stage);
    triggerRefresh();
    addToast('success', 'Startup Status Updated', `Status changed to ${status}${stage ? ` (${stage})` : ''}.`);
    if (activeStartupDetail && activeStartupDetail.id === startupId) {
      setActiveStartupDetail({ ...activeStartupDetail, status, stage: stage || activeStartupDetail.stage });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider font-mono">
            Module 6.4 • Startup Hub Management
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Venture Pipeline & Incubation Desk
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Review venture pitches, advance cohorts through incubation milestones, and assign diaspora advisors.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono">
            Total Startups: <strong className="text-white">{startups.length}</strong>
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search startup, founder, sector..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-2">
          {statuses.map(st => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition-colors ${
                selectedStatus === st
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {st.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Startups Table */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-3 px-4">Startup</th>
                <th className="py-3 px-4">Sector</th>
                <th className="py-3 px-4">Founder</th>
                <th className="py-3 px-4">Incubation Stage</th>
                <th className="py-3 px-4">Assigned Mentor</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filtered.map(st => (
                <tr key={st.id} className="hover:bg-slate-900/50 transition-colors">
                  <td className="py-3.5 px-4">
                    <strong className="text-white block font-medium">{st.name}</strong>
                    <span className="text-[11px] text-slate-500 line-clamp-1">{st.tagline}</span>
                  </td>
                  <td className="py-3.5 px-4 text-cyan-300 font-medium">
                    {st.sector}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="text-slate-200 block">{st.founderName}</span>
                    <span className="text-[10px] text-slate-500">{st.location}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-900 border border-slate-700 text-slate-300">
                      {st.stage}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-400">
                    {st.mentorAssigned || <span className="text-slate-600 italic">Unassigned</span>}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      st.status === 'active'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : st.status === 'under_review'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-purple-950 text-purple-300 border border-purple-800'
                    }`}>
                      {st.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => setActiveStartupDetail(st)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs border border-slate-700 transition-colors"
                    >
                      Manage
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Startup Details & Review Drawer */}
      {activeStartupDetail && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-2xl w-full border border-slate-700 shadow-2xl p-6 text-slate-100 space-y-5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] text-amber-400 font-mono uppercase font-bold">
                  {activeStartupDetail.sector} • Stage: {activeStartupDetail.stage}
                </span>
                <h3 className="text-xl font-bold text-white">{activeStartupDetail.name}</h3>
              </div>
              <button onClick={() => setActiveStartupDetail(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 font-mono block">Founder Name</span>
                <strong className="text-white">{activeStartupDetail.founderName}</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-mono block">Contact Email</span>
                <strong className="text-slate-300">{activeStartupDetail.founderEmail}</strong>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-mono block">Operational Base</span>
                <strong className="text-white">{activeStartupDetail.location}</strong>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <h4 className="font-bold text-slate-300 uppercase tracking-wider text-[11px] mb-1">Problem Statement</h4>
                <p className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-slate-300 leading-relaxed">
                  {activeStartupDetail.problemStatement}
                </p>
              </div>

              <div>
                <h4 className="font-bold text-slate-300 uppercase tracking-wider text-[11px] mb-1">Proposed Solution</h4>
                <p className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-slate-300 leading-relaxed">
                  {activeStartupDetail.solution}
                </p>
              </div>
            </div>

            {/* Stage Progression Action Buttons */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 block">Advance Startup Pipeline Stage:</span>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleUpdateStatus(activeStartupDetail.id, 'active', 'Incubation')}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                >
                  Accept into Incubation
                </button>
                <button
                  onClick={() => handleUpdateStatus(activeStartupDetail.id, 'active', 'Acceleration')}
                  className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
                >
                  Advance to Acceleration
                </button>
                <button
                  onClick={() => handleUpdateStatus(activeStartupDetail.id, 'graduated', 'Growth / Scale')}
                  className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
                >
                  Mark as Graduated Alumni
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
