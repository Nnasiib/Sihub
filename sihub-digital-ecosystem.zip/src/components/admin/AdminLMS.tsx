/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.3 Education & LMS Management Administration
 * Implements course management and strict Admin Approval workflow for student enrollments.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Course, CourseCategory, Enrollment } from '../../types';
import {
  GraduationCap,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  Eye,
  Trash2,
  Edit,
  Clock,
  ShieldAlert,
  BarChart2,
  X,
  Save,
  BookOpen,
  Award
} from 'lucide-react';

export const AdminLMS: React.FC = () => {
  const { addToast, triggerRefresh, setSelectedCourseForLearn } = useApp();
  const courses = StorageService.getCourses();
  const enrollments = StorageService.getEnrollments();

  const [activeTab, setActiveTab] = useState<'enrollments' | 'courses' | 'reports'>('enrollments');
  const [rejectingEnrollment, setRejectingEnrollment] = useState<Enrollment | null>(null);
  const [rejectReason, setRejectReason] = useState('Prerequisites not yet met for this cohort.');
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [showNewCourseModal, setShowNewCourseModal] = useState(false);

  // New course draft state
  const [newCourseTitle, setNewCourseTitle] = useState('');
  const [newCourseCategory, setNewCourseCategory] = useState<CourseCategory>('Technology & Software');
  const [newCourseInstructor, setNewCourseInstructor] = useState('Eng. Abdullahi Warsame');
  const [newCourseWeeks, setNewCourseWeeks] = useState(8);
  const [newCourseDesc, setNewCourseDesc] = useState('');

  const pendingEnrollments = enrollments.filter(e => e.status === 'pending');
  const approvedEnrollments = enrollments.filter(e => e.status === 'approved');

  const handleApprove = (enrollmentId: string, userName: string, courseTitle: string) => {
    StorageService.approveEnrollment(enrollmentId);
    triggerRefresh();
    addToast('success', 'Enrollment Approved', `Granted ${userName} access to ${courseTitle}. Course unlocked in their dashboard.`);
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectingEnrollment) return;
    StorageService.rejectEnrollment(rejectingEnrollment.id, rejectReason);
    setRejectingEnrollment(null);
    triggerRefresh();
    addToast('error', 'Enrollment Rejected', `Application for ${rejectingEnrollment.userName} rejected.`);
  };

  const handleDeleteCourse = (courseId: string) => {
    if (confirm('Are you sure you want to delete this demonstration course?')) {
      StorageService.deleteCourse(courseId);
      triggerRefresh();
      addToast('info', 'Course Removed', 'Course deleted from catalog.');
    }
  };

  const handleTogglePublish = (courseId: string) => {
    StorageService.togglePublishCourse(courseId);
    triggerRefresh();
  };

  const handleCreateCourse = (e: React.FormEvent) => {
    e.preventDefault();
    const newCourse: Course = {
      id: `crs-${Date.now()}`,
      title: newCourseTitle,
      code: `SIHUB-${newCourseCategory.substring(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
      category: newCourseCategory,
      description: newCourseDesc,
      instructorId: 'usr-instructor-1',
      instructorName: newCourseInstructor,
      instructorTitle: 'SiHub Academy Senior Instructor',
      durationWeeks: newCourseWeeks,
      hoursPerWeek: 6,
      level: 'Beginner',
      deliveryMode: 'Online',
      capacity: 50,
      enrolledCount: 0,
      thumbnailUrl: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=600&auto=format&fit=crop&q=80',
      prerequisites: ['Basic logical thinking and dedication'],
      learningOutcomes: ['Understand modern architecture principles', 'Deploy practical solution'],
      isPublished: true,
      createdAt: new Date().toISOString(),
      modules: [
        {
          id: `mod-${Date.now()}-1`,
          courseId: `crs-${Date.now()}`,
          title: 'Module 1: Foundations & Architecture',
          order: 1,
          lessons: [
            {
              id: `les-${Date.now()}-1`,
              moduleId: `mod-${Date.now()}-1`,
              title: '1.1 Orientation and Setup',
              type: 'video',
              durationMinutes: 30,
              textContent: 'Welcome to the course orientation session.'
            }
          ]
        }
      ]
    };

    StorageService.saveCourse(newCourse);
    setShowNewCourseModal(false);
    setNewCourseTitle('');
    setNewCourseDesc('');
    triggerRefresh();
    addToast('success', 'Course Created', `"${newCourse.title}" is now published.`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.3 • Education & LMS Administration
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Learning Management System Control Center
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage course offerings, learning modules, and review student enrollment applications requiring administrative authorization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNewCourseModal(true)}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" /> Create Demonstration Course
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-800 space-x-2">
        <button
          onClick={() => setActiveTab('enrollments')}
          className={`pb-3 px-3 text-xs font-bold transition-colors flex items-center gap-2 border-b-2 ${
            activeTab === 'enrollments'
              ? 'border-cyan-500 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <span>Enrollment Applications Review</span>
          {pendingEnrollments.length > 0 && (
            <span className="px-2 py-0.2 rounded-full text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
              {pendingEnrollments.length} Pending
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('courses')}
          className={`pb-3 px-3 text-xs font-bold transition-colors border-b-2 ${
            activeTab === 'courses'
              ? 'border-cyan-500 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          Course Management ({courses.length})
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`pb-3 px-3 text-xs font-bold transition-colors border-b-2 ${
            activeTab === 'reports'
              ? 'border-cyan-500 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          LMS Academic Reports
        </button>
      </div>

      {/* Tab 1: Enrollment Applications & Approvals Desk */}
      {activeTab === 'enrollments' && (
        <div className="space-y-6">
          {/* Business rule info callout */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-semibold">LMS Enrollment Approval Workflow:</strong>
              <p className="mt-0.5 text-slate-400 text-[11px] leading-relaxed">
                When a student submits a course application, it enters the queue below as <strong>Pending</strong>. Clicking <strong>"Approve Access"</strong> activates their enrollment record, unlocking the lesson videos, reading materials, quizzes, and certificate generator in their Learner Dashboard!
              </p>
            </div>
          </div>

          {/* Pending Applications Queue */}
          <div className="bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center justify-between">
              <span>Pending Enrollment Applications ({pendingEnrollments.length})</span>
              <span className="text-[10px] text-slate-400 font-mono">Requires Action</span>
            </h3>

            {pendingEnrollments.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 rounded-xl bg-slate-900/50 border border-slate-800/80">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                All student enrollment applications have been processed.
              </div>
            ) : (
              <div className="space-y-3">
                {pendingEnrollments.map(enr => (
                  <div
                    key={enr.id}
                    className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs"
                  >
                    <div className="space-y-1.5 max-w-xl">
                      <div className="flex items-center gap-2">
                        <strong className="text-white text-sm">{enr.userName}</strong>
                        <span className="text-[10px] text-slate-400 font-mono">{enr.userEmail}</span>
                        <span className="text-[10px] text-slate-400">({enr.userPhone})</span>
                      </div>
                      <div className="text-cyan-400 font-semibold">{enr.courseTitle}</div>
                      <p className="text-slate-300 text-[11px] bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                        <strong className="text-slate-400 uppercase text-[9px] block">Motivation Statement:</strong>
                        "{enr.motivation}"
                      </p>
                      <div className="text-[10px] text-slate-500 font-mono">
                        Applied on: {new Date(enr.appliedAt).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleApprove(enr.id, enr.userName, enr.courseTitle)}
                        className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
                      >
                        Approve Access
                      </button>
                      <button
                        onClick={() => setRejectingEnrollment(enr)}
                        className="px-4 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 font-bold text-xs transition-colors"
                      >
                        Reject with Reason
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Approved & Active Enrollments Table */}
          <div className="bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center justify-between">
              <span>Active Enrolled Learners ({approvedEnrollments.length})</span>
              <span className="text-[10px] text-emerald-400 font-mono">Approved Access</span>
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800 uppercase text-[10px] font-mono">
                  <tr>
                    <th className="py-2.5 px-3">Student</th>
                    <th className="py-2.5 px-3">Course</th>
                    <th className="py-2.5 px-3">Progress</th>
                    <th className="py-2.5 px-3">Certificate</th>
                    <th className="py-2.5 px-3">Approved Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {approvedEnrollments.map(item => (
                    <tr key={item.id} className="hover:bg-slate-900/50">
                      <td className="py-3 px-3">
                        <strong className="text-white block">{item.userName}</strong>
                        <span className="text-[11px] text-slate-500">{item.userEmail}</span>
                      </td>
                      <td className="py-3 px-3 text-cyan-300 font-medium">
                        {item.courseTitle}
                      </td>
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div
                              className="bg-cyan-500 h-full rounded-full"
                              style={{ width: `${item.progressPercent}%` }}
                            />
                          </div>
                          <span className="text-[11px] font-mono text-cyan-400 font-bold">
                            {item.progressPercent}%
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        {item.certificateIssued ? (
                          <span className="inline-flex items-center gap-1 text-emerald-400 text-[11px] font-semibold">
                            <Award className="w-3.5 h-3.5" /> Issued
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[11px]">In Progress</span>
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-400">
                        {item.reviewedAt ? new Date(item.reviewedAt).toLocaleDateString() : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Course Management */}
      {activeTab === 'courses' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map(course => (
              <div
                key={course.id}
                className="bg-slate-950 rounded-2xl border border-slate-800 p-5 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                      {course.category}
                    </span>
                    <button
                      onClick={() => handleTogglePublish(course.id)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        course.isPublished
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {course.isPublished ? '● Published' : 'Draft'}
                    </button>
                  </div>

                  <h3 className="text-base font-bold text-white leading-snug">{course.title}</h3>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{course.description}</p>

                  <div className="text-xs text-slate-400 space-y-1 pt-2 border-t border-slate-800/80">
                    <div>Instructor: <strong className="text-slate-200">{course.instructorName}</strong></div>
                    <div>Capacity: <strong className="text-slate-200">{course.enrolledCount} / {course.capacity} Students</strong></div>
                    <div>Modules: <strong className="text-slate-200">{course.modules.length} Modules</strong></div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setSelectedCourseForLearn(course)}
                    className="flex-1 py-1.5 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 font-bold text-xs border border-cyan-500/40 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <BookOpen className="w-3.5 h-3.5" /> Preview Player
                  </button>
                  <button
                    onClick={() => handleDeleteCourse(course.id)}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-300 transition-colors"
                    title="Delete Course"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Academic Reports */}
      {activeTab === 'reports' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-medium">Total Registered Learners</span>
            <div className="text-3xl font-extrabold text-white">{enrollments.length}</div>
            <p className="text-[11px] text-cyan-400">Across 6 academic tracks</p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-medium">Approval Ratio</span>
            <div className="text-3xl font-extrabold text-emerald-400">
              {Math.round((approvedEnrollments.length / Math.max(1, enrollments.length)) * 100)}%
            </div>
            <p className="text-[11px] text-slate-400">Admitted based on prerequisite verification</p>
          </div>
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-medium">Average Course Completion</span>
            <div className="text-3xl font-extrabold text-amber-400">62%</div>
            <p className="text-[11px] text-slate-400">Online video & quiz engagement</p>
          </div>
        </div>
      )}

      {/* Rejection Modal with Reason */}
      {rejectingEnrollment && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-md w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-rose-400 flex items-center gap-2">
                <XCircle className="w-4 h-4" /> Reject Enrollment Application
              </h3>
              <button onClick={() => setRejectingEnrollment(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Please specify the institutional reason for declining {rejectingEnrollment.userName}'s application for "{rejectingEnrollment.courseTitle}":
            </p>

            <form onSubmit={handleConfirmReject} className="space-y-4 text-xs">
              <textarea
                required
                rows={3}
                value={rejectReason}
                onChange={e => setRejectReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-rose-500 resize-none"
              />

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRejectingEnrollment(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Course Modal */}
      {showNewCourseModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-xl w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" /> Create Demonstration LMS Course
              </h3>
              <button onClick={() => setShowNewCourseModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCourse} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Course Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Distributed Cloud & Microservices..."
                  value={newCourseTitle}
                  onChange={e => setNewCourseTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Category</label>
                  <select
                    value={newCourseCategory}
                    onChange={e => setNewCourseCategory(e.target.value as CourseCategory)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Technology & Software">Technology & Software</option>
                    <option value="Renewable Energy & Climate">Renewable Energy</option>
                    <option value="AgriTech & Food Security">AgriTech & Food</option>
                    <option value="Digital Entrepreneurship">Entrepreneurship</option>
                    <option value="Data & AI">Data & AI</option>
                    <option value="Health & MedTech">Health & MedTech</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Duration (Weeks)</label>
                  <input
                    type="number"
                    min={2}
                    max={24}
                    value={newCourseWeeks}
                    onChange={e => setNewCourseWeeks(parseInt(e.target.value) || 8)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Lead Instructor</label>
                <input
                  type="text"
                  required
                  value={newCourseInstructor}
                  onChange={e => setNewCourseInstructor(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Course Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Outline syllabus content, target learning outcomes..."
                  value={newCourseDesc}
                  onChange={e => setNewCourseDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewCourseModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                >
                  Publish Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
