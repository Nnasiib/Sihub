/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.9 Mentorship Administration
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Compass, CheckCircle2, Clock, Users, Video, Calendar, Star } from 'lucide-react';

export const AdminMentorship: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const mentors = StorageService.getMentors();
  const requests = StorageService.getMentorshipRequests();

  const handleAccept = (reqId: string, menteeName: string) => {
    StorageService.updateMentorshipStatus(reqId, 'accepted', 'https://meet.google.com/sihub-mentor-session');
    triggerRefresh();
    addToast('success', 'Request Accepted', `Assigned meeting link for ${menteeName}.`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider font-mono">
            Module 6.9 • Mentorship Coordination Desk
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Advisor Matching & 1-on-1 Sessions
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage diaspora mentor rosters, review mentee advisory requests, and monitor video consultation logs.
          </p>
        </div>
      </div>

      {/* Requests Queue */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>Active Mentorship Inquiries ({requests.length})</span>
          <span className="text-xs text-slate-500 font-mono">Schedule & Match</span>
        </h3>

        <div className="space-y-3">
          {requests.map(req => (
            <div key={req.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
              <div className="space-y-1 max-w-xl">
                <div className="flex items-center gap-2">
                  <strong className="text-white text-sm">{req.menteeName}</strong>
                  <span className="text-slate-400 font-mono text-[11px]">&rarr; {req.mentorName}</span>
                </div>
                <div className="text-indigo-300 font-medium">{req.topic}</div>
                <div className="text-slate-500 text-[11px]">Preferred slot: {req.preferredSlot}</div>
                {req.meetingLink && (
                  <div className="text-emerald-400 font-mono text-[11px] flex items-center gap-1">
                    <Video className="w-3.5 h-3.5" /> Meeting Link: {req.meetingLink}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {req.status === 'pending' ? (
                  <button
                    onClick={() => handleAccept(req.id, req.menteeName)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs"
                  >
                    Confirm & Dispatch Link
                  </button>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold text-[10px]">
                    Confirmed
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Mentors Roster */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {mentors.map(m => (
          <div key={m.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center gap-3">
              <img src={m.avatarUrl} alt={m.name} className="w-12 h-12 rounded-xl object-cover" />
              <div>
                <h4 className="text-sm font-bold text-white">{m.name}</h4>
                <p className="text-[11px] text-indigo-400">{m.title}</p>
                <p className="text-[10px] text-slate-500">{m.organization}</p>
              </div>
            </div>
            <div className="text-xs text-slate-400 flex justify-between pt-2 border-t border-slate-800">
              <span className="flex items-center gap-1 text-amber-400 font-bold"><Star className="w-3 h-3 fill-amber-400" /> {m.rating}</span>
              <span>{m.totalMenteesHelped} Advised</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
