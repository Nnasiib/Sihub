/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.11 Partnerships & MOUs Administration
 */

import React from 'react';
import { StorageService } from '../../services/storageService';
import { Handshake, FileCheck, CheckCircle2, Globe, Building } from 'lucide-react';

export const AdminPartnerships: React.FC = () => {
  const partners = StorageService.getPartners();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-teal-400 uppercase tracking-wider font-mono">
            Module 6.11 • Institutional Partnerships & MOUs
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Multilateral Coalitions & Donor Alignment
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Maintain active memorandum of understanding (MOU) records with UN agencies, telecoms, and academic institutions.
          </p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800 uppercase text-[10px] font-mono">
              <tr>
                <th className="py-3 px-4">Partner Organization</th>
                <th className="py-3 px-4">Classification</th>
                <th className="py-3 px-4">Focal Person</th>
                <th className="py-3 px-4">Active Collaborative Tracks</th>
                <th className="py-3 px-4">MOU Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {partners.map(p => (
                <tr key={p.id} className="hover:bg-slate-900/50">
                  <td className="py-3.5 px-4">
                    <strong className="text-white block font-medium">{p.name}</strong>
                    <span className="text-[11px] text-slate-500">{p.country}</span>
                  </td>
                  <td className="py-3.5 px-4 text-cyan-300">
                    {p.type}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300">
                    {p.contactPerson}
                  </td>
                  <td className="py-3.5 px-4 text-[11px] text-slate-400">
                    {p.collaborativePrograms.join(', ')}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      <FileCheck className="w-3 h-3" /> {p.mouStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
