/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.6 Programs & Cohorts Administration
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Program } from '../../types';
import { Layers, Plus, Calendar, Users, CheckCircle2, X } from 'lucide-react';

export const AdminPrograms: React.FC = () => {
  const { addToast, triggerRefresh } = useApp();
  const programs = StorageService.getPrograms();

  const [showModal, setShowModal] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Program['category']>('Incubation');
  const [duration, setDuration] = useState('6 Months');
  const [cohortSize, setCohortSize] = useState(15);
  const [deadline, setDeadline] = useState('2026-12-30');
  const [coordinator, setCoordinator] = useState('Sharmarke Abdi Liban');
  const [summary, setSummary] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const newPrg: Program = {
      id: `prg-${Date.now()}`,
      title,
      category,
      summary,
      objectives: ['Milestone-based venture mentoring', 'Seed capital grant allocation'],
      targetAudience: 'Selected founders & graduates in Somalia',
      duration,
      eligibility: ['Functional prototype', '2+ dedicated founders'],
      cohortSize,
      status: 'Open',
      deadline,
      coordinator,
      thumbnailUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?w=600&auto=format&fit=crop&q=80'
    };

    StorageService.saveProgram(newPrg);
    setShowModal(false);
    triggerRefresh();
    addToast('success', 'Program Created', `"${newPrg.title}" is now active.`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.6 • Cohort Programs Management
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Program Portfolios & Residencies
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure accelerator batches, women in tech tracks, and specialized sector challenges.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-4 h-4" /> Create Cohort Program
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {programs.map(p => (
          <div key={p.id} className="bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                  {p.category}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold">● {p.status}</span>
              </div>
              <h3 className="text-base font-bold text-white leading-snug">{p.title}</h3>
              <p className="text-xs text-slate-400 line-clamp-3">{p.summary}</p>
              <div className="text-xs text-slate-500 space-y-1 pt-2 border-t border-slate-800">
                <div>Duration: <strong className="text-slate-300">{p.duration}</strong></div>
                <div>Cohort: <strong className="text-slate-300">{p.cohortSize} Participants</strong></div>
                <div>Lead: <strong className="text-slate-300">{p.coordinator}</strong></div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-between text-[11px] text-slate-400">
              <span>Deadline: <strong className="text-rose-400">{p.deadline}</strong></span>
              <span className="text-emerald-400 font-semibold">Active Cohort</span>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-700 p-6 text-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" /> Create Cohort Program
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Program Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Somali Youth Agrinnovation Cohort 2026..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as Program['category'])}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                  >
                    <option value="Incubation">Incubation</option>
                    <option value="Acceleration">Acceleration</option>
                    <option value="Women in Innovation">Women in Innovation</option>
                    <option value="Youth Tech">Youth Tech</option>
                    <option value="Seed Grant">Seed Grant</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Cohort Size</label>
                  <input
                    type="number"
                    min={5}
                    max={100}
                    value={cohortSize}
                    onChange={e => setCohortSize(parseInt(e.target.value) || 15)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Summary</label>
                <textarea
                  rows={3}
                  required
                  value={summary}
                  onChange={e => setSummary(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                >
                  Publish Program
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
