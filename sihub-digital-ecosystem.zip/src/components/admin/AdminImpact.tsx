/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.13 Impact & Monitoring Dashboard
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import {
  BarChart3,
  TrendingUp,
  Download,
  Award,
  Users,
  GraduationCap,
  Rocket,
  DollarSign,
  Heart,
  Globe2,
  FileSpreadsheet
} from 'lucide-react';

export const AdminImpact: React.FC = () => {
  const { addToast } = useApp();
  const impact = StorageService.getImpactMetrics();

  const handleDownloadCsv = () => {
    const csvContent = "data:text/csv;charset=utf-8," +
      "Metric,Value,Unit\n" +
      `Total Beneficiaries,${impact.totalBeneficiaries},Citizens\n` +
      `Certified Learners,${impact.learnersTrained},Students\n` +
      `Startups Accelerated,${impact.startupsSupported},Ventures\n` +
      `Jobs Created,${impact.jobsCreatedDirectly},Direct Jobs\n` +
      `Grant Capital Disbursed,${impact.grantsDisbursedUSD},USD\n` +
      `Women in Tech Ratio,${impact.womenParticipationRate},Percent\n` +
      `Completed R&D Projects,${impact.innovationProjectsCompleted},Projects\n` +
      `Institutional Partners,${impact.partnerOrganizations},Organizations\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sihub_impact_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    addToast('success', 'Report Exported', 'Downloaded official SiHub M&E metrics in CSV format.');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider font-mono">
            Module 6.13 • Monitoring & Evaluation (M&E)
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Organizational Impact & KPI Telemetry
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Verified developmental metrics tracking beneficiary reach, direct jobs, seed grant disbursements, and gender equity.
          </p>
        </div>

        <button
          onClick={handleDownloadCsv}
          className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-colors"
        >
          <FileSpreadsheet className="w-4 h-4" /> Download Official M&E CSV Report
        </button>
      </div>

      {/* Primary Impact Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Total Beneficiaries Reached</span>
          <div className="text-3xl font-extrabold text-cyan-400 font-heading">
            {impact.totalBeneficiaries.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">Across 5 federal member states</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Learners Certified</span>
          <div className="text-3xl font-extrabold text-emerald-400 font-heading">
            {impact.learnersTrained.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-400">Online LMS verified credentials</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Startups Accelerated</span>
          <div className="text-3xl font-extrabold text-amber-400 font-heading">
            {impact.startupsSupported}
          </div>
          <p className="text-[11px] text-amber-400">Across 5 incubation cohorts</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <span className="text-xs font-medium text-slate-400">Direct Jobs Created</span>
          <div className="text-3xl font-extrabold text-purple-400 font-heading">
            {impact.jobsCreatedDirectly}+
          </div>
          <p className="text-[11px] text-slate-500">In technology & agriculture logistics</p>
        </div>
      </div>

      {/* Sustainable Development Goals Alignment */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-950 border border-slate-800 space-y-6">
        <div>
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest font-mono">
            United Nations SDG Alignment
          </span>
          <h3 className="text-lg font-bold text-white mt-1">Multi-Sector Developmental Contributions</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <strong className="text-amber-400 font-bold block text-sm">SDG 7: Clean & Affordable Energy</strong>
            <p className="text-slate-300 leading-relaxed">
              Decentralized solar micro-grids and battery testing in Garowe reducing small business power costs by 45%.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <strong className="text-emerald-400 font-bold block text-sm">SDG 2: Zero Hunger & Food Security</strong>
            <p className="text-slate-300 leading-relaxed">
              Solar camel milk chilling networks cutting rural pastoral spoilage from 40% down to under 4%.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <strong className="text-cyan-400 font-bold block text-sm">SDG 8: Decent Work & Economic Growth</strong>
            <p className="text-slate-300 leading-relaxed">
              Over $460,000 in equity-free catalytic seed grants disbursed to young innovators with 44% female participation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
