/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - 6.7 Community Administration
 */

import React from 'react';
import { StorageService } from '../../services/storageService';
import { Users2, MapPin, MessageSquare, Award, CheckCircle } from 'lucide-react';

export const AdminCommunity: React.FC = () => {
  const members = StorageService.getCommunityMembers();
  const topics = StorageService.getForumTopics();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs font-bold text-sky-400 uppercase tracking-wider font-mono">
            Module 6.7 • Community Chapters & Moderation
          </span>
          <h1 className="text-2xl font-extrabold text-white font-heading mt-1">
            Grassroots Chapters & Forum Moderation
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Oversee regional youth ambassadors, active member registries, and technical knowledge exchange.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Members Roster */}
        <div className="lg:col-span-6 bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center justify-between">
            <span>Verified Community Ambassadors ({members.length})</span>
            <span className="text-[10px] text-slate-400 font-mono">Regional Nodes</span>
          </h3>

          <div className="space-y-2.5">
            {members.map(m => (
              <div key={m.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <strong className="text-white block font-medium">{m.name}</strong>
                  <span className="text-[11px] text-slate-400">{m.sectorInterest} • {m.city}</span>
                </div>
                <div>
                  {m.isAmbassador ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      Ambassador
                    </span>
                  ) : (
                    <span className="text-slate-500 text-[11px]">Member</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Discussions Moderation */}
        <div className="lg:col-span-6 bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center justify-between">
            <span>Community Discussions Moderation ({topics.length})</span>
            <span className="text-[10px] text-slate-400 font-mono">Real-Time Moderation</span>
          </h3>

          <div className="space-y-3">
            {topics.map(t => (
              <div key={t.id} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1.5">
                <div className="flex justify-between text-[10px]">
                  <span className="text-cyan-400 font-semibold">{t.category}</span>
                  <span className="text-slate-500 font-mono">{t.repliesCount} replies • {t.likesCount} endorsements</span>
                </div>
                <h4 className="font-bold text-white">{t.title}</h4>
                <p className="text-slate-400 text-[11px] line-clamp-2">{t.content}</p>
                <div className="flex justify-between text-[10px] text-slate-500 pt-1">
                  <span>Author: {t.author}</span>
                  <span className="text-emerald-400">Status: Approved</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
