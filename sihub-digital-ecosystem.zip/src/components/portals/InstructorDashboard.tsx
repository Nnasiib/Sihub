/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Instructor Dashboard
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import {
  Briefcase,
  BookOpen,
  Users,
  CheckCircle2,
  Award,
  Upload,
  PlayCircle
} from 'lucide-react';

export const InstructorDashboard: React.FC = () => {
  const { currentUser, setSelectedCourseForLearn, addToast } = useApp();
  const courses = StorageService.getCourses();
  const enrollments = StorageService.getEnrollments();

  const [activeTab, setActiveTab] = useState<'courses' | 'grading'>('courses');

  // Instructor's courses
  const myCourses = courses.filter(
    c => c.instructorName.includes('Abdullahi') || c.instructorName.includes('Hassan') || c.instructorId === currentUser.id
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider">
            <Briefcase className="w-4 h-4" /> Instructor Academic Desk
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading">
            Instructor Portal: {currentUser.fullName}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Manage your assigned courses, review student assignment submissions, monitor quiz pass rates, and issue course completion credentials.
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Assigned Courses</span>
          <div className="text-3xl font-extrabold text-indigo-700 font-heading">{myCourses.length}</div>
          <p className="text-[11px] text-slate-500">Active Curriculum</p>
        </div>
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Total Active Students</span>
          <div className="text-3xl font-extrabold text-cyan-700 font-heading">{enrollments.filter(e => e.status === 'approved').length}</div>
          <p className="text-[11px] text-slate-500">Across All Tracks</p>
        </div>
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Pending Assignments</span>
          <div className="text-3xl font-extrabold text-amber-600 font-heading">3</div>
          <p className="text-[11px] text-slate-500">Submissions to Grade</p>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-600" /> Assigned Courses
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {myCourses.map(course => (
            <div key={course.id} className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-lg transition-all space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 uppercase tracking-wider">
                  {course.category}
                </span>
                <h3 className="text-base font-bold text-slate-900">{course.title}</h3>
                <p className="text-xs text-slate-600 line-clamp-2">{course.description}</p>
                <div className="text-xs text-slate-500 pt-2 border-t border-slate-100 space-y-1">
                  <div>Enrolled: <strong className="text-slate-800">{course.enrolledCount} Students</strong></div>
                  <div>Modules: <strong className="text-slate-800">{course.modules.length} Modules</strong></div>
                </div>
              </div>

              <button
                onClick={() => setSelectedCourseForLearn(course)}
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2"
              >
                <PlayCircle className="w-4 h-4" /> Preview Curriculum & Player
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
