/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Student & Learner Dashboard ("My Learning")
 * Features approved courses, interactive lesson player launch, pending applications status, and certificates.
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Course } from '../../types';
import {
  GraduationCap,
  PlayCircle,
  Clock,
  Award,
  CheckCircle2,
  AlertCircle,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  FileText
} from 'lucide-react';

export const LearnerDashboard: React.FC = () => {
  const {
    currentUser,
    setSelectedCourseForLearn,
    setSelectedCourseForApply,
    navigateTo,
    switchRole
  } = useApp();

  const courses = StorageService.getCourses();
  const enrollments = StorageService.getEnrollments();

  // Enrollments for this user
  const userEnrollments = enrollments.filter(e => e.userId === currentUser.id);
  const approvedEnrollments = userEnrollments.filter(e => e.status === 'approved');
  const pendingEnrollments = userEnrollments.filter(e => e.status === 'pending');
  const rejectedEnrollments = userEnrollments.filter(e => e.status === 'rejected');

  const handleLaunchCourse = (courseId: string) => {
    const course = courses.find(c => c.id === courseId);
    if (course) {
      setSelectedCourseForLearn(course);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <GraduationCap className="w-4 h-4" /> SiHub Academy Learner Portal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading">
            Welcome back, {currentUser.fullName}!
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Track your coursework progress, complete quizzes, submit practical assignments, and earn verified credentials.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 shrink-0">
          <button
            onClick={() => navigateTo('courses')}
            className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
          >
            Browse Available Courses &rarr;
          </button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Approved Active Courses</span>
          <div className="text-3xl font-extrabold text-cyan-700 font-heading">
            {approvedEnrollments.length}
          </div>
          <p className="text-[11px] text-emerald-600 font-semibold">Unlocked Online Lessons</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Pending Admin Review</span>
          <div className="text-3xl font-extrabold text-amber-600 font-heading">
            {pendingEnrollments.length}
          </div>
          <p className="text-[11px] text-slate-500">Awaiting Admin Authorization</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Certificates Earned</span>
          <div className="text-3xl font-extrabold text-emerald-700 font-heading">
            {approvedEnrollments.filter(e => e.certificateIssued).length}
          </div>
          <p className="text-[11px] text-slate-500">Verified Credentials</p>
        </div>
      </div>

      {/* Section 1: My Active & Approved Learning Courses */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-cyan-600" />
            My Learning (Approved Access)
          </h2>
          <span className="text-xs text-slate-500 font-mono">
            {approvedEnrollments.length} Enrolled
          </span>
        </div>

        {approvedEnrollments.length === 0 ? (
          <div className="p-8 rounded-3xl bg-white border border-dashed border-slate-300 text-center space-y-3">
            <GraduationCap className="w-12 h-12 text-slate-400 mx-auto" />
            <h3 className="font-bold text-slate-900 text-sm">No Active Approved Courses Yet</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Once an administrator approves your course enrollment application, your course player will unlock here.
            </p>
            <button
              onClick={() => navigateTo('courses')}
              className="px-5 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs"
            >
              Browse Course Catalog
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {approvedEnrollments.map(enr => {
              const course = courses.find(c => c.id === enr.courseId);
              return (
                <div
                  key={enr.id}
                  className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-lg transition-all space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                        Approved Access
                      </span>
                      {enr.certificateIssued && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 flex items-center gap-1">
                          <Award className="w-3 h-3" /> Certified
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-slate-900 leading-snug">{enr.courseTitle}</h3>

                    {/* Progress Bar */}
                    <div className="space-y-1.5 pt-2">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Course Completion:</span>
                        <strong className="text-cyan-700 font-bold">{enr.progressPercent}%</strong>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-cyan-600 h-full rounded-full transition-all duration-300"
                          style={{ width: `${enr.progressPercent}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-xs text-slate-500 pt-1">
                      <span>Completed Lessons: </span>
                      <strong className="text-slate-800">{enr.completedLessonIds.length} lessons</strong>
                    </div>
                  </div>

                  <button
                    onClick={() => handleLaunchCourse(enr.courseId)}
                    className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <PlayCircle className="w-4 h-4" />
                    <span>Open Interactive Course Player</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Section 2: Pending Applications Status Tracker */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-600" />
            Pending Applications Status Tracker
          </h2>
          <span className="text-xs text-amber-600 font-mono font-bold">
            {pendingEnrollments.length} Under Review
          </span>
        </div>

        {pendingEnrollments.length === 0 ? (
          <div className="p-6 rounded-2xl bg-white border border-slate-200 text-xs text-slate-500 text-center">
            You have no pending course enrollment applications.
          </div>
        ) : (
          <div className="space-y-3">
            {pendingEnrollments.map(enr => (
              <div
                key={enr.id}
                className="bg-white rounded-2xl border border-amber-200 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
                    <strong className="text-sm text-slate-900">{enr.courseTitle}</strong>
                  </div>
                  <p className="text-xs text-slate-600">
                    Application submitted on {new Date(enr.appliedAt).toLocaleDateString()}. Status: <strong className="text-amber-700 font-semibold">Pending Admin Review</strong>.
                  </p>
                  <p className="text-[11px] text-slate-500 italic">
                    "Your motivation and prerequisites are currently being verified by SiHub instructors."
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      switchRole('admin');
                      navigateTo('admin', 'lms');
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs"
                  >
                    Switch to Admin Role & Approve Now &rarr;
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
