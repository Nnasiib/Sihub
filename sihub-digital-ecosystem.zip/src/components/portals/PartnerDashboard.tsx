/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Institutional Partner Dashboard
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Globe, FileCheck, Award, TrendingUp, CheckCircle2, Download } from 'lucide-react';

export const PartnerDashboard: React.FC = () => {
  const { addToast } = useApp();
  const impact = StorageService.getImpactMetrics();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-teal-400 text-xs font-semibold uppercase tracking-wider">
            <Globe className="w-4 h-4" /> Partner Directorate: UNDP Somalia Accelerator Labs
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading">
            Institutional Oversight & Program Telemetry
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Co-funded initiatives, milestone verification, and grant disbursement compliance across Somali regions.
          </p>
        </div>

        <button
          onClick={() => addToast('success', 'Report Exported', 'Downloaded certified joint donor impact audit.')}
          className="px-5 py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs shadow-md transition-colors flex items-center gap-2 shrink-0"
        >
          <Download className="w-4 h-4" /> Download Joint Audit Report
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Co-Funded Programs</span>
          <div className="text-3xl font-extrabold text-teal-700 font-heading">3 Cohorts</div>
          <p className="text-[11px] text-slate-500">SWITI, Climate Hack, AgriTech</p>
        </div>
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Joint Capital Allocated</span>
          <div className="text-3xl font-extrabold text-slate-900 font-mono">${(impact.grantsDisbursedUSD / 1000).toFixed(0)}k</div>
          <p className="text-[11px] text-emerald-600 font-semibold">100% Equity-Free</p>
        </div>
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">MOU Status</span>
          <div className="text-sm font-bold text-emerald-700 flex items-center gap-1.5 mt-2">
            <FileCheck className="w-4 h-4" /> Fully Ratified (2022-2027)
          </div>
          <p className="text-[11px] text-slate-500">Annual Audit Passed</p>
        </div>
      </div>
    </div>
  );
};
