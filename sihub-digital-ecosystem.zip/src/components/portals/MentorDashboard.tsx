/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Mentor Dashboard
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Compass, Users, Calendar, Video, Clock, Star } from 'lucide-react';

export const MentorDashboard: React.FC = () => {
  const { currentUser } = useApp();
  const requests = StorageService.getMentorshipRequests();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-purple-400 text-xs font-semibold uppercase tracking-wider">
            <Compass className="w-4 h-4" /> Mentor Portal: Zahra Osman Guled
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading">
            Advisory Desk & Mentee Scheduling
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Provide strategic feedback to early-stage founders and guide their commercial scaling across East Africa.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Assigned Mentees</span>
          <div className="text-3xl font-extrabold text-purple-700 font-heading">4 Startups</div>
          <p className="text-[11px] text-slate-500">Active Guidance</p>
        </div>
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Monthly Allocation</span>
          <div className="text-3xl font-extrabold text-cyan-700 font-heading">8 Hours</div>
          <p className="text-[11px] text-slate-500">Pro-Bono Diaspora Service</p>
        </div>
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Satisfaction Rating</span>
          <div className="text-3xl font-extrabold text-amber-600 font-heading">4.9 / 5.0</div>
          <p className="text-[11px] text-emerald-600 font-semibold">Top Rated Mentor</p>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-4 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900">Upcoming Mentorship Consultations</h2>
        <div className="space-y-3">
          {requests.map(req => (
            <div key={req.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
              <div className="space-y-1">
                <div className="font-bold text-slate-900 text-sm">{req.menteeName}</div>
                <div className="text-purple-700 font-medium">{req.topic}</div>
                <div className="text-slate-500 text-[11px]">Slot: {req.preferredSlot}</div>
              </div>

              <div className="flex items-center gap-3">
                <a
                  href={req.meetingLink || '#'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2"
                >
                  <Video className="w-4 h-4" /> Launch Consultation
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
