/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Startup Founder Dashboard
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import {
  Rocket,
  TrendingUp,
  DollarSign,
  Compass,
  CheckCircle2,
  Clock,
  Upload,
  Calendar,
  ExternalLink
} from 'lucide-react';

export const StartupDashboard: React.FC = () => {
  const { currentUser, navigateTo, addToast } = useApp();
  const startups = StorageService.getStartups();

  // Find founder startup or default to GeelTech
  const myStartup = startups.find(
    s => s.founderEmail === currentUser.email || s.founderName.includes('Abdirahman')
  ) || startups[0];

  const milestones = [
    { title: 'MVP Prototyping in SiHub Lab', status: 'completed' },
    { title: 'Pastoral Field Testing (450 Herders)', status: 'completed' },
    { title: 'EVC Plus Automated Mobile Money API', status: 'completed' },
    { title: 'Angel Demo Day Presentation', status: 'in_progress' },
    { title: 'Regional Commercial Rollout', status: 'upcoming' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
            <Rocket className="w-4 h-4" /> Founder Acceleration Portal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-heading">
            {myStartup.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            {myStartup.tagline} • Incubation Cohort: <strong>{myStartup.incubationCohort || 'Active Batch'}</strong>
          </p>
        </div>

        <div className="flex flex-wrap gap-2 shrink-0">
          <button
            onClick={() => navigateTo('mentorship')}
            className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors"
          >
            Book Mentor Consultation &rarr;
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Incubation Track</span>
          <div className="text-2xl font-bold text-emerald-700 font-heading">{myStartup.stage}</div>
          <p className="text-[11px] text-slate-500">{myStartup.sector}</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Seed Funding</span>
          <div className="text-2xl font-bold text-slate-900 font-mono">{myStartup.fundingRaised}</div>
          <p className="text-[11px] text-emerald-600 font-semibold">Disbursed to Date</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Assigned Lead Mentor</span>
          <div className="text-sm font-bold text-slate-900 truncate">{myStartup.mentorAssigned || 'Zahra Osman Guled'}</div>
          <p className="text-[11px] text-indigo-600">Diaspora Angel Advisory</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-xs text-slate-500 font-medium">Demo Day Pitch Slot</span>
          <div className="text-sm font-bold text-purple-700 font-mono">Confirmed (Slot #4)</div>
          <p className="text-[11px] text-slate-500">Dec 18, 2026</p>
        </div>
      </div>

      {/* Milestones and Pitch Deck */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Milestones */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-5 shadow-xs">
          <h2 className="text-lg font-bold text-slate-900 flex items-center justify-between">
            <span>Incubation Milestones Tracker</span>
            <span className="text-xs text-emerald-600 font-mono font-bold">75% Completed</span>
          </h2>

          <div className="space-y-3">
            {milestones.map((m, i) => (
              <div key={i} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs">
                <span className={`flex items-center gap-2.5 ${m.status === 'completed' ? 'text-slate-900 font-semibold' : 'text-slate-600'}`}>
                  {m.status === 'completed' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  ) : m.status === 'in_progress' ? (
                    <Clock className="w-4 h-4 text-amber-500 shrink-0 animate-spin" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300 shrink-0" />
                  )}
                  {m.title}
                </span>
                <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                  m.status === 'completed'
                    ? 'bg-emerald-100 text-emerald-800'
                    : m.status === 'in_progress'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-slate-200 text-slate-600'
                }`}>
                  {m.status.replace('_', ' ')}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Investor Pitch Deck Mockup */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 space-y-5 shadow-xs">
          <h2 className="text-lg font-bold text-slate-900">Investor Readiness Asset</h2>
          <div className="p-5 rounded-2xl bg-slate-50 border border-dashed border-slate-300 text-center space-y-3">
            <Upload className="w-8 h-8 text-emerald-600 mx-auto" />
            <div>
              <strong className="text-xs text-slate-900 block font-bold">GeelTech_Seed_Pitch_Deck_v3.pdf</strong>
              <span className="text-[10px] text-slate-400">12 Slides • Audited by Zahra Guled</span>
            </div>
            <button
              onClick={() => addToast('info', 'Pitch Deck Download', 'Downloading pitch deck to local device...')}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs"
            >
              Download Pitch Deck
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
