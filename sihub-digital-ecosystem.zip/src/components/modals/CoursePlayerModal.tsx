/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Interactive Online LMS Course Player & Assessment Environment
 * Features video player, PDF reader, assignment submission, interactive quiz, and certificate generator.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Lesson, Enrollment } from '../../types';
import { StorageService } from '../../services/storageService';
import {
  X,
  PlayCircle,
  FileText,
  BookOpen,
  Award,
  CheckCircle2,
  Circle,
  Upload,
  Send,
  HelpCircle,
  Check,
  Printer
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';

export const CoursePlayerModal: React.FC = () => {
  const {
    selectedCourseForLearn,
    setSelectedCourseForLearn,
    currentUser,
    addToast,
    triggerRefresh
  } = useApp();

  const enrollments = StorageService.getEnrollments();
  const enrollment: Enrollment | undefined = selectedCourseForLearn
    ? enrollments.find(e => e.courseId === selectedCourseForLearn.id && e.userId === currentUser.id)
    : undefined;

  // Flatten all lessons across modules
  const allLessons: Lesson[] = selectedCourseForLearn
    ? selectedCourseForLearn.modules.flatMap(m => m.lessons)
    : [];

  const [activeLessonId, setActiveLessonId] = useState<string>(
    allLessons.length > 0 ? allLessons[0].id : ''
  );

  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [assignmentText, setAssignmentText] = useState<string>('');
  const [assignmentSubmitted, setAssignmentSubmitted] = useState<boolean>(false);
  const [showCertificateModal, setShowCertificateModal] = useState<boolean>(false);

  if (!selectedCourseForLearn) return null;

  const activeLesson = allLessons.find(l => l.id === activeLessonId) || allLessons[0];
  const isLessonCompleted = enrollment?.completedLessonIds.includes(activeLesson?.id || '');

  const handleMarkComplete = (lessonId: string) => {
    if (!enrollment) return;
    StorageService.updateLessonProgress(enrollment.id, lessonId, allLessons.length);
    triggerRefresh();
    addToast('success', 'Lesson Completed', 'Progress recorded in your learner profile.');
  };

  const handleQuizSubmit = () => {
    if (!activeLesson?.quizQuestions) return;
    setQuizSubmitted(true);
    let correct = 0;
    activeLesson.quizQuestions.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswerIndex) {
        correct++;
      }
    });
    const scorePct = Math.round((correct / activeLesson.quizQuestions.length) * 100);
    handleMarkComplete(activeLesson.id);
    addToast('success', 'Quiz Evaluated', `You scored ${scorePct}% on this assessment!`);
  };

  const handleAssignmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAssignmentSubmitted(true);
    if (activeLesson) handleMarkComplete(activeLesson.id);
    addToast('success', 'Assignment Submitted', 'Your submission has been sent to instructor review.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-hidden">
      <div className="bg-slate-900 rounded-2xl shadow-2xl w-full max-w-6xl h-[92vh] flex flex-col border border-slate-800 text-slate-100 overflow-hidden">
        {/* Top Bar */}
        <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo size="sm" showSubtitle={false} lightText={true} />
            <div className="truncate">
              <span className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider block">
                SiHub Online Learning System
              </span>
              <h2 className="text-sm sm:text-base font-bold text-white truncate">
                {selectedCourseForLearn.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {enrollment?.certificateIssued && (
              <button
                onClick={() => setShowCertificateModal(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs shadow-md transition-colors"
              >
                <Award className="w-4 h-4" /> View Certificate
              </button>
            )}

            <div className="hidden md:flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
              <span className="text-slate-400">Progress:</span>
              <div className="w-24 bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-cyan-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${enrollment?.progressPercent || 0}%` }}
                />
              </div>
              <span className="font-bold text-cyan-400">{enrollment?.progressPercent || 0}%</span>
            </div>

            <button
              onClick={() => setSelectedCourseForLearn(null)}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body: Left Syllabus Navigation & Right Active Lesson Viewer */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* Left Navigation: Modules & Lessons */}
          <div className="w-full md:w-80 bg-slate-950/70 border-r border-slate-800 flex flex-col overflow-y-auto">
            <div className="p-4 border-b border-slate-800/80">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Course Syllabus</h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {selectedCourseForLearn.modules.length} Modules • {allLessons.length} Lessons
              </p>
            </div>

            <div className="p-3 space-y-4 flex-1">
              {selectedCourseForLearn.modules.map(module => (
                <div key={module.id} className="space-y-1">
                  <div className="text-[11px] font-bold text-slate-300 px-2 py-1 bg-slate-900/60 rounded">
                    {module.title}
                  </div>
                  <div className="space-y-0.5 mt-1">
                    {module.lessons.map(lesson => {
                      const isCompleted = enrollment?.completedLessonIds.includes(lesson.id);
                      const isCurrent = activeLesson?.id === lesson.id;
                      const icons = {
                        video: <PlayCircle className="w-3.5 h-3.5" />,
                        pdf: <FileText className="w-3.5 h-3.5" />,
                        reading: <BookOpen className="w-3.5 h-3.5" />,
                        assignment: <Upload className="w-3.5 h-3.5" />,
                        quiz: <HelpCircle className="w-3.5 h-3.5" />
                      };

                      return (
                        <button
                          key={lesson.id}
                          onClick={() => {
                            setActiveLessonId(lesson.id);
                            setQuizSubmitted(false);
                            setAssignmentSubmitted(false);
                          }}
                          className={`w-full flex items-center justify-between text-left px-2.5 py-2 rounded-lg text-xs transition-colors ${
                            isCurrent
                              ? 'bg-cyan-600/30 text-cyan-300 font-semibold border border-cyan-500/50'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className={isCurrent ? 'text-cyan-400' : 'text-slate-500'}>
                              {icons[lesson.type]}
                            </span>
                            <span className="truncate">{lesson.title}</span>
                          </div>
                          <div>
                            {isCompleted ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <Circle className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Area: Active Lesson Player */}
          <div className="flex-1 bg-slate-900 overflow-y-auto p-4 sm:p-6 flex flex-col justify-between">
            {activeLesson ? (
              <div className="space-y-6">
                {/* Lesson Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
                  <div>
                    <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                      {activeLesson.type} Lesson • {activeLesson.durationMinutes} Minutes
                    </span>
                    <h3 className="text-xl font-bold text-white mt-1">{activeLesson.title}</h3>
                  </div>

                  <button
                    onClick={() => handleMarkComplete(activeLesson.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm ${
                      isLessonCompleted
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-cyan-500 hover:bg-cyan-600 text-slate-950'
                    }`}
                  >
                    {isLessonCompleted ? (
                      <>
                        <Check className="w-4 h-4" /> Lesson Completed
                      </>
                    ) : (
                      <>Mark Lesson Complete</>
                    )}
                  </button>
                </div>

                {/* Lesson Type Specific Content */}
                {activeLesson.type === 'video' && (
                  <div className="space-y-4">
                    <div className="aspect-video w-full rounded-2xl bg-black border border-slate-800 overflow-hidden relative shadow-2xl flex items-center justify-center group">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />
                      <div className="text-center p-6 space-y-3 z-10">
                        <div className="w-16 h-16 rounded-full bg-cyan-500/90 hover:bg-cyan-400 text-slate-950 flex items-center justify-center mx-auto shadow-lg cursor-pointer transform group-hover:scale-105 transition-transform">
                          <PlayCircle className="w-10 h-10" />
                        </div>
                        <p className="text-xs text-slate-300 max-w-md font-mono">
                          Simulated High-Definition Video Stream • SiHub CDN Engine
                        </p>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-2">
                      <h4 className="font-bold text-white text-sm">Lesson Transcript & Overview:</h4>
                      <p className="leading-relaxed">
                        {activeLesson.textContent ||
                          'In this recorded session, our senior instructors guide you step-by-step through core theory, architecture patterns, and live coding exercises. Code snippets and references are linked in the study guide below.'}
                      </p>
                    </div>
                  </div>
                )}

                {activeLesson.type === 'pdf' && (
                  <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-rose-950/60 text-rose-400 flex items-center justify-center border border-rose-800/40">
                          <FileText className="w-6 h-6" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white">Course Document & Architecture Guide</h4>
                          <span className="text-[11px] text-slate-400">PDF Document • 24 Pages • 3.4 MB</span>
                        </div>
                      </div>
                      <button
                        onClick={() => addToast('info', 'PDF Download', 'Downloading document to local device...')}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
                      >
                        Download PDF
                      </button>
                    </div>

                    <div className="p-8 bg-slate-900 rounded-xl border border-dashed border-slate-700 text-center space-y-3">
                      <BookOpen className="w-12 h-12 text-slate-500 mx-auto" />
                      <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
                        {activeLesson.textContent ||
                          'Interactive online document viewer simulated. Contains high-resolution diagrams, flowcharts, and regulatory guidelines.'}
                      </p>
                      <button
                        onClick={() => addToast('info', 'Document Reader', 'Opening full screen PDF viewer...')}
                        className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs shadow-sm transition-colors"
                      >
                        Open In Full-Screen Reader
                      </button>
                    </div>
                  </div>
                )}

                {activeLesson.type === 'quiz' && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-800/50 text-xs text-cyan-200">
                      💡 <strong>Quiz Assessment:</strong> Answer the questions below and submit to evaluate your comprehension. A passing score records completion.
                    </div>

                    {activeLesson.quizQuestions?.map((question, qIdx) => (
                      <div key={question.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                        <h4 className="text-sm font-bold text-white">
                          Question {qIdx + 1}: {question.question}
                        </h4>
                        <div className="space-y-2 mt-2">
                          {question.options.map((opt, optIdx) => {
                            const isSelected = quizAnswers[question.id] === optIdx;
                            const isCorrect = question.correctAnswerIndex === optIdx;
                            let optionClass = 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800';

                            if (quizSubmitted) {
                              if (isCorrect) optionClass = 'bg-emerald-950/80 border-emerald-600 text-emerald-200 font-bold';
                              else if (isSelected && !isCorrect) optionClass = 'bg-rose-950/80 border-rose-600 text-rose-200 line-through';
                            } else if (isSelected) {
                              optionClass = 'bg-cyan-900/60 border-cyan-500 text-cyan-200 font-semibold';
                            }

                            return (
                              <button
                                key={optIdx}
                                disabled={quizSubmitted}
                                onClick={() => setQuizAnswers(prev => ({ ...prev, [question.id]: optIdx }))}
                                className={`w-full text-left p-3 rounded-xl border text-xs transition-colors flex items-center justify-between ${optionClass}`}
                              >
                                <span>{opt}</span>
                                {quizSubmitted && isCorrect && <Check className="w-4 h-4 text-emerald-400" />}
                              </button>
                            );
                          })}
                        </div>
                        {quizSubmitted && question.explanation && (
                          <div className="p-3 bg-slate-900 rounded-lg text-[11px] text-cyan-300 border-l-2 border-cyan-500">
                            <strong>Explanation:</strong> {question.explanation}
                          </div>
                        )}
                      </div>
                    ))}

                    {!quizSubmitted ? (
                      <button
                        onClick={handleQuizSubmit}
                        disabled={Object.keys(quizAnswers).length < (activeLesson.quizQuestions?.length || 1)}
                        className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4" /> Submit Quiz Answers
                      </button>
                    ) : (
                      <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-700 text-center space-y-2">
                        <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                        <h4 className="text-sm font-bold text-white">Quiz Evaluated Successfully!</h4>
                        <p className="text-xs text-slate-300">Your score has been stored in your learning profile.</p>
                      </div>
                    )}
                  </div>
                )}

                {activeLesson.type === 'assignment' && (
                  <form onSubmit={handleAssignmentSubmit} className="space-y-4">
                    <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                      <h4 className="text-sm font-bold text-cyan-300">Assignment Prompt</h4>
                      <p className="text-xs text-slate-200 leading-relaxed">
                        {activeLesson.assignmentPrompt ||
                          'Complete the practical task outlined in the module instructions and submit your documentation and code repository.'}
                      </p>
                    </div>

                    {assignmentSubmitted ? (
                      <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-700 text-center space-y-2">
                        <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                        <h4 className="text-sm font-bold text-white">Assignment Submitted!</h4>
                        <p className="text-xs text-slate-300">
                          Your submission has been dispatched to Dr. Hassan & SiHub instructors for grading.
                        </p>
                      </div>
                    ) : (
                      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-300 mb-1">
                            Your Solution & GitHub/Project Links
                          </label>
                          <textarea
                            required
                            rows={4}
                            value={assignmentText}
                            onChange={e => setAssignmentText(e.target.value)}
                            placeholder="Paste your GitHub repository link, deployment URL, or write your solution analysis..."
                            className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-hidden focus:border-cyan-500 resize-none"
                          />
                        </div>

                        <div className="p-4 rounded-xl border border-dashed border-slate-700 bg-slate-900/50 text-center cursor-pointer hover:border-cyan-500 transition-colors">
                          <Upload className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                          <span className="text-xs text-slate-300">Attach Document / ZIP File (Simulated)</span>
                          <span className="block text-[10px] text-slate-500">Max size 25MB • PDF, DOCX, ZIP</span>
                        </div>

                        <button
                          type="submit"
                          className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-2"
                        >
                          <Send className="w-4 h-4" /> Submit Assignment for Review
                        </button>
                      </div>
                    )}
                  </form>
                )}

                {activeLesson.type === 'reading' && (
                  <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 text-xs text-slate-200 leading-relaxed">
                    <h4 className="text-base font-bold text-white">Required Reading Material</h4>
                    <p>{activeLesson.textContent}</p>
                    <div className="p-4 rounded-xl bg-slate-900 border-l-4 border-emerald-500 text-slate-300">
                      <strong>Key Takeaway:</strong> In high-concurrency African deployments, designing with network resilience, low data consumption, and local offline cache guarantees system survival.
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">Select a lesson from the left syllabus to start.</div>
            )}
          </div>
        </div>
      </div>

      {/* Official Certificate of Completion Modal */}
      {showCertificateModal && (
        <div className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4">
          <div className="bg-white text-slate-900 rounded-3xl max-w-2xl w-full p-8 border-8 border-slate-100 shadow-2xl relative text-center space-y-6">
            <button
              onClick={() => setShowCertificateModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 p-2"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex justify-center">
              <BrandLogo size="lg" showSubtitle={true} />
            </div>

            <div className="border-y-2 border-slate-200 py-6 space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-cyan-700">
                Somali Innovation Hub Academy
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900">
                Certificate of Completion
              </h2>
              <p className="text-xs text-slate-500 italic">This is proudly awarded to</p>
              <h3 className="text-2xl font-bold text-slate-900 font-heading">
                {currentUser.fullName}
              </h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                for successfully fulfilling all curriculum requirements, quizzes, and practical assignments for the course:
              </p>
              <h4 className="text-base font-bold text-cyan-800">
                {selectedCourseForLearn.title}
              </h4>
            </div>

            <div className="flex items-center justify-between text-left text-xs text-slate-600 px-6">
              <div>
                <span className="block text-[10px] text-slate-400 uppercase font-mono">Date Issued</span>
                <strong>{enrollment?.certificateDate || '2026-11-02'}</strong>
              </div>
              <div className="text-center">
                <Award className="w-10 h-10 text-amber-500 mx-auto" />
                <span className="text-[9px] uppercase font-mono text-slate-400">Verified Credential</span>
              </div>
              <div className="text-right">
                <span className="block text-[10px] text-slate-400 uppercase font-mono">Certificate ID</span>
                <strong className="font-mono text-cyan-700">{enrollment?.certificateNumber || 'SIHUB-CERT-2026-001'}</strong>
              </div>
            </div>

            <div className="flex justify-center gap-3 pt-4">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs flex items-center gap-2 hover:bg-slate-800"
              >
                <Printer className="w-4 h-4" /> Print / Save PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
