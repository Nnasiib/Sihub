/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Event Registration & Digital QR Pass Generator
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import type { EventRegistration } from '../../types';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  QrCode,
  Download,
  CalendarPlus
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';

export const EventRegisterModal: React.FC = () => {
  const {
    selectedEventForRegister,
    setSelectedEventForRegister,
    currentUser,
    addToast,
    triggerRefresh
  } = useApp();

  const [registration, setRegistration] = useState<EventRegistration | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!selectedEventForRegister) return null;

  const handleClose = () => {
    setSelectedEventForRegister(null);
    setRegistration(null);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const reg = StorageService.registerForEvent(selectedEventForRegister, currentUser);
      setRegistration(reg);
      setIsSubmitting(false);
      triggerRefresh();
      addToast(
        'success',
        'Event Registered',
        `You have successfully registered for "${selectedEventForRegister.title}". Your digital QR pass is ready!`
      );
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-gradient-to-r from-slate-900 via-cyan-950 to-slate-900 p-6 text-white relative">
          <button
            onClick={handleClose}
            className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
          <span className="text-cyan-400 text-xs font-semibold uppercase tracking-wider block mb-1">
            SiHub Events & Community
          </span>
          <h3 className="text-xl font-bold pr-6">{selectedEventForRegister.title}</h3>
          <div className="flex flex-wrap gap-y-1 gap-x-4 text-xs text-slate-300 mt-2">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" /> {selectedEventForRegister.date}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-cyan-400" /> {selectedEventForRegister.time}
            </span>
          </div>
        </div>

        {registration ? (
          <div className="p-6 space-y-6">
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-1">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h4 className="text-base font-bold text-emerald-950">Registration Confirmed!</h4>
              <p className="text-xs text-emerald-700">Present this QR code pass at SiHub reception for fast scan check-in.</p>
            </div>

            {/* Visual Digital Ticket Badge */}
            <div className="border-2 border-slate-900 rounded-2xl p-5 bg-gradient-to-br from-slate-50 to-slate-100 shadow-inner relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-slate-900 text-cyan-300 px-3 py-1 text-[10px] font-mono font-bold rounded-bl-xl uppercase tracking-wider">
                {registration.ticketCode}
              </div>

              <div className="flex items-center gap-3 mb-4">
                <BrandLogo size="sm" showSubtitle={false} />
                <div>
                  <h5 className="text-xs font-bold text-slate-900">Official Access Pass</h5>
                  <span className="text-[10px] text-slate-500">Somali Innovation Hub Events</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-5 pt-3 border-t border-slate-200">
                {/* Simulated SVG High-Tech QR code */}
                <div className="w-28 h-28 bg-white p-2 rounded-xl shadow-xs border border-slate-300 flex items-center justify-center shrink-0">
                  <div className="w-full h-full bg-slate-900 rounded-lg p-2 flex flex-col justify-between">
                    <div className="flex justify-between">
                      <div className="w-5 h-5 bg-cyan-400 rounded-xs" />
                      <div className="w-5 h-5 bg-cyan-400 rounded-xs" />
                    </div>
                    <div className="flex items-center justify-center">
                      <QrCode className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex justify-between">
                      <div className="w-5 h-5 bg-cyan-400 rounded-xs" />
                      <div className="w-2 h-2 bg-emerald-400 rounded-full" />
                    </div>
                  </div>
                </div>

                <div className="text-left text-xs space-y-1.5 flex-1 min-w-0">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-mono">Attendee Name</span>
                    <strong className="text-slate-900 truncate block">{registration.userName}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-mono">Venue & Access</span>
                    <span className="text-slate-700 text-[11px] block truncate">{selectedEventForRegister.venue}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-mono">Status</span>
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      Confirmed Entry Pass
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => addToast('info', 'Pass Downloaded', 'Your digital entry pass has been downloaded.')}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" /> Save Ticket
              </button>
              <button
                onClick={() => addToast('info', 'Calendar Added', 'Event synced to your default calendar.')}
                className="py-2.5 px-4 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-900 font-bold text-xs flex items-center justify-center gap-2 border border-cyan-200"
              >
                <CalendarPlus className="w-4 h-4" /> Add to Calendar
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleRegister} className="p-6 space-y-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-1">
              <div className="flex items-center gap-1.5 text-slate-900 font-bold">
                <MapPin className="w-4 h-4 text-cyan-600" /> Venue:
              </div>
              <p>{selectedEventForRegister.venue}</p>
              <div className="pt-2 text-slate-500">
                Keynote / Lead: <strong>{selectedEventForRegister.speaker}</strong>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  defaultValue={currentUser.fullName}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  defaultValue={currentUser.email}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Organization / Sector</label>
                <input
                  type="text"
                  placeholder="e.g. SIMAD University, Self-Employed, Ministry..."
                  defaultValue={currentUser.organization || 'Independent Innovator'}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={handleClose}
                className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-700 shadow-sm flex items-center gap-2"
              >
                {isSubmitting ? 'Registering...' : 'Confirm Free Registration & Get Pass'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
