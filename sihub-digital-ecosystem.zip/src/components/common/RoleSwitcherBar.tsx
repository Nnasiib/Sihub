/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Interactive Role Demonstration Banner
 * Enables executives and stakeholders to inspect all 11 user experiences.
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  Users,
  GraduationCap,
  Sparkles,
  RotateCcw,
  Globe,
  Layers,
  Bot,
  Briefcase,
  ChevronDown,
  X,
  Compass
} from 'lucide-react';

export const RoleSwitcherBar: React.FC = () => {
  const {
    activeRole,
    switchRole,
    currentUser,
    language,
    setLanguage,
    resetDemoData,
    setIsAiAssistantOpen,
    currentView,
    navigateTo
  } = useApp();

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  const rolesList: { id: UserRole; label: string; labelSo: string; icon: React.ReactNode; color: string }[] = [
    { id: 'visitor', label: 'Visitor (Public)', labelSo: 'Boozde (Dadweyne)', icon: <Compass className="w-4 h-4" />, color: 'bg-slate-100 text-slate-800' },
    { id: 'learner', label: 'Student / Learner', labelSo: 'Arday / Barte', icon: <GraduationCap className="w-4 h-4" />, color: 'bg-emerald-100 text-emerald-800' },
    { id: 'instructor', label: 'Instructor', labelSo: 'Macallin / Tababare', icon: <Briefcase className="w-4 h-4" />, color: 'bg-indigo-100 text-indigo-800' },
    { id: 'startup_founder', label: 'Startup Founder', labelSo: 'Aasaase Shirkad', icon: <Sparkles className="w-4 h-4" />, color: 'bg-amber-100 text-amber-800' },
    { id: 'mentor', label: 'Mentor / Advisor', labelSo: 'La-taliye Sare', icon: <Users className="w-4 h-4" />, color: 'bg-purple-100 text-purple-800' },
    { id: 'community_member', label: 'Community Member', labelSo: 'Xubin Bulshada', icon: <Users className="w-4 h-4" />, color: 'bg-sky-100 text-sky-800' },
    { id: 'staff', label: 'Staff Member', labelSo: 'Shaqaale SiHub', icon: <Layers className="w-4 h-4" />, color: 'bg-blue-100 text-blue-800' },
    { id: 'partner', label: 'Partner (UNDP/Corporate)', labelSo: 'Bah-wadaag', icon: <Globe className="w-4 h-4" />, color: 'bg-teal-100 text-teal-800' },
    { id: 'program_manager', label: 'Program Manager', labelSo: 'Maamulaha Barnaamijyada', icon: <Layers className="w-4 h-4" />, color: 'bg-violet-100 text-violet-800' },
    { id: 'admin', label: 'Administrator', labelSo: 'Maamule (Admin)', icon: <Briefcase className="w-4 h-4" />, color: 'bg-rose-100 text-rose-800' },
    { id: 'super_admin', label: 'Super Administrator', labelSo: 'Maamulaha Guud', icon: <Sparkles className="w-4 h-4" />, color: 'bg-red-100 text-red-900' }
  ];

  const currentRoleObj = rolesList.find(r => r.id === activeRole) || rolesList[0];

  return (
    <div className="bg-slate-900 text-slate-100 border-b border-slate-800 text-xs py-2 px-3 sm:px-6 relative z-50 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left: Demo Mode Indicator & Role Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-cyan-950/80 text-cyan-300 px-2.5 py-1 rounded-md border border-cyan-800/60 font-semibold tracking-wide uppercase text-[10px]">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            Phase 1 Interactive Demo
          </div>

          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white font-medium px-3 py-1.5 rounded-lg border border-slate-700 transition-colors shadow-xs"
            >
              <span className="text-slate-400 font-normal">Persona:</span>
              <span className={`px-2 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1.5 ${currentRoleObj.color}`}>
                {currentRoleObj.icon}
                {language === 'so' ? currentRoleObj.labelSo : currentRoleObj.label}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {isDropdownOpen && (
              <div className="absolute left-0 mt-2 w-80 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 z-50 backdrop-blur-md">
                <div className="px-3 py-2 border-b border-slate-800 text-slate-400 text-[11px]">
                  Select any persona to test dedicated permissions, workflows, and portals:
                </div>
                <div className="max-h-72 overflow-y-auto py-1 space-y-1">
                  {rolesList.map(r => (
                    <button
                      key={r.id}
                      onClick={() => {
                        switchRole(r.id);
                        setIsDropdownOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left text-xs transition-colors ${
                        activeRole === r.id
                          ? 'bg-cyan-600/30 text-cyan-300 font-semibold border border-cyan-500/50'
                          : 'hover:bg-slate-800 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className={`p-1.5 rounded-md ${r.color}`}>
                          {r.icon}
                        </span>
                        <div>
                          <div>{language === 'so' ? r.labelSo : r.label}</div>
                          <div className="text-[10px] text-slate-400 font-normal">
                            {r.id.replace('_', ' ')}
                          </div>
                        </div>
                      </div>
                      {activeRole === r.id && (
                        <span className="text-cyan-400 text-[10px] bg-cyan-950 px-2 py-0.5 rounded font-mono">
                          ACTIVE
                        </span>
                      )}
                    </button>
                  ))}
                </div>
                <div className="p-2 border-t border-slate-800 text-[10px] text-slate-500 bg-slate-950/50 rounded-b-lg">
                  * Note: Client-side switching is for demo review. Phase 2 implements OAuth2 & PostgreSQL RBAC.
                </div>
              </div>
            )}
          </div>

          <span className="hidden md:inline-block text-slate-400 truncate max-w-xs">
            Logged in as: <strong className="text-slate-200">{currentUser.fullName}</strong>
          </span>
        </div>

        {/* Right: Actions, AI Assistant, Language Switcher, Reset */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Nav shortcut to Admin or Website */}
          {currentView === 'admin' ? (
            <button
              onClick={() => navigateTo('home')}
              className="bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/30 px-2.5 py-1 rounded-md font-medium transition-colors"
            >
              Public Website &rarr;
            </button>
          ) : (
            <button
              onClick={() => navigateTo('admin')}
              className="bg-cyan-600/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-600/30 px-2.5 py-1 rounded-md font-medium transition-colors"
            >
              Admin Dashboard &rarr;
            </button>
          )}

          {/* AI Assistant Button */}
          <button
            onClick={() => setIsAiAssistantOpen(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-medium px-3 py-1 rounded-md shadow-xs transition-all"
            title="Open SiHub AI Assistant"
          >
            <Bot className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">SiHub AI</span>
          </button>

          {/* Language Switcher */}
          <div className="flex items-center bg-slate-800 border border-slate-700 rounded-lg p-0.5">
            <button
              onClick={() => setLanguage('en')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                language === 'en'
                  ? 'bg-cyan-500 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage('so')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                language === 'so'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              SO
            </button>
          </div>

          {/* Reset Demo Data Button */}
          <button
            onClick={() => setShowConfirmReset(true)}
            title="Reset demo data to initial factory state"
            className="text-slate-400 hover:text-amber-400 p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Resetting Demo */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-base text-amber-400 flex items-center gap-2">
                <RotateCcw className="w-4 h-4" /> Reset Demo Records?
              </h3>
              <button
                onClick={() => setShowConfirmReset(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-300 mt-4 leading-relaxed">
              This will restore all courses, enrollment requests, startup records, and innovation milestones to their pristine demonstration defaults.
            </p>
            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetDemoData();
                  setShowConfirmReset(false);
                }}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs"
              >
                Yes, Reset Demo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
