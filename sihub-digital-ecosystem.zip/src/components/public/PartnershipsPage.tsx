/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Strategic Partnerships & Institutional Collaboration
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import {
  Globe,
  Building,
  CheckCircle2,
  Handshake,
  Send,
  FileCheck,
  ShieldCheck
} from 'lucide-react';

export const PartnershipsPage: React.FC = () => {
  const { currentUser, addToast } = useApp();
  const partners = StorageService.getPartners();

  const [orgName, setOrgName] = useState('');
  const [partnerType, setPartnerType] = useState('Development Agency');
  const [focusArea, setFocusArea] = useState('Clean Energy & Water Resilience');
  const [proposal, setProposal] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    addToast('success', 'Partnership Inquiry Sent', 'Our institutional partnerships directorate will review your proposal.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-teal-600">
          Strategic Alliances & Multilateral MOUs
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          SiHub Partnerships & Coalitions
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          We collaborate with multilateral United Nations agencies, Somali federal ministries, telecommunications operators, academic research centers, and diaspora venture syndicates.
        </p>
      </div>

      {/* Existing Partners Roster */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {partners.map(p => (
          <div
            key={p.id}
            className="p-6 rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-shadow space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800">
                  {p.type}
                </span>
                <span className="text-[10px] font-mono text-emerald-600 font-bold flex items-center gap-1">
                  <FileCheck className="w-3 h-3" /> {p.mouStatus}
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug">{p.name}</h3>
              <p className="text-xs text-slate-500">{p.contactPerson}</p>

              <div className="space-y-1 pt-2 border-t border-slate-100">
                <span className="text-[10px] font-bold uppercase text-slate-400 block">Joint Initiatives:</span>
                {p.collaborativePrograms.map((cp, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-700">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                    <span>{cp}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-[10px] text-slate-400 font-mono pt-2 border-t border-slate-100">
              Partner since {p.joinedYear} • {p.country}
            </div>
          </div>
        ))}
      </div>

      {/* Partnership Inquiry Form */}
      <div className="bg-gradient-to-br from-slate-900 to-teal-950 rounded-3xl p-8 sm:p-12 text-white shadow-xl max-w-4xl mx-auto space-y-6">
        <div className="space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-2">
            <Handshake className="w-4 h-4" /> Formal Collaboration
          </span>
          <h2 className="text-2xl font-bold font-heading">Partner with Somali Innovation Hub</h2>
          <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
            Whether your organization represents an international donor, commercial financial institution, university, or diaspora syndicate, submit a collaboration brief to engage our national network.
          </p>
        </div>

        {submitted ? (
          <div className="p-8 rounded-2xl bg-teal-900/60 border border-teal-700 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-teal-400 mx-auto" />
            <h3 className="text-lg font-bold text-white">MOU Inquiry Registered!</h3>
            <p className="text-xs text-slate-300">
              Our Director of Partnerships, Fadumo Ahmed Noor, will connect with your organization within 48 business hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Organization Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. World Bank, SIMAD, Swedish Aid..."
                  value={orgName}
                  onChange={e => setOrgName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-hidden focus:border-teal-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Partnership Category</label>
                <select
                  value={partnerType}
                  onChange={e => setPartnerType(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-hidden focus:border-teal-400"
                >
                  <option>Development Agency / UN</option>
                  <option>Institutional / Government</option>
                  <option>Corporate Sponsor & Telecom</option>
                  <option>Academic & University R&D</option>
                  <option>Diaspora Investment Syndicate</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Proposed Collaboration Focus Area</label>
              <input
                type="text"
                required
                value={focusArea}
                onChange={e => setFocusArea(e.target.value)}
                placeholder="e.g. Youth AgriTech Co-funding, Clean Energy Sandbox..."
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-hidden focus:border-teal-400"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Cooperation Scope & Objectives</label>
              <textarea
                rows={3}
                required
                placeholder="Briefly state your programmatic goals, target regions, and proposed resources..."
                defaultValue="We seek to establish a co-funded grant acceleration program for women entrepreneurs in clean tech across Mogadishu and Hargeisa."
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-hidden focus:border-teal-400 resize-none"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs shadow-md transition-colors flex items-center gap-2"
              >
                <Send className="w-4 h-4" /> Submit Partnership Proposal
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
