/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Contact, Regional Hub Locations & FAQ
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MapPin,
  Mail,
  Phone,
  Clock,
  Send,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Building
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { currentUser, addToast } = useApp();

  const [name, setName] = useState(currentUser.fullName);
  const [email, setEmail] = useState(currentUser.email);
  const [phone, setPhone] = useState(currentUser.phone || '+252 61 ');
  const [subject, setSubject] = useState('Inquiry regarding incubation cohort application');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const [openFaqIdx, setOpenFaqIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Is SiHub only focused on IT and software coding?',
      a: 'No. SiHub is a multi-sector innovation hub supporting agriculture (AgriTech & water irrigation), renewable clean energy (solar mini-grids & storage), public healthcare (telemedicine), digital entrepreneurship, and community resilience across all Somali regions.'
    },
    {
      q: 'Do I have to pay tuition to take SiHub Academy courses?',
      a: 'All currently listed professional courses are 100% grant-subsidized for accepted students. However, to maintain cohort quality and dedicated instructor mentorship, every course application requires administrative review and approval before learning modules unlock.'
    },
    {
      q: 'How does a startup qualify for the SiHub Flagship Incubation cohort?',
      a: 'Applicants must have at least two co-founders based in Somalia, a functional prototype or minimum viable product (MVP), and a clear problem statement addressing local needs. Accepted ventures receive $10,000 equity-free seed grants and workspace.'
    },
    {
      q: 'Where are SiHub physical MakerSpaces and labs located?',
      a: 'Our central headquarters and advanced MakerSpace is located along KM4 Airport Road in Mogadishu. We also operate regional innovation and field testing stations in Hargeisa, Garowe, Baidoa, and Kismayo.'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    addToast('success', 'Message Dispatched', 'Your inquiry has been delivered to SiHub front office.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-cyan-600">
          Reach Our Headquarters & Field Teams
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          Contact Somali Innovation Hub
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          Whether you want to visit our Mogadishu MakerSpace, enroll in an upcoming academy cohort, or propose an institutional partnership, we are here to support your journey.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Left: Contact Form */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-8 shadow-xs space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-slate-900 font-heading">Send Us a Direct Message</h3>
            <p className="text-xs text-slate-500">We respond to all verified inquiries within 24 business hours.</p>
          </div>

          {submitted ? (
            <div className="p-8 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
              <h4 className="text-base font-bold text-emerald-950">Inquiry Dispatched Successfully!</h4>
              <p className="text-xs text-emerald-700">
                A member of our team will follow up via email and phone.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs"
              >
                Send Another Note
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Your Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone / WhatsApp</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-cyan-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Topic / Directorate</label>
                  <select
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white"
                  >
                    <option>Startup Incubation & Seed Grants</option>
                    <option>Academy & LMS Course Enrollment</option>
                    <option>Institutional Partnership & MOUs</option>
                    <option>MakerSpace Lab & Facility Booking</option>
                    <option>Events & Sponsorships</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Message Details</label>
                <textarea
                  rows={4}
                  required
                  placeholder="How can SiHub assist you or collaborate with your organization?"
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 resize-none focus:outline-hidden focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs shadow-md transition-colors flex items-center gap-2"
                >
                  <Send className="w-4 h-4" /> Send Direct Message
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Right: Office Directory & Hours */}
        <div className="lg:col-span-5 space-y-6">
          <div className="p-8 rounded-3xl bg-slate-900 text-white shadow-xl space-y-6">
            <h3 className="text-lg font-bold text-cyan-400 font-heading">Somali Innovation Hub (HQ)</h3>

            <div className="space-y-4 text-xs text-slate-300">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block">Main Campus & MakerSpace:</strong>
                  <span>KM4 Airport Road, Wadajir District, Mogadishu, Somalia</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block">Working Hours:</strong>
                  <span>Saturday – Thursday: 8:00 AM – 5:00 PM (EAT)</span>
                  <span className="block text-[11px] text-slate-400">MakerSpace 24/7 access for active incubator cohorts</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block">Official Email:</strong>
                  <span>info@sihub.so • directorate@sihub.so</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block">Direct Telephone:</strong>
                  <span>+252 61 555 1200 / +252 61 888 9012</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400">
              Regional field stations active in Hargeisa, Garowe, Baidoa, and Kismayo.
            </div>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions Accordion */}
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-cyan-600">Got Questions?</span>
          <h2 className="text-2xl font-bold text-slate-900 font-heading">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaqIdx === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs"
              >
                <button
                  onClick={() => setOpenFaqIdx(isOpen ? null : idx)}
                  className="w-full text-left p-5 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-900 hover:text-cyan-700 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-cyan-600 shrink-0" />
                    {faq.q}
                  </span>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
