/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Public Navigation Header
 */

import React, { useState } from 'react';
import { useApp, AppView } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import {
  Menu,
  X,
  GraduationCap,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  UserCheck
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentView,
    navigateTo,
    activeRole,
    language,
    t
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { view: AppView; label: string; badge?: string }[] = [
    { view: 'home', label: t.nav.home },
    { view: 'about', label: t.nav.about },
    { view: 'programs', label: t.nav.programs },
    { view: 'courses', label: t.nav.courses, badge: 'LMS' },
    { view: 'startups', label: t.nav.startups },
    { view: 'innovation', label: t.nav.innovation },
    { view: 'events', label: t.nav.events },
    { view: 'opportunities', label: t.nav.opportunities },
    { view: 'mentorship', label: t.nav.mentorship },
    { view: 'community', label: t.nav.community },
    { view: 'partnerships', label: t.nav.partnerships },
    { view: 'news', label: t.nav.news },
    { view: 'contact', label: t.nav.contact }
  ];

  const handleNavClick = (view: AppView) => {
    navigateTo(view);
    setMobileMenuOpen(false);
  };

  const getRolePortalView = (): AppView => {
    switch (activeRole) {
      case 'learner': return 'learner_portal';
      case 'instructor': return 'instructor_portal';
      case 'startup_founder': return 'startup_portal';
      case 'mentor': return 'mentor_portal';
      case 'partner': return 'partner_portal';
      case 'admin':
      case 'super_admin':
      case 'staff':
      case 'program_manager':
        return 'admin';
      default:
        return 'learner_portal';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <div className="flex items-center gap-4">
            <BrandLogo
              size="md"
              showSubtitle={true}
              onClick={() => handleNavClick('home')}
            />
          </div>

          {/* Desktop Primary Navigation */}
          <nav className="hidden xl:flex items-center space-x-1">
            {navLinks.slice(0, 8).map(link => {
              const isActive = currentView === link.view;
              return (
                <button
                  key={link.view}
                  onClick={() => handleNavClick(link.view)}
                  className={`relative px-3 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    isActive
                      ? 'text-cyan-600 bg-cyan-50/80 font-bold'
                      : 'text-slate-700 hover:text-cyan-600 hover:bg-slate-50'
                  }`}
                >
                  {link.label}
                  {link.badge && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-100 text-cyan-800 font-bold">
                      {link.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-cyan-600 rounded-full" />
                  )}
                </button>
              );
            })}

            {/* Dropdown for More Sections */}
            <div className="relative group">
              <button className="px-3 py-2 rounded-lg text-xs font-semibold text-slate-700 hover:text-cyan-600 hover:bg-slate-50 flex items-center gap-1">
                More ▾
              </button>
              <div className="absolute right-0 mt-1 w-52 bg-white rounded-xl shadow-xl border border-slate-200 py-2 hidden group-hover:block animate-in fade-in zoom-in-95">
                {navLinks.slice(8).map(link => (
                  <button
                    key={link.view}
                    onClick={() => handleNavClick(link.view)}
                    className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 hover:bg-cyan-50 hover:text-cyan-600 flex items-center justify-between"
                  >
                    <span>{link.label}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Direct Portal Access */}
            <button
              onClick={() => handleNavClick(getRolePortalView())}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-200 transition-colors"
            >
              <UserCheck className="w-4 h-4 text-cyan-600" />
              <span>
                {activeRole === 'learner' ? 'My Learning Portal' : `${activeRole.replace('_', ' ')} Portal`}
              </span>
            </button>

            {/* Admin Back-Office Button */}
            <button
              onClick={() => handleNavClick('admin')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 shadow-sm transition-all"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Admin Console</span>
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="xl:hidden flex items-center gap-2">
            <button
              onClick={() => handleNavClick('admin')}
              className="p-2 rounded-lg bg-slate-900 text-white text-xs font-bold"
              title="Admin Dashboard"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-2 shadow-xl animate-in slide-in-from-top-4">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-100">
            <button
              onClick={() => handleNavClick('admin')}
              className="py-2.5 px-3 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Admin Console
            </button>
            <button
              onClick={() => handleNavClick(getRolePortalView())}
              className="py-2.5 px-3 rounded-xl bg-cyan-600 text-white text-xs font-bold flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4" /> Role Portal
            </button>
          </div>

          <div className="max-h-80 overflow-y-auto space-y-1 py-1">
            {navLinks.map(link => (
              <button
                key={link.view}
                onClick={() => handleNavClick(link.view)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between ${
                  currentView === link.view
                    ? 'bg-cyan-50 text-cyan-700 font-bold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>{link.label}</span>
                {link.badge && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-100 text-cyan-800 font-bold">
                    {link.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
