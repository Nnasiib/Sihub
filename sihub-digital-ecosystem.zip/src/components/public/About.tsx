/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - About SiHub Page
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import {
  Target,
  Eye,
  CheckCircle2,
  Award,
  Users,
  Building,
  ShieldCheck,
  Compass,
  ArrowRight
} from 'lucide-react';

export const About: React.FC = () => {
  const { navigateTo, t } = useApp();

  const values = [
    { title: 'Inclusivity & Equity', desc: 'Ensuring youth, women, and marginalized rural pastoralists across all federal states have equal access to knowledge and tools.' },
    { title: 'Multi-Sector Innovation', desc: 'Transcending pure IT by championing climate-resilient farming, renewable solar energy, clean water, and community healthcare.' },
    { title: 'Indigenous Ownership', desc: 'Developing solutions grounded in local language, cultural realities, and sustainable domestic business models.' },
    { title: 'Institutional Integrity', desc: 'Transparent governance, peer-reviewed curriculum standards, and audited financial and grant stewardship.' }
  ];

  const team = [
    {
      name: 'Eng. Abdullahi Warsame',
      role: 'Executive Director & Chief Systems Architect',
      location: 'Mogadishu Headquarters',
      bio: 'Enterprise systems specialist and former advisor on national digital infrastructure.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80'
    },
    {
      name: 'Fadumo Ahmed Noor',
      role: 'Head of Governance & Institutional Partnerships',
      location: 'Mogadishu & Regional Hubs',
      bio: 'Public policy strategist coordinating university sandboxes and multilateral agency grants.',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80'
    },
    {
      name: 'Dr. Hassan Ali Geedi',
      role: 'Director of Renewable Technology & AgriTech Labs',
      location: 'Hargeisa & Garowe Hubs',
      bio: 'PhD researcher on extreme-heat battery chemistry, solar micro-irrigation, and arid soil sensors.',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80'
    },
    {
      name: 'Sharmarke Abdi Liban',
      role: 'Director of Incubation & Acceleration',
      location: 'Mogadishu MakerSpace',
      bio: 'Former venture accelerator lead who has mentored over 50 startups to commercial sustainability.',
      image: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&auto=format&fit=crop&q=80'
    }
  ];

  return (
    <div className="space-y-16 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Overview Banner */}
      <section className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-cyan-600">
          Institutional Mandate
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          About Somali Innovation Hub (SiHub)
        </h1>
        <p className="text-base text-slate-600 leading-relaxed">
          Somali Innovation Hub (SiHub) is the independent institutional engine for innovation, digital capacity, entrepreneurship, and sustainable community empowerment across all Somali regions.
        </p>
      </section>

      {/* Mission & Vision Cards */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-8 rounded-3xl bg-gradient-to-br from-cyan-900 to-slate-900 text-white shadow-xl space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30">
            <Target className="w-6 h-6" />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">Our Mission</span>
          <h2 className="text-2xl font-bold font-heading">
            Connecting People, Empowering Ideas, Creating Opportunities.
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            To build a resilient, inclusive innovation ecosystem that bridges knowledge, provides seed capital, and mentors talented individuals to create scalable ventures that address critical societal needs.
          </p>
        </div>

        <div className="p-8 rounded-3xl bg-gradient-to-br from-emerald-950 to-slate-900 text-white shadow-xl space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-400/30">
            <Eye className="w-6 h-6" />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">Our Vision</span>
          <h2 className="text-2xl font-bold font-heading">
            A Thriving, Knowledge-Driven Horn of Africa.
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            A sovereign, technologically empowered Somalia where youth drive economic prosperity through sustainable agriculture, clean energy sovereignty, digital health, and world-class enterprise.
          </p>
        </div>
      </section>

      {/* Strategic Objectives */}
      <section className="p-8 sm:p-12 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-cyan-600">Strategic Pillars</span>
          <h3 className="text-2xl font-bold text-slate-900 font-heading mt-1">Our Core Institutional Objectives</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
            <div className="text-cyan-600 font-bold text-base">01. Human Capital Development</div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Equip thousands of young adults, women, and professionals with accredited online and hybrid training in software engineering, solar grids, and climate-smart farming.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
            <div className="text-emerald-600 font-bold text-base">02. Venture Incubation & Seed Grants</div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Accelerate early-stage startups with equity-free capital, high-speed labs, workspace, and connections to diaspora syndicates and international angels.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
            <div className="text-amber-600 font-bold text-base">03. Decentralized Regional Presence</div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Expand physical maker-spaces and field testing labs from Mogadishu into Hargeisa, Garowe, Baidoa, and Kismayo to ensure equitable national impact.
            </p>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-cyan-600">Organizational DNA</span>
          <h3 className="text-2xl font-bold text-slate-900 font-heading">Our Core Values</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((v, i) => (
            <div key={i} className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2">
              <h4 className="text-sm font-bold text-slate-900">{v.title}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Leadership Team */}
      <section className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">Executive Leadership</span>
          <h3 className="text-2xl font-bold text-slate-900 font-heading">Experienced Ecosystem Stewards</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, i) => (
            <div key={i} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-shadow">
              <img src={member.image} alt={member.name} className="h-48 w-full object-cover" />
              <div className="p-5 space-y-2">
                <h4 className="text-sm font-bold text-slate-900">{member.name}</h4>
                <div className="text-[11px] font-semibold text-cyan-700">{member.role}</div>
                <div className="text-[10px] text-slate-400">{member.location}</div>
                <p className="text-xs text-slate-600 pt-1 leading-relaxed">{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
