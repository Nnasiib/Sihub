/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Dedicated Programs Directory Page
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Program } from '../../types';
import {
  Rocket,
  CheckCircle2,
  Calendar,
  Users,
  Clock,
  Filter,
  ArrowRight,
  ShieldCheck,
  X
} from 'lucide-react';

export const ProgramsPage: React.FC = () => {
  const { addToast, triggerRefresh, currentUser } = useApp();
  const programs = StorageService.getPrograms();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeProgramModal, setActiveProgramModal] = useState<Program | null>(null);
  const [isAppliedSuccess, setIsAppliedSuccess] = useState(false);

  const categories = ['All', 'Incubation', 'Women in Innovation', 'Seed Grant'];

  const filtered = selectedCategory === 'All'
    ? programs
    : programs.filter(p => p.category === selectedCategory);

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
      setIsAppliedSuccess(true);
      addToast('success', 'Program Application Submitted', `Applied to ${activeProgramModal?.title}`);
      triggerRefresh();
    }, 500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
          Cohort Directories & Residencies
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          SiHub Flagship Programs & Cohorts
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          Structured, milestone-driven acceleration cohorts providing equity-free seed grants, dedicated international mentors, specialized laboratory facilities, and investor matching.
        </p>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === cat
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Programs List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map(program => (
          <div
            key={program.id}
            className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl transition-all flex flex-col justify-between"
          >
            <div>
              <div className="relative h-48">
                <img
                  src={program.thumbnailUrl}
                  alt={program.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-slate-900/90 text-emerald-300 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  {program.category}
                </div>
                <div className="absolute top-3 right-3 bg-white/95 text-slate-900 text-[10px] font-bold px-2.5 py-1 rounded-full shadow-xs">
                  Status: {program.status}
                </div>
              </div>

              <div className="p-6 space-y-4">
                <h3 className="text-lg font-bold text-slate-900 leading-snug">{program.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">{program.summary}</p>

                <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-cyan-600" /> Duration:</span>
                    <strong className="text-slate-800">{program.duration}</strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5 text-cyan-600" /> Cohort Size:</span>
                    <strong className="text-slate-800">{program.cohortSize} Selected</strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-rose-500" /> Deadline:</span>
                    <strong className="text-rose-600 font-semibold">{program.deadline}</strong>
                  </div>
                </div>

                <div className="space-y-1.5 pt-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Core Objectives:</span>
                  {program.objectives.slice(0, 2).map((obj, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px] text-slate-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{obj}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 pt-0">
              <button
                onClick={() => {
                  setActiveProgramModal(program);
                  setIsAppliedSuccess(false);
                }}
                className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <span>View Full Details & Apply</span>
                <ArrowRight className="w-4 h-4 text-cyan-400" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Program Application & Detail Modal */}
      {activeProgramModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 overflow-hidden my-8 shadow-2xl animate-in zoom-in-95">
            <div className="bg-gradient-to-r from-slate-900 to-slate-950 p-6 text-white relative">
              <button
                onClick={() => setActiveProgramModal(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
              <span className="text-cyan-400 text-[11px] font-bold uppercase tracking-wider">
                {activeProgramModal.category} Residency
              </span>
              <h3 className="text-xl font-bold pr-6">{activeProgramModal.title}</h3>
              <p className="text-xs text-slate-300 mt-1">Lead Coordinator: {activeProgramModal.coordinator}</p>
            </div>

            {isAppliedSuccess ? (
              <div className="p-8 text-center space-y-4">
                <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto" />
                <h4 className="text-xl font-bold text-slate-900">Program Application Submitted!</h4>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  Your application for {activeProgramModal.title} has been received by the program selection committee. You will receive an interview scheduling update shortly.
                </p>
                <button
                  onClick={() => setActiveProgramModal(null)}
                  className="px-6 py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
                >
                  Close & Return
                </button>
              </div>
            ) : (
              <div className="p-6 space-y-6">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Overview</h4>
                  <p className="text-xs text-slate-700 leading-relaxed">{activeProgramModal.summary}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Target Audience</span>
                    <strong className="text-slate-800">{activeProgramModal.targetAudience}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Program Deadline</span>
                    <strong className="text-rose-600 font-bold">{activeProgramModal.deadline}</strong>
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Eligibility Criteria</h4>
                  <ul className="space-y-1.5">
                    {activeProgramModal.eligibility.map((el, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                        <span>{el}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <form onSubmit={handleApplySubmit} className="pt-4 border-t border-slate-100 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Candidate / Team Lead Name</label>
                      <input
                        type="text"
                        required
                        defaultValue={currentUser.fullName}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
                      <input
                        type="email"
                        required
                        defaultValue={currentUser.email}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Venture / Project Brief</label>
                    <textarea
                      rows={2}
                      required
                      placeholder="Briefly state your solution and what you expect to achieve during this cohort..."
                      defaultValue="We have deployed our MVP and wish to join this cohort to scale across Somalia with mentor guidance."
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 resize-none"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveProgramModal(null)}
                      className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700"
                    >
                      Submit Cohort Application
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
