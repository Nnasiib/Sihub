/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Institutional Website Footer
 */

import React from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import {
  MapPin,
  Mail,
  Phone,
  Globe,
  ArrowUpRight,
  ShieldCheck,
  Heart
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { navigateTo, language, t } = useApp();

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-emerald-950 py-10 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <span className="text-cyan-400 font-semibold uppercase text-xs tracking-wider">
              {language === 'so' ? 'Hal-abuurka Qaranka' : 'National Innovation Ecosystem'}
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              {t.tagline}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              {t.taglineSub}
            </p>
          </div>

          <div className="flex flex-wrap gap-3 shrink-0">
            <button
              onClick={() => navigateTo('programs')}
              className="px-5 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg transition-transform hover:scale-102"
            >
              {t.actions.explorePrograms}
            </button>
            <button
              onClick={() => navigateTo('admin')}
              className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors"
            >
              {t.actions.explorePrograms.includes('Sahami') ? 'Maamulka (Admin)' : 'Admin Console'} &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer Directory */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Column 1: Organization & Logo */}
          <div className="lg:col-span-2 space-y-4">
            <BrandLogo size="lg" showSubtitle={true} lightText={true} />
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Somali Innovation Hub (SiHub) is an institutional platform championing entrepreneurship, renewable clean technology, modern agriculture, health tech, and youth digital capacity across all Somali regions.
            </p>

            <div className="space-y-2 text-xs text-slate-300 pt-2">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>KM4 Airport Road, Wadajir District, Mogadishu, Somalia</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>info@sihub.so • partnerships@sihub.so</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>+252 61 555 1200 / +252 61 888 9012</span>
              </div>
            </div>
          </div>

          {/* Column 2: Ecosystem Portals */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Ecosystem Portals</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('courses')} className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  Education & LMS <ArrowUpRight className="w-3 h-3 text-slate-500" />
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('startups')} className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  Startup Venture Hub <ArrowUpRight className="w-3 h-3 text-slate-500" />
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('innovation')} className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  Innovation Lab Tracks <ArrowUpRight className="w-3 h-3 text-slate-500" />
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('programs')} className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  Flagship Incubation 2026 <ArrowUpRight className="w-3 h-3 text-slate-500" />
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('mentorship')} className="hover:text-cyan-400 transition-colors flex items-center gap-1">
                  Diaspora Mentor Network <ArrowUpRight className="w-3 h-3 text-slate-500" />
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Community & Opportunities */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Community & Impact</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => navigateTo('events')} className="hover:text-cyan-400 transition-colors">
                  Annual Innovation Summit
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('opportunities')} className="hover:text-cyan-400 transition-colors">
                  Grants & Scholarships
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('community')} className="hover:text-cyan-400 transition-colors">
                  Regional Youth Hubs
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('news')} className="hover:text-cyan-400 transition-colors">
                  Research & Publications
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('partnerships')} className="hover:text-cyan-400 transition-colors">
                  Institutional Partners
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Regional Hubs & Governance */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Regional Hubs</h4>
            <div className="text-xs text-slate-400 space-y-2">
              <div>
                <strong className="text-slate-200">Mogadishu (HQ):</strong>
                <p className="text-[11px]">KM4 MakerSpace & High-Tech Lab</p>
              </div>
              <div>
                <strong className="text-slate-200">Hargeisa Hub:</strong>
                <p className="text-[11px]">Maroodi Jeex Innovation Station</p>
              </div>
              <div>
                <strong className="text-slate-200">Garowe Hub:</strong>
                <p className="text-[11px]">Puntland Clean Energy & IoT Lab</p>
              </div>
              <div>
                <strong className="text-slate-200">Baidoa & Kismayo:</strong>
                <p className="text-[11px]">AgriTech & Coastal Field Stations</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} Somali Innovation Hub (SiHub). All Rights Reserved.</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" /> ISO/IEC Aligned Architecture
            </span>
            <span>•</span>
            <button onClick={() => navigateTo('admin', 'settings')} className="hover:text-white transition-colors">
              Phase 2 Architecture & Security Blueprint
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
