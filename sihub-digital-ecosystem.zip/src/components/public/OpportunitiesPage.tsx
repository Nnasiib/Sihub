/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Opportunities (Scholarships, Grants, Jobs, Fellowships)
 */

import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storageService';
import { Opportunity } from '../../types';
import {
  Award,
  DollarSign,
  Calendar,
  MapPin,
  CheckCircle2,
  X,
  Send,
  Briefcase
} from 'lucide-react';

export const OpportunitiesPage: React.FC = () => {
  const { currentUser, addToast, triggerRefresh } = useApp();
  const opportunities = StorageService.getOpportunities();

  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedOpp, setSelectedOpp] = useState<Opportunity | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const types = ['All', 'Grant', 'Scholarship', 'Internship'];

  const filtered = selectedType === 'All'
    ? opportunities
    : opportunities.filter(o => o.type === selectedType);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
      setIsSubmitted(true);
      addToast('success', 'Application Submitted', `Your application for ${selectedOpp?.title} has been logged.`);
      triggerRefresh();
    }, 500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-emerald-600">
          Catalytic Funding & Career Pathways
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          Grants, Scholarships & Fellowships
        </h1>
        <p className="text-sm text-slate-600 leading-relaxed">
          Access equity-free innovation grants, full computer science tuition fellowships, and paid residency internships supported by SiHub and international partners.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-center gap-2">
        {types.map(t => (
          <button
            key={t}
            onClick={() => setSelectedType(t)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedType === t
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Opportunities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {filtered.map(opp => (
          <div
            key={opp.id}
            className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-lg transition-all flex flex-col justify-between space-y-5"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                  {opp.type}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {opp.applicantsCount} Applicants
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 leading-snug">{opp.title}</h3>
                <p className="text-xs text-slate-500 mt-1">Provider: {opp.provider}</p>
              </div>

              {opp.amountOrStipend && (
                <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-100 text-emerald-950 font-bold text-xs flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{opp.amountOrStipend}</span>
                </div>
              )}

              <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                {opp.description}
              </p>

              <div className="space-y-1.5 text-xs text-slate-500 pt-2 border-t border-slate-100">
                <div className="flex justify-between">
                  <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-cyan-600" /> Location:</span>
                  <strong className="text-slate-800">{opp.location}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5 text-rose-500" /> Deadline:</span>
                  <strong className="text-rose-600">{opp.deadline}</strong>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  setSelectedOpp(opp);
                  setIsSubmitted(false);
                }}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors shadow-xs"
              >
                Apply for Opportunity &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Opportunity Application Modal */}
      {selectedOpp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 overflow-hidden my-8 shadow-2xl animate-in zoom-in-95">
            <div className="bg-slate-900 p-6 text-white relative">
              <button
                onClick={() => setSelectedOpp(null)}
                className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
              <span className="text-emerald-400 text-xs font-bold uppercase tracking-wider">
                {selectedOpp.type} Application
              </span>
              <h3 className="text-xl font-bold pr-6">{selectedOpp.title}</h3>
              <p className="text-xs text-slate-300 mt-1">Deadline: {selectedOpp.deadline}</p>
            </div>

            {isSubmitted ? (
              <div className="p-8 text-center space-y-4">
                <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto" />
                <h4 className="text-xl font-bold text-slate-900">Application Submitted!</h4>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  Your candidate dossier has been forwarded to the evaluation panel. Decisions are dispatched via email.
                </p>
                <button
                  onClick={() => setSelectedOpp(null)}
                  className="px-6 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs"
                >
                  Close
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
                <div>
                  <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-1">Eligibility</h4>
                  <ul className="space-y-1">
                    {selectedOpp.eligibility.map((el, i) => (
                      <li key={i} className="flex items-center gap-2 text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> {el}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Applicant Name</label>
                    <input
                      type="text"
                      required
                      defaultValue={currentUser.fullName}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Email</label>
                    <input
                      type="email"
                      required
                      defaultValue={currentUser.email}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Proposal & Personal Statement</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Summarize your qualifications and how this grant or opportunity will create tangible impact..."
                    defaultValue="I have worked with pastoral youth and have prototyped a low-cost solution that meets all specified guidelines."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 resize-none"
                  />
                </div>

                <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedOpp(null)}
                    className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                  >
                    Submit Application
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
