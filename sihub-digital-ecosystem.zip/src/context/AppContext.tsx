/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Global Application Context
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, UserRole, Language, Course, SiHubEvent as Event, Startup } from '../types';
import { StorageService } from '../services/storageService';
import { TRANSLATIONS } from '../utils/translations';

export type AppView =
  | 'home'
  | 'about'
  | 'programs'
  | 'courses'
  | 'startups'
  | 'innovation'
  | 'community'
  | 'events'
  | 'opportunities'
  | 'mentorship'
  | 'partnerships'
  | 'news'
  | 'contact'
  | 'admin'
  | 'learner_portal'
  | 'instructor_portal'
  | 'startup_portal'
  | 'mentor_portal'
  | 'partner_portal';

export type AdminTab =
  | 'overview'
  | 'users'
  | 'lms'
  | 'startups'
  | 'innovation'
  | 'programs'
  | 'community'
  | 'events'
  | 'mentorship'
  | 'opportunities'
  | 'partnerships'
  | 'content'
  | 'impact'
  | 'ai'
  | 'settings';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
}

interface AppContextType {
  // Navigation
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  adminTab: AdminTab;
  setAdminTab: (tab: AdminTab) => void;
  navigateTo: (view: AppView, adminTab?: AdminTab) => void;

  // Role & User
  activeRole: UserRole;
  switchRole: (role: UserRole) => void;
  currentUser: User;
  users: User[];

  // Language
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof TRANSLATIONS.en;

  // Selected entities for modals / player
  selectedCourseForLearn: Course | null;
  setSelectedCourseForLearn: (course: Course | null) => void;
  selectedCourseForApply: Course | null;
  setSelectedCourseForApply: (course: Course | null) => void;
  selectedEventForRegister: Event | null;
  setSelectedEventForRegister: (event: Event | null) => void;
  selectedStartupForView: Startup | null;
  setSelectedStartupForView: (startup: Startup | null) => void;

  // Modals & Panels
  isAiAssistantOpen: boolean;
  setIsAiAssistantOpen: (open: boolean) => void;
  isRoleSwitcherOpen: boolean;
  setIsRoleSwitcherOpen: (open: boolean) => void;
  isStartupModalOpen: boolean;
  setIsStartupModalOpen: (open: boolean) => void;
  isPartnerModalOpen: boolean;
  setIsPartnerModalOpen: (open: boolean) => void;

  // Notifications
  toasts: ToastMessage[];
  addToast: (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => void;
  removeToast: (id: string) => void;

  // Global Actions
  resetDemoData: () => void;
  triggerRefresh: () => void;
  dataVersion: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [adminTab, setAdminTab] = useState<AdminTab>('overview');
  const [activeRole, setActiveRole] = useState<UserRole>('visitor');
  const [language, setLanguage] = useState<Language>('en');
  const [dataVersion, setDataVersion] = useState<number>(0);

  // Modals & Selected
  const [selectedCourseForLearn, setSelectedCourseForLearn] = useState<Course | null>(null);
  const [selectedCourseForApply, setSelectedCourseForApply] = useState<Course | null>(null);
  const [selectedEventForRegister, setSelectedEventForRegister] = useState<Event | null>(null);
  const [selectedStartupForView, setSelectedStartupForView] = useState<Startup | null>(null);

  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState<boolean>(false);
  const [isRoleSwitcherOpen, setIsRoleSwitcherOpen] = useState<boolean>(false);
  const [isStartupModalOpen, setIsStartupModalOpen] = useState<boolean>(false);
  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState<boolean>(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const triggerRefresh = () => {
    setDataVersion(v => v + 1);
  };

  useEffect(() => {
    const handleStorageUpdate = () => {
      setDataVersion(v => v + 1);
    };
    window.addEventListener('sihub-storage-update', handleStorageUpdate);
    return () => window.removeEventListener('sihub-storage-update', handleStorageUpdate);
  }, []);

  const users = StorageService.getUsers();

  // Find user matching role
  const currentUser: User = users.find(u => u.role === activeRole) || {
    id: `usr-${activeRole}`,
    fullName: `Demo ${activeRole.replace('_', ' ').toUpperCase()}`,
    email: `${activeRole}@sihub.so`,
    role: activeRole,
    isActive: true,
    registeredAt: new Date().toISOString()
  };

  const switchRole = (role: UserRole) => {
    setActiveRole(role);
    addToast('info', 'Switched Demonstration Role', `Now viewing the system as: ${role.replace('_', ' ').toUpperCase()}`);

    // Auto-route to corresponding role portal if user wants to see it immediately
    if (role === 'admin' || role === 'super_admin' || role === 'staff') {
      setCurrentView('admin');
    } else if (role === 'learner') {
      setCurrentView('learner_portal');
    } else if (role === 'instructor') {
      setCurrentView('instructor_portal');
    } else if (role === 'startup_founder') {
      setCurrentView('startup_portal');
    } else if (role === 'mentor') {
      setCurrentView('mentor_portal');
    } else if (role === 'partner') {
      setCurrentView('partner_portal');
    } else {
      setCurrentView('home');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateTo = (view: AppView, targetAdminTab?: AdminTab) => {
    setCurrentView(view);
    if (targetAdminTab) {
      setAdminTab(targetAdminTab);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetDemoData = () => {
    StorageService.resetAllData();
    triggerRefresh();
    addToast('success', 'Demo Reset', 'All demonstration courses, enrollments, startups, and records have been reset to factory defaults.');
  };

  const t = TRANSLATIONS[language];

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        adminTab,
        setAdminTab,
        navigateTo,
        activeRole,
        switchRole,
        currentUser,
        users,
        language,
        setLanguage,
        t,
        selectedCourseForLearn,
        setSelectedCourseForLearn,
        selectedCourseForApply,
        setSelectedCourseForApply,
        selectedEventForRegister,
        setSelectedEventForRegister,
        selectedStartupForView,
        setSelectedStartupForView,
        isAiAssistantOpen,
        setIsAiAssistantOpen,
        isRoleSwitcherOpen,
        setIsRoleSwitcherOpen,
        isStartupModalOpen,
        setIsStartupModalOpen,
        isPartnerModalOpen,
        setIsPartnerModalOpen,
        toasts,
        addToast,
        removeToast,
        resetDemoData,
        triggerRefresh,
        dataVersion
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
