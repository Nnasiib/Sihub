# SiHub Digital Ecosystem (Somali Innovation Hub)
> *"Connecting People, Empowering Ideas, Creating Opportunities."*

Official multi-sector digital ecosystem for **Somali Innovation Hub (SiHub)**.

---

## 🌟 Executive Overview

SiHub is Somalia's institutional catalyst for multi-sector innovation, human capital development, entrepreneurship, and community resilience. SiHub is **NOT exclusively an IT or cybersecurity organization**—its mandate spans:
- **AgriTech & Food Security:** Precision drip irrigation, Jubba-Shabelle river basin telemetry, solar-powered dairy chilling.
- **Renewable Energy & Climate:** Off-grid solar mini-grids, LiFePO4 battery testing for extreme heat, smart remote metering.
- **Healthcare & MedTech:** Mobile maternal telemedicine, solar vaccine cold-chain transport.
- **Software Engineering & Vernacular AI:** Scalable web & mobile engineering, open Somali NLP corpus.
- **Digital Entrepreneurship:** Early-stage venture incubation, seed grants, diaspora angel syndicates.

---

## 🚀 Key Modules Built & Explorable

### 1. Public Institutional Website
- **Home:** Hero section, mission/vision, featured programs, multi-sector innovation highlights, startup showcase, upcoming events, impact statistics, and trusted partners.
- **About Us:** Institutional mandate, mission, vision, core values, leadership team, and regional hubs.
- **Programs Directory:** Incubation, SWITI (Somali Women in Tech & Innovation), and Agrinnovation seed challenges with interactive application workflows.
- **Education & LMS Catalog:** 6 accredited courses with syllabus breakdowns, prerequisites, and **Enrollment Application with Mandatory Admin Approval notice**.
- **Startup Hub:** Directory of accelerated ventures (GeelTech, Banaadir Solar, Hilaac Health, Kalkaal EdTech), interactive founder pitch submission modal.
- **Innovation Lab:** Applied R&D projects across Agriculture, Technology, Environment, Health, and Social innovation with milestone checklists.
- **Events & Summits:** Somalia Annual Innovation Summit 2026, Climate Hackathons, with **Live QR Code Digital Ticket generation and download**.
- **Opportunities:** Scholarships (100% Tuition), $15,000 Climate Grants, and developer internships with interactive application submission.
- **Mentorship Network:** 1-on-1 booking requests with diaspora angels and senior tech architects.
- **Community:** Regional youth hubs in Mogadishu, Hargeisa, Garowe, Baidoa, and Kismayo, plus interactive knowledge exchange forum.
- **Partnerships:** Institutional alignments with UNDP Somalia, Ministry of Communications & Technology, and Hormuud Telecom Foundation.
- **News & Insights:** Success stories, policy whitepapers, and modal article reader.
- **Contact:** Mogadishu campus (KM4 Airport Road), regional stations, direct hotline, and interactive FAQ accordion.

### 2. Complete Administration Console (Modules 6.1 – 6.15)
- **6.1 Executive Overview:** KPI cards, live activity audit stream, and rapid enrollment approvals queue.
- **6.2 User Management:** Roster of all 11 persona roles, search, role reassignment, and account suspension/reactivation.
- **6.3 Education & LMS Control Center:**
  - Course CRUD (create, edit, publish/unpublish, delete demo courses).
  - **LMS Enrollment Approval Desk (Critical Rule):** Review applicant motivation and click *Approve Access* to immediately unlock lessons in the student dashboard, or *Reject with Custom Reason*.
  - Learner performance metrics and completion tracking.
- **6.4 Startup Hub Management:** Venture pipeline review (Ideation -> Incubation -> Acceleration -> Graduated alumni) and mentor assignment.
- **6.5 Innovation Lab Portfolio:** Milestone tracking, budget allocation, and beneficiary telemetry.
- **6.6 Programs & Cohorts:** Cohort batch sizing, application review, and residency tracking.
- **6.7 Community Moderation:** Regional ambassadors directory and forum discussion moderation.
- **6.8 Events & Attendance Desk:** Event scheduler and **Live Reception QR Ticket Scanner simulation** that validates tickets and updates attendance in real time.
- **6.9 Mentorship Desk:** Review mentee consultation requests and dispatch video consultation links.
- **6.10 Grants & Opportunities:** Post catalytic grants and review candidate dossiers.
- **6.11 Partnerships & MOUs:** Formal collaborative agreements and donor monitoring.
- **6.12 News & CMS:** Rich article creation, category management, and publication.
- **6.13 Impact & Monitoring (M&E):** UN SDG alignment and **Downloadable Official CSV Impact Report generation**.
- **6.14 AI Assistant Settings:** Configurable system instructions, prompt temperature, and vector knowledge base FAQ curation.
- **6.15 System Settings & Security Blueprint:** Organization branding, role permissions matrix, and complete Phase 2 architecture roadmap.

### 3. Dedicated Role Dashboards
- **Student / Learner ("My Learning"):** Access unlocked course player with video streams, PDF architecture guides, practical assignment submissions, interactive quizzes with auto-grading, and **verified Certificate of Completion generator**.
- **Instructor Dashboard:** Assigned courses, student enrollments, and assignment grading.
- **Startup Founder Dashboard:** Incubation milestone progress, pitch deck repository, and investor readiness tracker.
- **Mentor Dashboard:** Consultation calendar, video meeting links, and mentee logs.
- **Partner Dashboard:** Co-funded cohorts, grant leverage telemetry, and certified audit reports.

### 4. Interactive SiHub AI Assistant
- Dual-language support (**English & Somali / Af-Soomaali**).
- Guidance on courses, incubation, grants, and regional campus locations.
- Direct-action buttons that navigate users to the appropriate section or form.

### 5. Interactive Demo Persona Switcher Bar
- Floating top bar allowing instant switching between **all 11 user personas**:
  1. Visitor (Public)
  2. Student / Learner
  3. Instructor
  4. Startup Founder
  5. Mentor
  6. Community Member
  7. Staff Member
  8. Institutional Partner
  9. Program Manager
  10. Administrator
  11. Super Administrator
- Language toggle (**EN** / **SO**).
- Factory demo data reset button.

---

## 🔒 Phase 2 Architecture & Security Roadmap

### Relational Database Model (PostgreSQL / Drizzle ORM)
- Strict TypeScript schemas defined in `/src/types/index.ts` ready for PostgreSQL migration.
- Entities: `users`, `courses`, `course_modules`, `lessons`, `course_enrollments`, `startups`, `innovation_projects`, `programs`, `events`, `event_registrations`, `mentors`, `mentorship_requests`, `opportunities`, `partners`, `audit_logs`.

### Production Security Specifications
1. **Authentication:** Argon2id password hashing, OAuth2 client-side flows, short-lived JWT access tokens paired with rotating refresh tokens stored in `HttpOnly, Secure, SameSite=Strict` cookies.
2. **Authorization (RBAC):** Server-side middleware verifying role capabilities before mutating enrollments, courses, or grant disbursements.
3. **Database Security:** Parameterized queries to eliminate SQL injection, connection pooling with SSL encryption.
4. **Content Security Policy (CSP):** Strict script-src and frame-ancestors restrictions.
5. **Auditing:** Immutable database audit logs capturing user ID, timestamp, and action payload for all administrative events.
